import { useState } from 'react';
import type { StoreSettings } from '../types';
import { logActivity } from '../services/activity';
import { setPasscode, verifyPasscode } from '../services/auth';
import { BACKEND, APP_VERSION } from '../services/config';
import { useSettings } from '../services/data';
import { exportAll, importAll, resetCollections } from '../services/store';
import { toast } from '../services/ui';
import { Icon } from '../components/Icon';
import { Field, ImagePicker, Num, Switch } from '../components/ui';

function StringList({ title, items, onChange }: { title: string; items: string[]; onChange: (v: string[]) => void }) {
  return (
    <div className="editor">
      <div className="row-between"><h3>{title}</h3><button className="link" onClick={() => onChange([...items, ''])}>+ Agregar</button></div>
      {items.map((it, i) => (
        <div key={i} className="editor-row">
          <input value={it} onChange={(e) => onChange(items.map((x, j) => (j === i ? e.target.value : x)))} />
          <button className="icon-btn danger" aria-label="Quitar" onClick={() => onChange(items.filter((_, j) => j !== i))}><Icon name="close" size={18} /></button>
        </div>
      ))}
    </div>
  );
}

export function AdminSettings() {
  const [settings, setSettings] = useSettings();
  const [d, setD] = useState<StoreSettings>(settings);
  const [cur, setCur] = useState('');
  const [next, setNext] = useState('');
  const set = <K extends keyof StoreSettings>(k: K, v: StoreSettings[K]) => setD((x) => ({ ...x, [k]: v }));

  const save = () => {
    const pickup = d.pickupMethods.map((s) => s.trim()).filter(Boolean);
    const pay = d.paymentMethods.map((s) => s.trim()).filter(Boolean);
    if (!d.name.trim()) return toast('El nombre es obligatorio', 'error');
    if (!pickup.length || !pay.length) return toast('Deja al menos un método de entrega y uno de pago', 'error');
    setSettings((cur) => ({ ...d, name: d.name.trim(), pickupMethods: pickup, paymentMethods: pay, open: cur.open }));
    logActivity('Configuración guardada', 'Configuración', d.name);
    toast('Configuración guardada');
  };
  const toggleOpen = (v: boolean) => {
    setSettings((s) => ({ ...s, open: v }));
    setD((x) => ({ ...x, open: v }));
    logActivity(v ? 'Tienda abierta' : 'Tienda cerrada', 'Configuración', d.name);
  };
  const changePass = async () => {
    if (!(await verifyPasscode(cur))) return toast('La contraseña actual no es correcta', 'error');
    if (next.length < 6) return toast('La nueva contraseña necesita al menos 6 caracteres', 'error');
    await setPasscode(next);
    setCur(''); setNext('');
    logActivity('Contraseña cambiada', 'Seguridad', 'Administrador');
    toast('Contraseña actualizada');
  };
  const backup = () => {
    const blob = new Blob([JSON.stringify({ app: 'redwings', version: APP_VERSION, exportedAt: new Date().toISOString(), data: exportAll() })], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'redwings-respaldo-' + new Date().toISOString().slice(0, 10) + '.json';
    a.click();
    URL.revokeObjectURL(a.href);
  };
  const restore = async (file?: File) => {
    if (!file) return;
    try {
      const j = JSON.parse(await file.text());
      if (j.app !== 'redwings' || typeof j.data !== 'object') throw new Error('x');
      if (!window.confirm('Esto reemplaza los datos actuales con los del respaldo. ¿Continuar?')) return;
      importAll(j.data);
      toast('Respaldo restaurado');
    } catch {
      toast('El archivo no es un respaldo válido de Redwings', 'error');
    }
  };

  return (
    <div className="page">
      <h1 className="page-title">Configuración</h1>
      <section className="card">
        <Switch label={settings.open ? 'TIENDA ABIERTA' : 'TIENDA CERRADA'} checked={settings.open} onChange={toggleOpen} />
        <Field label="Mensaje cuando está cerrada"><input value={d.closedMessage} onChange={(e) => set('closedMessage', e.target.value)} /></Field>
        <Switch label="Permitir pedidos aunque esté cerrada (programados)" checked={d.allowOrdersWhenClosed} onChange={(v) => set('allowOrdersWhenClosed', v)} />
      </section>
      <section className="card">
        <h2>Tienda</h2>
        <Field label="Nombre"><input value={d.name} onChange={(e) => set('name', e.target.value)} /></Field>
        <Field label="Slogan"><input value={d.slogan} onChange={(e) => set('slogan', e.target.value)} /></Field>
        <Field label="Horario (texto libre)"><input value={d.hours} onChange={(e) => set('hours', e.target.value)} placeholder="Ej. Lun–Vie 9:00–15:00" /></Field>
        <Field label="WhatsApp (con código de país)" hint="Ej. 50499999999"><input inputMode="tel" value={d.whatsapp} onChange={(e) => set('whatsapp', e.target.value)} /></Field>
        <Field label="Teléfono de contacto"><input inputMode="tel" value={d.phone} onChange={(e) => set('phone', e.target.value)} /></Field>
        <Field label="Aviso importante (se muestra en inicio)"><input value={d.notice} onChange={(e) => set('notice', e.target.value)} /></Field>
        <Field label="Stock bajo desde (unidades)"><Num value={d.lowStockThreshold} onChange={(n) => set('lowStockThreshold', Math.floor(n))} /></Field>
      </section>
      <section className="card">
        <h2>Portada</h2>
        <Field label="Título (usa | para separar líneas)"><input value={d.banner.title} onChange={(e) => set('banner', { ...d.banner, title: e.target.value })} /></Field>
        <Field label="Texto"><input value={d.banner.text} onChange={(e) => set('banner', { ...d.banner, text: e.target.value })} /></Field>
        <ImagePicker label="Imagen de portada" value={d.banner.image} onChange={(v) => set('banner', { ...d.banner, image: v })} />
      </section>
      <section className="card">
        <StringList title="Métodos de entrega" items={d.pickupMethods} onChange={(v) => set('pickupMethods', v)} />
        <StringList title="Métodos de pago" items={d.paymentMethods} onChange={(v) => set('paymentMethods', v)} />
      </section>
      <button className="btn btn-primary btn-block" onClick={save}>Guardar configuración</button>

      <section className="card">
        <h2>Contraseña de administración</h2>
        <Field label="Contraseña actual"><input type="password" value={cur} onChange={(e) => setCur(e.target.value)} autoComplete="current-password" /></Field>
        <Field label="Nueva contraseña"><input type="password" value={next} onChange={(e) => setNext(e.target.value)} autoComplete="new-password" /></Field>
        <button className="btn btn-ghost btn-block" onClick={changePass}>Cambiar contraseña</button>
      </section>

      <section className="card">
        <h2>Datos</h2>
        <p className="small muted">Modo de datos: <b>{BACKEND === 'local' ? 'local (este dispositivo)' : 'Firebase'}</b> · versión {APP_VERSION}. Haz respaldos periódicos mientras no haya base de datos conectada.</p>
        <button className="btn btn-ghost btn-block" onClick={backup}>Descargar respaldo (.json)</button>
        <label className="btn btn-ghost btn-block">Restaurar respaldo<input type="file" accept="application/json" hidden onChange={(e) => { restore(e.target.files?.[0]); e.target.value = ''; }} /></label>
        <button className="btn btn-ghost btn-block danger" onClick={() => { if (window.confirm('¿Borrar TODOS los pedidos y notificaciones de este dispositivo? Úsalo para limpiar pruebas.')) { resetCollections(['orders', 'notifications', 'orderCounter']); logActivity('Pedidos borrados', 'Datos', 'Todos'); toast('Pedidos borrados', 'info'); } }}>Borrar pedidos de prueba</button>
        <button className="btn btn-ghost btn-block danger" onClick={() => { if (window.confirm('¿Restablecer productos, categorías y configuración a los datos de ejemplo?')) { resetCollections(['products', 'categories', 'settings']); setD(settings); toast('Datos de ejemplo restaurados', 'info'); } }}>Restablecer catálogo de ejemplo</button>
      </section>
    </div>
  );
}
