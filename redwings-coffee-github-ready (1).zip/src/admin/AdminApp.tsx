import { useEffect, useRef, useState } from 'react';
import { useOrders } from '../services/data';
import { endAdminSession, isAdminSession } from '../services/auth';
import { navigate } from '../services/router';
import { toast } from '../services/ui';
import { Icon } from '../components/Icon';
import { AdminActivity } from './AdminActivity';
import { AdminCategories } from './AdminCategories';
import { AdminLogin } from './AdminLogin';
import { AdminOrders } from './AdminOrders';
import { AdminProducts } from './AdminProducts';
import { AdminSettings } from './AdminSettings';
import { Dashboard } from './Dashboard';

const TABS: [string, string, string][] = [['', 'Resumen', 'chart'], ['orders', 'Pedidos', 'orders'], ['products', 'Productos', 'menu'], ['categories', 'Categorías', 'tag'], ['settings', 'Ajustes', 'gear']];

export function AdminApp({ route }: { route: string[] }) {
  const [logged, setLogged] = useState(isAdminSession());
  const [orders] = useOrders();
  const pending = orders.filter((o) => o.status === 'Pendiente').length;
  const prev = useRef(pending);

  useEffect(() => {
    if (logged && pending > prev.current) toast('Nuevo pedido recibido', 'info');
    prev.current = pending;
  }, [pending, logged]);

  if (!logged) return <AdminLogin onDone={() => setLogged(true)} />;
  const section = route[1] || '';
  let page;
  switch (section) {
    case 'orders': page = <AdminOrders />; break;
    case 'products': page = <AdminProducts />; break;
    case 'categories': page = <AdminCategories />; break;
    case 'settings': page = <AdminSettings />; break;
    case 'activity': page = <AdminActivity />; break;
    default: page = <Dashboard />;
  }
  return (
    <div className="shell admin">
      <header className="topbar">
        <div className="brand"><span className="brand-mark">R</span><span><b>Administración</b><small>Redwings Coffee</small></span></div>
        <div className="top-actions">
          <button className="icon-btn" onClick={() => navigate('')} aria-label="Ver tienda"><Icon name="home" /></button>
          <button className="icon-btn" onClick={() => { endAdminSession(); setLogged(false); }} aria-label="Cerrar sesión"><Icon name="logout" /></button>
        </div>
      </header>
      <main>{page}</main>
      <nav className="bottom-nav" aria-label="Navegación del panel">
        {TABS.map(([path, label, icon]) => (
          <button key={label} className={section === path ? 'on' : ''} onClick={() => navigate('admin' + (path ? '/' + path : ''))}>
            <Icon name={icon} /><span>{label}</span>{path === 'orders' && pending > 0 && <span className="badge-n">{pending}</span>}
          </button>
        ))}
      </nav>
    </div>
  );
}
