import { fmtDateTime } from '../lib/format';
import { useActivity } from '../services/data';
import { goBack } from '../services/router';
import { Empty } from '../components/ui';

export function AdminActivity() {
  const [log] = useActivity();
  return (
    <div className="page">
      <button className="link" onClick={() => goBack('admin')}>← Atrás</button>
      <h1 className="page-title">Actividad</h1>
      {log.length === 0 ? <Empty icon="list" title="Sin actividad" text="Aquí aparecerán los cambios hechos desde el panel." /> : (
        <div className="stack">{log.map((e) => <div key={e.id} className="card"><b>{e.action}</b><p className="small">{e.section} · {e.item}</p><p className="small muted">{e.user} · {fmtDateTime(e.at)}</p></div>)}</div>
      )}
    </div>
  );
}
