import { useState } from 'react';
import type { Category } from '../types';
import { uid } from '../lib/format';
import { logActivity } from '../services/activity';
import { useCategories, useProducts } from '../services/data';
import { toast } from '../services/ui';
import { Icon } from '../components/Icon';
import { Field, ImagePicker, Sheet, Switch } from '../components/ui';

export function AdminCategories() {
  const [cats, setCats] = useCategories();
  const [products] = useProducts();
  const [draft, setDraft] = useState<Category | null>(null);
  const [isNew, setIsNew] = useState(false);
  const sorted = [...cats].sort((a, b) => a.order - b.order);
  const countOf = (id: string) => products.filter((p) => p.categoryId === id).length;

  const move = (id: string, dir: -1 | 1) => {
    const i = sorted.findIndex((c) => c.id === id);
    const j = i + dir;
    if (j < 0 || j >= sorted.length) return;
    const a = sorted[i], b = sorted[j];
    setCats((all) => all.map((c) => (c.id === a.id ? { ...c, order: b.order } : c.id === b.id ? { ...c, order: a.order } : c)));
  };
  const save = () => {
    if (!draft) return;
    if (!draft.name.trim()) return toast('El nombre es obligatorio', 'error');
    const clean = { ...draft, name: draft.name.trim() };
    setCats((all) => (isNew ? [...all, clean] : all.map((c) => (c.id === clean.id ? clean : c))));
    logActivity(isNew ? 'Categoría creada' : 'Categoría editada', 'Categorías', clean.name);
    toast('Categoría guardada');
    setDraft(null);
  };
  const remove = (c: Category) => {
    if (countOf(c.id) > 0) return toast('Primero mueve o elimina sus ' + countOf(c.id) + ' producto(s).', 'error');
    if (!window.confirm('¿Eliminar la categoría "' + c.name + '"?')) return;
    setCats((all) => all.filter((x) => x.id !== c.id));
    logActivity('Categoría eliminada', 'Categorías', c.name);
  };

  return (
    <div className="page">
      <div className="row-between"><h1 className="page-title">Categorías</h1>
        <button className="btn btn-primary" onClick={() => { setIsNew(true); setDraft({ id: uid(), name: '', order: Math.max(0, ...cats.map((c) => c.order)) + 1, active: true }); }}><Icon name="plus" size={18} /> Nueva</button></div>
      <div className="stack">
        {sorted.map((c) => (
          <div key={c.id} className={'card prod-row' + (c.active ? '' : ' off')}>
            <div className="prod-info"><b>{c.name}</b><p className="small muted">{countOf(c.id)} producto(s){c.description ? ' · ' + c.description : ''}{c.active ? '' : ' · inactiva'}</p></div>
            <div className="prod-actions">
              <button className="icon-btn" aria-label="Subir" onClick={() => move(c.id, -1)}><Icon name="up" size={18} /></button>
              <button className="icon-btn" aria-label="Bajar" onClick={() => move(c.id, 1)}><Icon name="down" size={18} /></button>
              <button className="icon-btn" aria-label="Editar" onClick={() => { setIsNew(false); setDraft({ ...c }); }}><Icon name="edit" size={18} /></button>
              <button className="icon-btn danger" aria-label="Eliminar" onClick={() => remove(c)}><Icon name="trash" size={18} /></button>
            </div>
          </div>
        ))}
      </div>
      <p className="small muted">“Todos” es automático y siempre aparece primero en el menú.</p>
      {draft && (
        <Sheet title={isNew ? 'Nueva categoría' : 'Editar categoría'} onClose={() => setDraft(null)} footer={<button className="btn btn-primary btn-block" onClick={save}>Guardar</button>}>
          <Field label="Nombre"><input value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} /></Field>
          <Field label="Descripción (opcional)"><input value={draft.description || ''} onChange={(e) => setDraft({ ...draft, description: e.target.value })} /></Field>
          <ImagePicker label="Imagen (opcional)" value={draft.image} onChange={(v) => setDraft({ ...draft, image: v })} />
          <Switch label="Activa" checked={draft.active} onChange={(v) => setDraft({ ...draft, active: v })} />
        </Sheet>
      )}
    </div>
  );
}
