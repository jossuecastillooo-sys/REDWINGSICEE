import { useState } from 'react';
import { fmtDateTime, money, norm } from '../lib/format';
import { useOrders, useSettings } from '../services/data';
import { canChangeStatus, nextStatus, setOrderStatus } from '../services/orders';
import { toast } from '../services/ui';
import { openWhatsApp, orderMessage } from '../services/whatsapp';
import { Empty, Sheet } from '../components/ui';
import type { Order, OrderStatus } from '../types';

const FILTERS: (OrderStatus | 'Todos' | 'Activos')[] = ['Activos', 'Pendiente', 'Confirmado', 'En preparación', 'Listo', 'Entregado', 'Cancelado', 'Todos'];
const ACTIVE = ['Pendiente', 'Confirmado', 'En preparación', 'Listo'];
const cls = (s: string) => 'st-' + s.replace(/\s|ó/g, '');

export function AdminOrders() {
  const [orders] = useOrders();
  const [settings] = useSettings();
  const [filter, setFilter] = useState<(typeof FILTERS)[number]>('Activos');
  const [q, setQ] = useState('');
  const [asc, setAsc] = useState(false);
  const [openId, setOpenId] = useState<string | null>(null);
  const [cancelId, setCancelId] = useState<string | null>(null);
  const [reason, setReason] = useState('');

  const term = norm(q.trim());
  let list = orders.filter((o) => (filter === 'Todos' ? true : filter === 'Activos' ? ACTIVE.includes(o.status) : o.status === filter));
  if (term) list = list.filter((o) => norm(o.number + ' ' + o.customer.name + ' ' + o.customer.phone + ' ' + o.lines.map((l) => l.name).join(' ')).includes(term));
  list = [...list].sort((a, b) => (asc ? 1 : -1) * (a.createdAt < b.createdAt ? -1 : 1));
  const open = orders.find((o) => o.id === openId);
  const count = (f: (typeof FILTERS)[number]) => (f === 'Todos' ? orders.length : f === 'Activos' ? orders.filter((o) => ACTIVE.includes(o.status)).length : orders.filter((o) => o.status === f).length);

  const advance = (o: Order, s: OrderStatus) => {
    const err = setOrderStatus(o.id, s);
    if (err) toast(err, 'error'); else toast(o.number + ' → ' + s);
  };
  const doCancel = () => {
    if (!cancelId) return;
    const err = setOrderStatus(cancelId, 'Cancelado', reason);
    if (err) return toast(err, 'error');
    toast('Pedido cancelado', 'info');
    setCancelId(null); setReason('');
  };

  return (
    <div className="page">
      <h1 className="page-title">Pedidos</h1>
      <div className="search"><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar por número, nombre, teléfono…" aria-label="Buscar pedidos" /></div>
      <div className="chips chips-wrap">{FILTERS.map((f) => <button key={f} className={'chip' + (filter === f ? ' on' : '')} onClick={() => setFilter(f)}>{f} ({count(f)})</button>)}</div>
      <button className="link" onClick={() => setAsc(!asc)}>Orden: {asc ? 'más antiguos primero' : 'más recientes primero'}</button>
      {list.length === 0 ? <Empty icon="orders" title="Sin pedidos" text="No hay pedidos con este filtro." /> : (
        <div className="stack">
          {list.map((o) => {
            const next = nextStatus(o);
            return (
              <div key={o.id} className={'card order-card' + (o.status === 'Pendiente' ? ' is-new' : '')}>
                <button className="order-main" onClick={() => setOpenId(o.id)}>
                  <div className="row-between"><b>{o.number}</b><span className={'badge ' + cls(o.status)}>{o.status}</span></div>
                  <p>{o.customer.name} · {o.customer.career} {o.customer.grade}-{o.customer.section}</p>
                  <p className="small muted">{fmtDateTime(o.createdAt)} · {o.lines.reduce((s, l) => s + l.qty, 0)} productos</p>
                  <p className="order-total">{money(o.total)}</p>
                </button>
                <div className="btn-row">
                  {next && <button className="btn btn-primary" onClick={() => advance(o, next)}>Marcar: {next}</button>}
                  {canChangeStatus(o, 'Cancelado') && <button className="btn btn-ghost danger" onClick={() => { setCancelId(o.id); setReason(''); }}>Cancelar</button>}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {open && (
        <Sheet title={open.number} onClose={() => setOpenId(null)} tall>
          <span className={'badge ' + cls(open.status)}>{open.status}</span>
          <p><b>{open.customer.name}</b><br /><span className="muted small">Tel. {open.customer.phone} · {open.customer.career} · {open.customer.grade} · Sección {open.customer.section}</span></p>
          <p className="small muted">{fmtDateTime(open.createdAt)} · {open.pickup} · {open.payment}</p>
          {open.notes && <p className="small">Notas: {open.notes}</p>}
          {open.cancelReason && <p className="small err">Motivo de cancelación: {open.cancelReason}</p>}
          <div className="card">
            {open.lines.map((l, i) => <div key={i} className="sum-line"><div><b>{l.qty} × {l.name}</b><p className="small muted">{[l.sizeName, ...l.options, ...l.extras.map((e) => e.name + (e.qty > 1 ? ' x' + e.qty : '') + ' (+' + money(e.price * e.qty) + ')'), l.note].filter(Boolean).join(' · ')}</p></div><b>{money(l.unitPrice * l.qty)}</b></div>)}
            <div className="summary"><div><span>Subtotal</span><b>{money(open.subtotal)}</b></div><div><span>Descuentos</span><b>{money(open.discount)}</b></div><div className="total"><span>Total</span><b>{money(open.total)}</b></div></div>
          </div>
          <h3>Historial</h3>
          {open.history.map((h, i) => <p key={i} className="small"><b>{h.status}</b> · {fmtDateTime(h.at)}</p>)}
          <button className="btn btn-ghost btn-block" onClick={() => openWhatsApp({ ...settings, whatsapp: open.customer.phone.length === 8 ? '504' + open.customer.phone : open.customer.phone }, 'Hola ' + open.customer.name + ', sobre tu pedido ' + open.number + ': ')}>Escribir al cliente por WhatsApp</button>
          <button className="btn btn-ghost btn-block" onClick={() => openWhatsApp(settings, orderMessage(open, settings.name))}>Compartir resumen</button>
        </Sheet>
      )}
      {cancelId && (
        <Sheet title="Cancelar pedido" onClose={() => setCancelId(null)} footer={<button className="btn btn-danger btn-block" onClick={doCancel}>Confirmar cancelación</button>}>
          <p className="muted small">El cliente verá este motivo. Si el producto tenía inventario, se devolverá.</p>
          <label className="field"><span>Motivo</span><input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Ej. producto agotado" /></label>
        </Sheet>
      )}
    </div>
  );
}
