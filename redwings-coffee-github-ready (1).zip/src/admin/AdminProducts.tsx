import type React from 'react';
import { useState } from 'react';
import type { Choice, Extra, OptionGroup, Product, Size, Tag } from '../types';
import { money, norm, uid } from '../lib/format';
import { isAvailable } from '../lib/pricing';
import { logActivity } from '../services/activity';
import { useCategories, useProducts } from '../services/data';
import { toast } from '../services/ui';
import { Icon } from '../components/Icon';
import { Empty, Field, ImagePicker, Num, ProductImage, Sheet, Switch } from '../components/ui';

const TAGS: Tag[] = ['Nuevo', 'Popular', 'Oferta'];

function blank(categoryId: string, order: number): Product {
  return { id: uid(), name: '', description: '', categoryId, basePrice: 0, active: true, soldOut: false, stock: null, tags: [], featured: false, recommended: false, ingredients: [], sizes: [], optionGroups: [], extras: [], order };
}

export function AdminProducts() {
  const [products, setProducts] = useProducts();
  const [categories] = useCategories();
  const [q, setQ] = useState('');
  const [cat, setCat] = useState('all');
  const [draft, setDraft] = useState<Product | null>(null);
  const [isNew, setIsNew] = useState(false);

  const sorted = [...products].sort((a, b) => a.order - b.order);
  const filtering = !!q.trim() || cat !== 'all';
  const list = sorted.filter((p) => (cat === 'all' || p.categoryId === cat) && (!q.trim() || norm(p.name + ' ' + (p.code || '')).includes(norm(q.trim()))));
  const catName = (id: string) => categories.find((c) => c.id === id)?.name || 'Sin categoría';

  const patch = (id: string, fn: (p: Product) => Product, log?: string) => {
    setProducts((all) => all.map((p) => (p.id === id ? fn(p) : p)));
    if (log) logActivity(log, 'Productos', products.find((p) => p.id === id)?.name || id);
  };
  const move = (id: string, dir: -1 | 1) => {
    const i = sorted.findIndex((p) => p.id === id);
    const j = i + dir;
    if (j < 0 || j >= sorted.length) return;
    const a = sorted[i], b = sorted[j];
    setProducts((all) => all.map((p) => (p.id === a.id ? { ...p, order: b.order } : p.id === b.id ? { ...p, order: a.order } : p)));
  };
  const duplicate = (p: Product) => {
    const copy: Product = { ...JSON.parse(JSON.stringify(p)), id: uid(), name: p.name + ' (copia)', order: Math.max(0, ...products.map((x) => x.order)) + 1, demo: false };
    setProducts((all) => [...all, copy]);
    logActivity('Producto duplicado', 'Productos', p.name);
    toast('Producto duplicado');
  };
  const remove = (p: Product) => {
    if (!window.confirm('¿Eliminar "' + p.name + '"? Los pedidos anteriores se conservan.')) return;
    setProducts((all) => all.filter((x) => x.id !== p.id));
    logActivity('Producto eliminado', 'Productos', p.name);
    toast('Producto eliminado', 'info');
  };

  const save = () => {
    if (!draft) return;
    const d = draft;
    if (!d.name.trim()) return toast('El nombre es obligatorio', 'error');
    if (!categories.some((c) => c.id === d.categoryId)) return toast('Elige una categoría (créala primero si no existe)', 'error');
    if (!(d.basePrice >= 0)) return toast('Precio inválido', 'error');
    const sizes = d.sizes.filter((s) => s.name.trim());
    const optionGroups = d.optionGroups.filter((g) => g.name.trim()).map((g) => ({ ...g, choices: g.choices.filter((c) => c.name.trim()) })).filter((g) => g.choices.length);
    const extras = d.extras.filter((e) => e.name.trim());
    const clean: Product = { ...d, name: d.name.trim(), sizes, optionGroups, extras, ingredients: d.ingredients.map((i) => i.trim()).filter(Boolean), demo: false, stock: d.stock === null ? null : Math.max(0, Math.floor(d.stock)) };
    if (isNew) {
      setProducts((all) => [...all, clean]);
      logActivity('Producto creado', 'Productos', clean.name);
    } else {
      const old = products.find((p) => p.id === clean.id);
      setProducts((all) => all.map((p) => (p.id === clean.id ? clean : p)));
      logActivity(old && old.basePrice !== clean.basePrice ? 'Precio modificado (' + money(old.basePrice) + ' → ' + money(clean.basePrice) + ')' : 'Producto editado', 'Productos', clean.name);
    }
    toast('Producto guardado');
    setDraft(null);
  };

  const set = <K extends keyof Product>(k: K, v: Product[K]) => setDraft((d) => (d ? { ...d, [k]: v } : d));

  return (
    <div className="page">
      <div className="row-between"><h1 className="page-title">Productos</h1>
        <button className="btn btn-primary" onClick={() => { setIsNew(true); setDraft(blank(categories[0]?.id || '', Math.max(0, ...products.map((p) => p.order)) + 1)); }}><Icon name="plus" size={18} /> Nuevo</button></div>
      <div className="search"><Icon name="search" size={20} /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar producto…" aria-label="Buscar productos" /></div>
      <div className="chips chips-wrap"><button className={'chip' + (cat === 'all' ? ' on' : '')} onClick={() => setCat('all')}>Todos</button>{categories.map((c) => <button key={c.id} className={'chip' + (cat === c.id ? ' on' : '')} onClick={() => setCat(c.id)}>{c.name}</button>)}</div>
      {products.some((p) => p.demo) && <div className="notice">Los productos marcados “Ejemplo” son datos iniciales editables. Al editarlos dejan de ser ejemplo.</div>}
      {list.length === 0 ? <Empty icon="menu" title="Sin productos" text="Crea tu primer producto con el botón Nuevo." /> : (
        <div className="stack">
          {list.map((p) => (
            <div key={p.id} className={'card prod-row' + (p.active ? '' : ' off')}>
              <ProductImage src={p.image} name={p.name} className="line-img" />
              <div className="prod-info">
                <b>{p.name}</b>
                <p className="small muted">{catName(p.categoryId)} · {money(p.basePrice)}{p.stock !== null ? ' · stock ' + p.stock : ''}</p>
                <div className="tags-row">
                  {p.demo && <span className="tag">Ejemplo</span>}
                  {!p.active && <span className="tag tag-off">Inactivo</span>}
                  {p.active && !isAvailable(p) && <span className="tag tag-off">Agotado</span>}
                  {p.featured && <span className="tag">Destacado</span>}
                </div>
              </div>
              <div className="prod-actions">
                <button className="icon-btn" aria-label="Editar" onClick={() => { setIsNew(false); setDraft(JSON.parse(JSON.stringify(p))); }}><Icon name="edit" size={18} /></button>
                <button className="icon-btn" aria-label="Duplicar" onClick={() => duplicate(p)}><Icon name="copy" size={18} /></button>
                <button className="icon-btn" aria-label="Subir" disabled={filtering} onClick={() => move(p.id, -1)}><Icon name="up" size={18} /></button>
                <button className="icon-btn" aria-label="Bajar" disabled={filtering} onClick={() => move(p.id, 1)}><Icon name="down" size={18} /></button>
                <button className="chip-s" onClick={() => patch(p.id, (x) => ({ ...x, soldOut: !x.soldOut }), p.soldOut ? 'Producto reactivado' : 'Producto marcado agotado')}>{p.soldOut ? 'Reponer' : 'Agotar'}</button>
                <button className="chip-s" onClick={() => patch(p.id, (x) => ({ ...x, active: !x.active }), p.active ? 'Producto desactivado' : 'Producto activado')}>{p.active ? 'Desactivar' : 'Activar'}</button>
                <button className="icon-btn danger" aria-label="Eliminar" onClick={() => remove(p)}><Icon name="trash" size={18} /></button>
              </div>
            </div>
          ))}
        </div>
      )}
      {filtering && <p className="small muted center">Quita los filtros para reordenar.</p>}

      {draft && (
        <Sheet title={isNew ? 'Nuevo producto' : 'Editar producto'} onClose={() => setDraft(null)} tall footer={<button className="btn btn-primary btn-block" onClick={save}>Guardar producto</button>}>
          <Field label="Nombre"><input value={draft.name} onChange={(e) => set('name', e.target.value)} /></Field>
          <Field label="Descripción"><textarea rows={2} value={draft.description} onChange={(e) => set('description', e.target.value)} /></Field>
          <ImagePicker value={draft.image} onChange={(v) => set('image', v)} />
          <div className="two">
            <Field label="Categoría"><select value={draft.categoryId} onChange={(e) => set('categoryId', e.target.value)}>{categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></Field>
            <Field label="Precio base (L)"><Num value={draft.basePrice} onChange={(n) => set('basePrice', n)} /></Field>
          </div>
          <div className="two">
            <Field label="Código interno (opcional)"><input value={draft.code || ''} onChange={(e) => set('code', e.target.value)} /></Field>
            <Field label="Preparación (min)"><Num value={draft.prepMinutes || 0} onChange={(n) => set('prepMinutes', n || undefined)} /></Field>
          </div>
          <Field label="Ingredientes (separados por coma)"><input value={draft.ingredients.join(', ')} onChange={(e) => set('ingredients', e.target.value.split(','))} /></Field>

          <Switch label="Activo (visible en el menú)" checked={draft.active} onChange={(v) => set('active', v)} />
          <Switch label="Agotado" checked={draft.soldOut} onChange={(v) => set('soldOut', v)} />
          <Switch label="Destacado en inicio" checked={draft.featured} onChange={(v) => set('featured', v)} />
          <Switch label="Recomendado" checked={draft.recommended} onChange={(v) => set('recommended', v)} />
          <Switch label="Controlar inventario" checked={draft.stock !== null} onChange={(v) => set('stock', v ? 0 : null)} />
          {draft.stock !== null && <Field label="Existencias" hint="Al llegar a 0 el producto se agota automáticamente."><Num value={draft.stock} onChange={(n) => set('stock', n)} /></Field>}
          <div className="chips chips-wrap">{TAGS.map((t) => <button type="button" key={t} className={'chip' + (draft.tags.includes(t) ? ' on' : '')} onClick={() => set('tags', draft.tags.includes(t) ? draft.tags.filter((x) => x !== t) : [...draft.tags, t])}>{t}</button>)}</div>

          <ListEditor<Size> title="Tamaños (precio total de cada tamaño)" items={draft.sizes} onChange={(v) => set('sizes', v)} make={() => ({ id: uid(), name: '', price: draft.basePrice })}
            render={(s, up) => (<><input placeholder="Nombre (Grande)" value={s.name} onChange={(e) => up({ ...s, name: e.target.value })} /><Num value={s.price} onChange={(n) => up({ ...s, price: n })} label="Precio" /></>)} />

          <div className="editor"><div className="row-between"><h3>Opciones (leche, azúcar, hielo…)</h3><button className="link" onClick={() => set('optionGroups', [...draft.optionGroups, { id: uid(), name: '', required: false, choices: [] } as OptionGroup])}>+ Grupo</button></div>
            {draft.optionGroups.map((g, gi) => {
              const upG = (ng: OptionGroup) => set('optionGroups', draft.optionGroups.map((x, i) => (i === gi ? ng : x)));
              return (
                <div key={g.id} className="card sub">
                  <div className="row-between"><input placeholder="Nombre del grupo (Leche)" value={g.name} onChange={(e) => upG({ ...g, name: e.target.value })} /><button className="icon-btn danger" aria-label="Quitar grupo" onClick={() => set('optionGroups', draft.optionGroups.filter((_, i) => i !== gi))}><Icon name="trash" size={18} /></button></div>
                  <Switch label="Obligatoria" checked={g.required} onChange={(v) => upG({ ...g, required: v })} />
                  <ListEditor<Choice> title="Opciones" items={g.choices} onChange={(v) => upG({ ...g, choices: v })} make={() => ({ id: uid(), name: '', price: 0 })}
                    render={(c, up) => (<><input placeholder="Opción" value={c.name} onChange={(e) => up({ ...c, name: e.target.value })} /><Num value={c.price} onChange={(n) => up({ ...c, price: n })} label="Precio extra" /></>)} />
                </div>
              );
            })}
          </div>

          <ListEditor<Extra> title="Extras de este producto" items={draft.extras} onChange={(v) => set('extras', v)} make={() => ({ id: uid(), name: '', price: 0, available: true, max: 3 })}
            render={(e, up) => (<><input placeholder="Extra" value={e.name} onChange={(x) => up({ ...e, name: x.target.value })} /><Num value={e.price} onChange={(n) => up({ ...e, price: n })} label="Precio" /><button type="button" className={'chip-s' + (e.available ? ' on' : '')} onClick={() => up({ ...e, available: !e.available })}>{e.available ? 'Disponible' : 'No disp.'}</button></>)} />
        </Sheet>
      )}
    </div>
  );
}

function ListEditor<T extends { id: string }>({ title, items, onChange, make, render }: { title: string; items: T[]; onChange: (v: T[]) => void; make: () => T; render: (item: T, update: (n: T) => void) => React.ReactNode }) {
  return (
    <div className="editor">
      <div className="row-between"><h3>{title}</h3><button type="button" className="link" onClick={() => onChange([...items, make()])}>+ Agregar</button></div>
      {items.map((it) => (
        <div key={it.id} className="editor-row">
          {render(it, (n) => onChange(items.map((x) => (x.id === it.id ? n : x))))}
          <button type="button" className="icon-btn danger" aria-label="Quitar" onClick={() => onChange(items.filter((x) => x.id !== it.id))}><Icon name="close" size={18} /></button>
        </div>
      ))}
      {items.length === 0 && <p className="small muted">Ninguno. Si lo dejas vacío, esta opción no aparece al cliente.</p>}
    </div>
  );
}
