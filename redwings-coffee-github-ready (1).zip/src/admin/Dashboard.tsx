import { useMemo, useState } from 'react';
import { dayKey, fmtDateTime, money, startOfDay } from '../lib/format';
import { useCategories, useOrders, useProducts, useSettings } from '../services/data';
import { navigate } from '../services/router';
import { BarList } from '../components/ui';
import type { Order } from '../types';

type Period = 'today' | 'week' | 'month' | 'custom';
const OPEN: Order['status'][] = ['Pendiente', 'Confirmado', 'En preparación', 'Listo'];
const income = (os: Order[]) => os.filter((o) => o.status === 'Entregado').reduce((s, o) => s + o.total, 0);

export function Dashboard() {
  const [orders] = useOrders();
  const [products] = useProducts();
  const [categories] = useCategories();
  const [settings] = useSettings();
  const [period, setPeriod] = useState<Period>('today');
  const [from, setFrom] = useState(dayKey(new Date()));
  const [to, setTo] = useState(dayKey(new Date()));

  const range = useMemo(() => {
    const now = new Date();
    const today = startOfDay(now);
    if (period === 'today') return [today, now] as const;
    if (period === 'week') return [new Date(today.getTime() - 6 * 86400000), now] as const;
    if (period === 'month') return [new Date(now.getFullYear(), now.getMonth(), 1), now] as const;
    const f = new Date(from + 'T00:00:00');
    const t = new Date(to + 'T23:59:59');
    return [f, t] as const;
  }, [period, from, to]);

  const inRange = orders.filter((o) => { const d = new Date(o.createdAt); return d >= range[0] && d <= range[1]; });
  const valid = inRange.filter((o) => o.status !== 'Cancelado');
  const count = (s: Order['status']) => inRange.filter((o) => o.status === s).length;

  const now = new Date();
  const today = startOfDay(now);
  const weekSales = income(orders.filter((o) => new Date(o.createdAt) >= new Date(today.getTime() - 6 * 86400000)));
  const monthSales = income(orders.filter((o) => new Date(o.createdAt) >= new Date(now.getFullYear(), now.getMonth(), 1)));
  const todaySales = income(orders.filter((o) => new Date(o.createdAt) >= today));

  const byDay = useMemo(() => {
    const m = new Map<string, number>();
    inRange.filter((o) => o.status === 'Entregado').forEach((o) => m.set(dayKey(o.createdAt), (m.get(dayKey(o.createdAt)) || 0) + o.total));
    return [...m.entries()].sort().slice(-14).map(([k, v]) => ({ label: k.slice(5), value: v, display: money(v) }));
  }, [inRange]);

  const top = useMemo(() => {
    const m = new Map<string, { name: string; qty: number }>();
    valid.forEach((o) => o.lines.forEach((l) => { const e = m.get(l.productId) || { name: l.name, qty: 0 }; e.qty += l.qty; m.set(l.productId, e); }));
    return [...m.values()].sort((a, b) => b.qty - a.qty).slice(0, 5).map((e) => ({ label: e.name, value: e.qty, display: String(e.qty) }));
  }, [valid]);

  const byCat = useMemo(() => {
    const m = new Map<string, number>();
    valid.forEach((o) => o.lines.forEach((l) => {
      const cid = products.find((p) => p.id === l.productId)?.categoryId;
      const name = categories.find((c) => c.id === cid)?.name || 'Otros';
      m.set(name, (m.get(name) || 0) + l.qty);
    }));
    return [...m.entries()].sort((a, b) => b[1] - a[1]).map(([k, v]) => ({ label: k, value: v, display: String(v) }));
  }, [valid, products, categories]);

  const soldOut = products.filter((p) => p.active && (p.soldOut || (p.stock !== null && p.stock <= 0)));
  const low = products.filter((p) => p.active && !p.soldOut && p.stock !== null && p.stock > 0 && p.stock <= settings.lowStockThreshold);
  const customers = new Set(orders.map((o) => o.customer.phone)).size;
  const pending = orders.filter((o) => o.status === 'Pendiente').length;

  return (
    <div className="page">
      <h1 className="page-title">Resumen</h1>
      {pending > 0 && <button className="notice notice-gold" onClick={() => navigate('admin/orders')}><b>{pending}</b> pedido(s) nuevo(s) por confirmar →</button>}
      <div className="stat-grid">
        <div className="stat"><small>Ventas hoy</small><b>{money(todaySales)}</b></div>
        <div className="stat"><small>Ventas 7 días</small><b>{money(weekSales)}</b></div>
        <div className="stat"><small>Ventas del mes</small><b>{money(monthSales)}</b></div>
        <div className="stat"><small>Clientes</small><b>{customers}</b></div>
      </div>
      <p className="small muted">Las ventas cuentan solo pedidos entregados. Los cancelados nunca suman.</p>

      <div className="tabs">
        {([['today', 'Hoy'], ['week', 'Semana'], ['month', 'Mes'], ['custom', 'Rango']] as [Period, string][]).map(([k, l]) => <button key={k} className={period === k ? 'on' : ''} onClick={() => setPeriod(k)}>{l}</button>)}
      </div>
      {period === 'custom' && <div className="two"><label className="field"><span>Desde</span><input type="date" value={from} onChange={(e) => setFrom(e.target.value)} /></label><label className="field"><span>Hasta</span><input type="date" value={to} onChange={(e) => setTo(e.target.value)} /></label></div>}

      <section className="card"><h2>Pedidos del período</h2>
        <div className="stat-grid">
          <div className="stat"><small>Pendientes</small><b>{count('Pendiente')}</b></div>
          <div className="stat"><small>En preparación</small><b>{count('En preparación')}</b></div>
          <div className="stat"><small>Listos</small><b>{count('Listo')}</b></div>
          <div className="stat"><small>Entregados</small><b>{count('Entregado')}</b></div>
        </div>
        <p className="small muted">Ingresos del período: <b>{money(income(inRange))}</b> · Cancelados: {count('Cancelado')} · En proceso: {inRange.filter((o) => OPEN.includes(o.status)).length}</p>
      </section>
      <section className="card"><h2>Ventas por día</h2><BarList items={byDay} empty="Aún no hay pedidos entregados en este período." /></section>
      <section className="card"><h2>Más vendidos</h2><BarList items={top} empty="Sin pedidos en este período." /></section>
      <section className="card"><h2>Ventas por categoría (unidades)</h2><BarList items={byCat} empty="Sin pedidos en este período." /></section>
      <section className="card"><h2>Alertas de inventario</h2>
        {soldOut.length === 0 && low.length === 0 && <p className="muted small">Todo en orden.</p>}
        {soldOut.map((p) => <p key={p.id} className="small"><span className="tag tag-off">Agotado</span> {p.name}</p>)}
        {low.map((p) => <p key={p.id} className="small"><span className="tag">Stock bajo</span> {p.name}: quedan {p.stock}</p>)}
      </section>
      <section className="card"><h2>Últimos pedidos</h2>
        {orders.slice(0, 5).map((o) => <button key={o.id} className="sum-line btn-plain" onClick={() => navigate('admin/orders')}><div><b>{o.number} · {o.customer.name}</b><p className="small muted">{fmtDateTime(o.createdAt)} · {o.status}</p></div><b>{money(o.total)}</b></button>)}
        {orders.length === 0 && <p className="muted small">Aún no hay pedidos.</p>}
      </section>
      <button className="link center" onClick={() => navigate('admin/activity')}>Ver actividad del sistema</button>
    </div>
  );
}
