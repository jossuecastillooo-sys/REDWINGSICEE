import type React from 'react';
import { useState } from 'react';
import { hasPasscode, setPasscode, startAdminSession, verifyPasscode } from '../services/auth';
import { navigate } from '../services/router';
import { toast } from '../services/ui';
import { Field } from '../components/ui';

export function AdminLogin({ onDone }: { onDone: () => void }) {
  const creating = !hasPasscode();
  const [pass, setPass] = useState('');
  const [pass2, setPass2] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      if (creating) {
        if (pass.length < 6) return toast('Usa al menos 6 caracteres', 'error');
        if (pass !== pass2) return toast('Las contraseñas no coinciden', 'error');
        await setPasscode(pass);
        startAdminSession();
        onDone();
      } else if (await verifyPasscode(pass)) {
        startAdminSession();
        onDone();
      } else {
        toast('Contraseña incorrecta', 'error');
      }
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="login">
      <form className="card login-card" onSubmit={submit}>
        <span className="brand-mark big">R</span>
        <h1>Redwings · Administración</h1>
        <p className="muted small">{creating ? 'Primer acceso: crea la contraseña de este dispositivo.' : 'Acceso privado del equipo.'}</p>
        <Field label="Contraseña"><input type="password" autoComplete={creating ? 'new-password' : 'current-password'} value={pass} onChange={(e) => setPass(e.target.value)} /></Field>
        {creating && <Field label="Repetir contraseña"><input type="password" autoComplete="new-password" value={pass2} onChange={(e) => setPass2(e.target.value)} /></Field>}
        <button className="btn btn-primary btn-block" disabled={busy || !pass}>{creating ? 'Crear y entrar' : 'Entrar'}</button>
        <button type="button" className="link center" onClick={() => navigate('')}>← Volver a la tienda</button>
        <p className="small muted center">Acceso local de este dispositivo. La autenticación segura por usuario llegará con la base de datos.</p>
      </form>
    </div>
  );
}
