/** 'local' = datos en este dispositivo. Cambiará a 'firebase' cuando se conecte la base de datos. */
export const BACKEND: 'local' | 'firebase' = 'local';
export const APP_VERSION = '0.2.0';
