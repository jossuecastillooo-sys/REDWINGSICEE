import type { Order, StoreSettings } from '../types';
import { money } from '../lib/format';

export function orderMessage(o: Order, shopName: string): string {
  const lines = o.lines.map((l) => {
    const extra = [l.sizeName, ...l.options, ...l.extras.map((e) => e.name + (e.qty > 1 ? ' x' + e.qty : ''))].filter(Boolean).join(', ');
    return '• ' + l.qty + ' x ' + l.name + (extra ? ' (' + extra + ')' : '') + ' — ' + money(l.unitPrice * l.qty);
  });
  return [
    'Hola ' + shopName + ', hice el pedido ' + o.number + '.',
    'Nombre: ' + o.customer.name,
    'Carrera: ' + o.customer.career + ' · ' + o.customer.grade + ' · Sección ' + o.customer.section,
    ...lines,
    'Total: ' + money(o.total),
    o.pickup + ' · ' + o.payment,
    o.notes ? 'Notas: ' + o.notes : '',
  ].filter(Boolean).join('\n');
}

export function whatsappUrl(settings: StoreSettings, text: string): string {
  const num = settings.whatsapp.replace(/\D/g, '');
  return 'https://wa.me/' + num + '?text=' + encodeURIComponent(text);
}

export const openWhatsApp = (settings: StoreSettings, text: string) => window.open(whatsappUrl(settings, text), '_blank', 'noopener');
