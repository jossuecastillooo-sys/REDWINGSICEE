import type { AppNotification, CartLine, CustomerProfile, Order, OrderLine, OrderStatus, Product, StoreSettings } from '../types';
import { isValidPhone, normalizePhone, uid } from '../lib/format';
import { describeLine, unitPrice, validateLine } from '../lib/pricing';
import { DEFAULT_SETTINGS, SEED_PRODUCTS } from './seed';
import { logActivity } from './activity';
import { addToCart, priceCart } from './cart';
import { getStored, setStored } from './store';

export const STATUS_FLOW: OrderStatus[] = ['Pendiente', 'Confirmado', 'En preparación', 'Listo', 'Entregado'];

export const STATUS_MESSAGE: Record<OrderStatus, string> = {
  Pendiente: 'Recibimos tu pedido. Esperamos confirmarlo pronto.',
  Confirmado: 'Tu pedido fue confirmado.',
  'En preparación': 'Estamos preparando tu pedido.',
  Listo: 'Tu pedido está listo para recoger.',
  Entregado: 'Pedido entregado. ¡Gracias por tu compra!',
  Cancelado: 'El pedido fue cancelado.',
};

const NOTIFY_TITLE: Record<OrderStatus, string> = {
  Pendiente: 'Pedido recibido',
  Confirmado: 'Pedido confirmado',
  'En preparación': 'Pedido en preparación',
  Listo: 'Tu pedido está listo',
  Entregado: 'Pedido entregado',
  Cancelado: 'Pedido cancelado',
};

function notify(phone: string, status: OrderStatus, order: Order, extra?: string) {
  const n: AppNotification = {
    id: uid(), phone, title: NOTIFY_TITLE[status] + ' · ' + order.number,
    body: STATUS_MESSAGE[status] + (extra ? ' ' + extra : ''),
    createdAt: new Date().toISOString(), read: false, orderId: order.id,
  };
  setStored('notifications', [n, ...getStored<AppNotification[]>('notifications', [])].slice(0, 200));
}

export interface SubmitInput {
  customer: Omit<CustomerProfile, 'createdAt'>;
  pickup: string;
  payment: string;
  notes?: string;
}

export type SubmitResult = { ok: true; order: Order } | { ok: false; error: string };

/** Valida todo contra el catálogo actual y crea el pedido. */
export function submitOrder(input: SubmitInput): SubmitResult {
  const settings = getStored<StoreSettings>('settings', DEFAULT_SETTINGS);
  const products = getStored<Product[]>('products', SEED_PRODUCTS);
  const cart = getStored<CartLine[]>('cart', []);

  if (!settings.open && !settings.allowOrdersWhenClosed) return { ok: false, error: settings.closedMessage || 'La tienda está cerrada.' };
  if (!cart.length) return { ok: false, error: 'Tu carrito está vacío.' };

  const c = input.customer;
  if (!c.name.trim()) return { ok: false, error: 'Escribe tu nombre.' };
  if (!isValidPhone(c.phone)) return { ok: false, error: 'El teléfono debe tener 8 dígitos.' };
  if (!c.career.trim() || !c.grade.trim() || !c.section.trim()) return { ok: false, error: 'Completa carrera, grado y sección.' };
  if (!settings.pickupMethods.includes(input.pickup)) return { ok: false, error: 'Elige cómo recibirás tu pedido.' };
  if (!settings.paymentMethods.includes(input.payment)) return { ok: false, error: 'Elige el método de pago.' };

  const priced = priceCart(cart, products);
  const bad = priced.lines.find((l) => l.error);
  if (bad) return { ok: false, error: bad.error as string };

  // Stock agregado por producto (varias líneas del mismo producto).
  const perProduct = new Map<string, number>();
  priced.lines.forEach((l) => perProduct.set(l.line.productId, (perProduct.get(l.line.productId) || 0) + l.line.qty));
  for (const [pid, qty] of perProduct) {
    const p = products.find((x) => x.id === pid);
    if (p && p.stock !== null && qty > p.stock) return { ok: false, error: 'Solo quedan ' + p.stock + ' de ' + p.name + '.' };
  }

  const lines: OrderLine[] = priced.lines.map(({ line, product, unit }) => {
    const d = describeLine(product as Product, line);
    return {
      productId: line.productId, name: (product as Product).name, sizeName: d.size, options: d.options, extras: d.extras,
      qty: line.qty, unitPrice: unit, note: line.note,
      config: { sizeId: line.sizeId, choices: line.choices, extras: line.extras },
    };
  });
  const subtotal = lines.reduce((s, l) => s + l.unitPrice * l.qty, 0);
  const counter = getStored<number>('orderCounter', 0) + 1;
  const now = new Date().toISOString();
  const order: Order = {
    id: uid(), number: 'RW-' + String(counter).padStart(4, '0'), createdAt: now,
    customer: { ...c, name: c.name.trim(), phone: normalizePhone(c.phone) },
    lines, subtotal, discount: 0, total: subtotal, status: 'Pendiente', history: [{ status: 'Pendiente', at: now }],
    pickup: input.pickup, payment: input.payment, notes: input.notes?.trim() || undefined, stockReserved: true,
  };

  setStored('orderCounter', counter);
  setStored('products', products.map((p) => (p.stock !== null && perProduct.has(p.id) ? { ...p, stock: p.stock - (perProduct.get(p.id) as number) } : p)));
  setStored('orders', [order, ...getStored<Order[]>('orders', [])]);
  notify(order.customer.phone, 'Pendiente', order);
  return { ok: true, order };
}

const FINAL: OrderStatus[] = ['Entregado', 'Cancelado'];

export function canChangeStatus(order: Order, next: OrderStatus): boolean {
  if (FINAL.includes(order.status) || order.status === next) return false;
  if (next === 'Cancelado') return true;
  return STATUS_FLOW.indexOf(next) > STATUS_FLOW.indexOf(order.status);
}

export function nextStatus(order: Order): OrderStatus | null {
  const i = STATUS_FLOW.indexOf(order.status);
  return i >= 0 && i < STATUS_FLOW.length - 1 ? STATUS_FLOW[i + 1] : null;
}

export function setOrderStatus(orderId: string, status: OrderStatus, reason?: string): string | null {
  const orders = getStored<Order[]>('orders', []);
  const order = orders.find((o) => o.id === orderId);
  if (!order) return 'Pedido no encontrado.';
  if (!canChangeStatus(order, status)) return 'Ese cambio de estado no es válido.';
  if (status === 'Cancelado' && !reason?.trim()) return 'Escribe el motivo de la cancelación.';

  const updated: Order = {
    ...order, status, history: [...order.history, { status, at: new Date().toISOString() }],
    cancelReason: status === 'Cancelado' ? reason!.trim() : order.cancelReason,
  };
  if (status === 'Cancelado' && order.stockReserved) {
    const back = new Map<string, number>();
    order.lines.forEach((l) => back.set(l.productId, (back.get(l.productId) || 0) + l.qty));
    setStored('products', getStored<Product[]>('products', SEED_PRODUCTS).map((p) => (p.stock !== null && back.has(p.id) ? { ...p, stock: p.stock + (back.get(p.id) as number) } : p)));
    updated.stockReserved = false;
  }
  setStored('orders', orders.map((o) => (o.id === orderId ? updated : o)));
  notify(order.customer.phone, status, updated, status === 'Cancelado' ? 'Motivo: ' + reason!.trim() : undefined);
  logActivity(status === 'Cancelado' ? 'Pedido cancelado' : 'Estado cambiado a ' + status, 'Pedidos', order.number);
  return null;
}

/** "Volver a pedir": recarga las líneas de un pedido anterior verificando disponibilidad y precios. */
export function reorder(order: Order): { added: number; warnings: string[] } {
  const products = getStored<Product[]>('products', SEED_PRODUCTS);
  const warnings: string[] = [];
  let added = 0;
  for (const l of order.lines) {
    const p = products.find((x) => x.id === l.productId);
    const line: CartLine = { id: '', productId: l.productId, sizeId: l.config.sizeId, choices: l.config.choices, extras: l.config.extras, qty: l.qty, note: l.note };
    const err = validateLine(p, line);
    if (err || !p) {
      warnings.push(l.name + ': ' + (err || 'ya no existe') + ' (no se agregó).');
      continue;
    }
    const now = unitPrice(p, line);
    if (now !== l.unitPrice) warnings.push(l.name + ': el precio cambió de L' + l.unitPrice + ' a L' + now + '.');
    addToCart({ productId: line.productId, sizeId: line.sizeId, choices: line.choices, extras: line.extras, qty: line.qty, note: line.note });
    added++;
  }
  return { added, warnings };
}
