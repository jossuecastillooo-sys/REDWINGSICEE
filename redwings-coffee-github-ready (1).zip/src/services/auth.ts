import { getStored, setStored } from './store';

/**
 * Acceso admin LOCAL: solo protege la interfaz en este dispositivo.
 * No es seguridad real (los datos están en el navegador). La autenticación segura
 * llegará con Firebase Auth + reglas de Firestore.
 */
interface AuthRecord { salt: string; hash: string }
const SESSION_KEY = 'rw2_admin_session';

async function sha256(text: string): Promise<string> {
  if (window.crypto?.subtle) {
    const buf = await window.crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
    return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, '0')).join('');
  }
  let h = 5381;
  for (let i = 0; i < text.length; i++) h = ((h << 5) + h + text.charCodeAt(i)) | 0;
  return String(h);
}

export const hasPasscode = (): boolean => !!getStored<AuthRecord | null>('adminAuth', null);

export async function setPasscode(pass: string): Promise<void> {
  const salt = Math.random().toString(36).slice(2) + Date.now().toString(36);
  setStored<AuthRecord>('adminAuth', { salt, hash: await sha256(salt + pass) });
}

export async function verifyPasscode(pass: string): Promise<boolean> {
  const rec = getStored<AuthRecord | null>('adminAuth', null);
  if (!rec) return false;
  return (await sha256(rec.salt + pass)) === rec.hash;
}

export const isAdminSession = (): boolean => sessionStorage.getItem(SESSION_KEY) === '1';
export const startAdminSession = () => sessionStorage.setItem(SESSION_KEY, '1');
export const endAdminSession = () => sessionStorage.removeItem(SESSION_KEY);
