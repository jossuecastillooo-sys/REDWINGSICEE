import type { CartLine, Product } from '../types';
import { uid } from '../lib/format';
import { unitPrice, validateLine } from '../lib/pricing';
import { getStored, setStored } from './store';

const sig = (l: Omit<CartLine, 'id' | 'qty'>) =>
  JSON.stringify([
    l.productId, l.sizeId || '', l.note || '',
    Object.entries(l.choices).sort(), Object.entries(l.extras).filter(([, q]) => q > 0).sort(),
  ]);

/** Agrega al carrito. Misma configuración = suma cantidad; distinta = línea separada. */
export function addToCart(line: Omit<CartLine, 'id'>, replaceId?: string) {
  const cart = getStored<CartLine[]>('cart', []);
  if (replaceId) {
    setStored('cart', cart.map((l) => (l.id === replaceId ? { ...line, id: replaceId } : l)));
    return;
  }
  const s = sig(line);
  const existing = cart.find((l) => sig(l) === s);
  if (existing) {
    setStored('cart', cart.map((l) => (l.id === existing.id ? { ...l, qty: Math.min(99, l.qty + line.qty) } : l)));
  } else {
    setStored('cart', [...cart, { ...line, id: uid() }]);
  }
}

export const setLineQty = (id: string, qty: number) => {
  const cart = getStored<CartLine[]>('cart', []);
  setStored('cart', qty <= 0 ? cart.filter((l) => l.id !== id) : cart.map((l) => (l.id === id ? { ...l, qty: Math.min(99, qty) } : l)));
};
export const removeLine = (id: string) => setStored('cart', getStored<CartLine[]>('cart', []).filter((l) => l.id !== id));
export const clearCart = () => setStored('cart', []);

export interface PricedLine {
  line: CartLine;
  product?: Product;
  unit: number;
  total: number;
  error: string | null;
}

/** Recalcula siempre con los precios actuales del catálogo. */
export function priceCart(cart: CartLine[], products: Product[]): { lines: PricedLine[]; subtotal: number; count: number; valid: boolean } {
  const lines = cart.map((line) => {
    const product = products.find((p) => p.id === line.productId);
    const error = validateLine(product, line);
    const unit = product ? unitPrice(product, line) : 0;
    return { line, product, unit, total: unit * line.qty, error };
  });
  return {
    lines,
    subtotal: lines.reduce((s, l) => s + (l.error ? 0 : l.total), 0),
    count: cart.reduce((s, l) => s + l.qty, 0),
    valid: lines.length > 0 && lines.every((l) => !l.error),
  };
}
