import type { ActivityEntry, AppNotification, CartLine, Category, CustomerProfile, Order, Product, StoreSettings } from '../types';
import { useStored } from './store';
import { DEFAULT_SETTINGS, SEED_CATEGORIES, SEED_PRODUCTS } from './seed';

const NO_ORDERS: Order[] = [];
const NO_CART: CartLine[] = [];
const NO_FAVS: string[] = [];
const NO_NOTIFS: AppNotification[] = [];
const NO_ACTIVITY: ActivityEntry[] = [];

export const useSettings = () => useStored<StoreSettings>('settings', DEFAULT_SETTINGS);
export const useCategories = () => useStored<Category[]>('categories', SEED_CATEGORIES);
export const useProducts = () => useStored<Product[]>('products', SEED_PRODUCTS);
export const useOrders = () => useStored<Order[]>('orders', NO_ORDERS);
export const useCart = () => useStored<CartLine[]>('cart', NO_CART);
export const useFavorites = () => useStored<string[]>('favorites', NO_FAVS);
export const useNotifications = () => useStored<AppNotification[]>('notifications', NO_NOTIFS);
export const useActivity = () => useStored<ActivityEntry[]>('activity', NO_ACTIVITY);
export const useCustomer = () => useStored<CustomerProfile | null>('customer', null);
export const useLookupPhone = () => useStored<string>('lookupPhone', '');

export const COLLECTION_KEYS = {
  settings: 'settings', categories: 'categories', products: 'products', orders: 'orders',
  cart: 'cart', favorites: 'favorites', notifications: 'notifications', activity: 'activity',
  customer: 'customer', counter: 'orderCounter',
} as const;

export { DEFAULT_SETTINGS, SEED_CATEGORIES, SEED_PRODUCTS };
