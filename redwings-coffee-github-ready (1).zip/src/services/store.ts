import { useCallback, useSyncExternalStore } from 'react';
import { toast } from './ui';

/**
 * Capa de persistencia. Hoy guarda en localStorage del dispositivo.
 * Para conectar Firebase más adelante, solo hay que reemplazar getStored/setStored
 * (o añadir un adaptador) sin tocar los componentes.
 */
const PREFIX = 'rw2_';
const cache = new Map<string, unknown>();
const subs = new Map<string, Set<() => void>>();

function emit(key: string) {
  subs.get(key)?.forEach((f) => f());
}

function parse<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(PREFIX + key);
    return raw === null ? fallback : (JSON.parse(raw) as T);
  } catch {
    return fallback;
  }
}

export function getStored<T>(key: string, fallback: T): T {
  if (!cache.has(key)) cache.set(key, parse(key, fallback));
  return cache.get(key) as T;
}

export function setStored<T>(key: string, value: T): boolean {
  cache.set(key, value);
  let ok = true;
  try {
    localStorage.setItem(PREFIX + key, JSON.stringify(value));
  } catch {
    ok = false;
    toast('No hay espacio para guardar. Usa imágenes más pequeñas o borra datos.', 'error');
  }
  emit(key);
  return ok;
}

if (typeof window !== 'undefined') {
  // Sincroniza pestañas del mismo dispositivo (tienda y admin abiertos a la vez).
  window.addEventListener('storage', (e) => {
    if (e.key && e.key.startsWith(PREFIX)) {
      const key = e.key.slice(PREFIX.length);
      cache.delete(key);
      emit(key);
    }
  });
}

export function useStored<T>(key: string, fallback: T) {
  const subscribe = useCallback(
    (cb: () => void) => {
      let set = subs.get(key);
      if (!set) {
        set = new Set();
        subs.set(key, set);
      }
      set.add(cb);
      return () => {
        set!.delete(cb);
      };
    },
    [key],
  );
  const value = useSyncExternalStore(subscribe, () => getStored(key, fallback));
  const update = useCallback(
    (v: T | ((prev: T) => T)) => {
      const prev = getStored(key, fallback);
      setStored(key, typeof v === 'function' ? (v as (p: T) => T)(prev) : v);
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [key],
  );
  return [value, update] as const;
}

/** Exporta todos los datos de la app (respaldo). */
export function exportAll(): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (let i = 0; i < localStorage.length; i++) {
    const k = localStorage.key(i);
    if (k && k.startsWith(PREFIX) && k !== PREFIX + 'adminAuth') {
      out[k.slice(PREFIX.length)] = parse(k.slice(PREFIX.length), null);
    }
  }
  return out;
}

export function importAll(data: Record<string, unknown>) {
  Object.entries(data).forEach(([k, v]) => {
    if (k !== 'adminAuth') setStored(k, v);
  });
}

export function resetCollections(keys: string[]) {
  keys.forEach((k) => {
    localStorage.removeItem(PREFIX + k);
    cache.delete(k);
    emit(k);
  });
}
