import { useSyncExternalStore } from 'react';

export type ToastKind = 'ok' | 'error' | 'info';
interface ToastState { id: number; msg: string; kind: ToastKind }

let current: ToastState | null = null;
let counter = 0;
let timer: number | undefined;
const listeners = new Set<() => void>();

export function toast(msg: string, kind: ToastKind = 'ok') {
  current = { id: ++counter, msg, kind };
  listeners.forEach((l) => l());
  window.clearTimeout(timer);
  timer = window.setTimeout(() => {
    current = null;
    listeners.forEach((l) => l());
  }, 3200);
}

export function useToast(): ToastState | null {
  return useSyncExternalStore(
    (cb) => {
      listeners.add(cb);
      return () => {
        listeners.delete(cb);
      };
    },
    () => current,
  );
}

/* Producto abierto en la hoja de personalización */
export interface SheetTarget { productId: string; lineId?: string }
let sheet: SheetTarget | null = null;
const sheetListeners = new Set<() => void>();
export const openProduct = (productId: string, lineId?: string) => {
  sheet = { productId, lineId };
  sheetListeners.forEach((l) => l());
};
export const closeProduct = () => {
  sheet = null;
  sheetListeners.forEach((l) => l());
};
export function useProductSheet(): SheetTarget | null {
  return useSyncExternalStore(
    (cb) => {
      sheetListeners.add(cb);
      return () => {
        sheetListeners.delete(cb);
      };
    },
    () => sheet,
  );
}

/* Conectividad */
export function useOnline(): boolean {
  return useSyncExternalStore(
    (cb) => {
      window.addEventListener('online', cb);
      window.addEventListener('offline', cb);
      return () => {
        window.removeEventListener('online', cb);
        window.removeEventListener('offline', cb);
      };
    },
    () => navigator.onLine,
  );
}
