import type { ActivityEntry } from '../types';
import { uid } from '../lib/format';
import { getStored, setStored } from './store';

/** Registra una acción administrativa (se conservan las últimas 300). */
export function logActivity(action: string, section: string, item: string, user = 'Administrador') {
  const list = getStored<ActivityEntry[]>('activity', []);
  const entry: ActivityEntry = { id: uid(), at: new Date().toISOString(), user, action, section, item };
  setStored('activity', [entry, ...list].slice(0, 300));
}
