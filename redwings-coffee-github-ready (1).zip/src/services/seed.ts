import type { Category, Product, StoreSettings, Choice, Extra } from '../types';

export const DEFAULT_SETTINGS: StoreSettings = {
  name: 'Redwings Coffee',
  slogan: 'Tu momento. | Tu café.',
  open: true,
  closedMessage: 'Estamos cerrados por ahora. Puedes explorar el menú y volver pronto.',
  allowOrdersWhenClosed: false,
  hours: '',
  whatsapp: '50492899752',
  phone: '',
  notice: '',
  banner: { title: 'Tu momento. | Tu café.', text: 'Sabores que convierten cualquier pausa en tu momento favorito.' },
  pickupMethods: ['Recoger en el instituto', 'Entrega coordinada'],
  paymentMethods: ['Pago en efectivo'],
  lowStockThreshold: 5,
};

export const SEED_CATEGORIES: Category[] = [
  { id: 'granitas', name: 'Granitas', order: 1, active: true },
  { id: 'frappes', name: 'Frappés', order: 2, active: true },
  { id: 'bolis', name: 'Bolis', order: 3, active: true },
  { id: 'cafe', name: 'Café', order: 4, active: true },
];

const milk = (): { id: string; name: string; required: boolean; choices: Choice[] } => ({
  id: 'leche',
  name: 'Leche',
  required: true,
  choices: [
    { id: 'entera', name: 'Entera', price: 0 },
    { id: 'deslactosada', name: 'Deslactosada', price: 0 },
    { id: 'descremada', name: 'Descremada', price: 0 },
  ],
});

const ex = (id: string, name: string, price: number): Extra => ({ id, name, price, available: true, max: 3 });

const base = (p: Partial<Product> & Pick<Product, 'id' | 'name' | 'categoryId' | 'basePrice' | 'order'>): Product => ({
  description: '',
  active: true,
  soldOut: false,
  stock: null,
  tags: [],
  featured: false,
  recommended: false,
  ingredients: [],
  sizes: [],
  optionGroups: [],
  extras: [],
  demo: true,
  ...p,
});

/** Productos de ejemplo con los precios iniciales. Todo es editable desde el panel admin. */
export const SEED_PRODUCTS: Product[] = [
  base({
    id: 'granita-tradicional', name: 'Granita tradicional', categoryId: 'granitas', basePrice: 45, order: 1,
    description: 'Café frío con sabor intenso.',
    optionGroups: [milk()],
    extras: [ex('crema-batida', 'Crema batida', 8), ex('oreo', 'Oreo adicional', 8), ex('hersheys', "Caramelo Hershey's", 6), ex('lechera', 'Lechera', 5)],
  }),
  base({
    id: 'granita-crema', name: 'Granita con crema', categoryId: 'granitas', basePrice: 50, order: 2,
    description: 'Granita cremosa para una pausa especial.',
    optionGroups: [milk()],
    extras: [ex('oreo', 'Oreo adicional', 8), ex('hersheys', "Caramelo Hershey's", 6), ex('lechera', 'Lechera', 5)],
  }),
  base({
    id: 'frappe-lechera', name: 'Frappé café con lechera', categoryId: 'frappes', basePrice: 55, order: 3,
    description: 'Frappé de café con leche condensada.',
    optionGroups: [milk()],
    extras: [ex('crema-batida', 'Crema batida', 8), ex('oreo', 'Oreo adicional', 8), ex('pinguino', 'Pinguino', 5), ex('lechera', 'Lechera', 5)],
  }),
  base({
    id: 'pinguinera', name: 'Pinguinera', categoryId: 'frappes', basePrice: 65, order: 4,
    description: 'Especialidad de la casa.', featured: true,
    optionGroups: [milk()],
    extras: [ex('crema-batida', 'Crema batida', 8), ex('pinguino', 'Pinguino', 5), ex('lechera', 'Lechera', 5)],
  }),
  base({
    id: 'frappe-oreo', name: 'Frappé Oreo', categoryId: 'frappes', basePrice: 70, order: 5,
    description: 'Frappé con galleta de chocolate.', featured: true,
    optionGroups: [milk()],
    extras: [ex('crema-batida', 'Crema batida', 8), ex('oreo', 'Oreo adicional', 8)],
  }),
  base({
    id: 'bolis-oreo', name: 'Bolis Oreo largos', categoryId: 'bolis', basePrice: 30, order: 6,
    description: 'Postre frío de Oreo.',
    extras: [ex('oreo', 'Oreo adicional', 8)],
  }),
  base({
    id: 'cafe-tradicional', name: 'Café tradicional (1 lb)', categoryId: 'cafe', basePrice: 150, order: 7,
    description: 'Café tradicional en bolsa de una libra.',
  }),
  base({
    id: 'cafe-pimienta', name: 'Café con pimienta (1 lb)', categoryId: 'cafe', basePrice: 165, order: 8,
    description: 'Mezcla especial de café con pimienta.',
  }),
];
