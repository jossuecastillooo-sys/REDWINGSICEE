import { useEffect, useSyncExternalStore } from 'react';

const get = () => window.location.hash.replace(/^#\/?/, '');
const subscribe = (cb: () => void) => {
  window.addEventListener('hashchange', cb);
  return () => window.removeEventListener('hashchange', cb);
};

/** Devuelve los segmentos de la ruta, p. ej. "orders/abc" -> ["orders","abc"]. */
export function useRoute(): string[] {
  const hash = useSyncExternalStore(subscribe, get);
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [hash]);
  return hash.split('/').filter(Boolean);
}

export const navigate = (path: string) => {
  window.location.hash = '/' + path.replace(/^\//, '');
};

export const goBack = (fallback = '') => {
  if (window.history.length > 1) window.history.back();
  else navigate(fallback);
};
