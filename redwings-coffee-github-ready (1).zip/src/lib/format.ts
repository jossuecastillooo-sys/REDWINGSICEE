export const money = (n: number): string =>
  'L' + (Number.isFinite(n) ? n : 0).toLocaleString('es-HN', { minimumFractionDigits: 0, maximumFractionDigits: 2 });

export const uid = (): string =>
  Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

export const fmtDate = (iso: string): string =>
  new Date(iso).toLocaleDateString('es-HN', { day: '2-digit', month: 'short', year: 'numeric' });

export const fmtTime = (iso: string): string =>
  new Date(iso).toLocaleTimeString('es-HN', { hour: '2-digit', minute: '2-digit' });

export const fmtDateTime = (iso: string): string => fmtDate(iso) + ' · ' + fmtTime(iso);

/** Deja solo dígitos; quita el prefijo 504 si viene completo. */
export const normalizePhone = (raw: string): string => {
  const d = raw.replace(/\D/g, '');
  return d.length === 11 && d.startsWith('504') ? d.slice(3) : d;
};

export const isValidPhone = (raw: string): boolean => normalizePhone(raw).length === 8;

export const startOfDay = (d: Date): Date => new Date(d.getFullYear(), d.getMonth(), d.getDate());

export const dayKey = (iso: string | Date): string => {
  const d = typeof iso === 'string' ? new Date(iso) : iso;
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
};

export const norm = (s: string): string =>
  s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
