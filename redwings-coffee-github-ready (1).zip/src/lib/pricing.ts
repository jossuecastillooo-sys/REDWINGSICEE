import type { CartLine, Product } from '../types';

export function isAvailable(p: Product | undefined): p is Product {
  return !!p && p.active && !p.soldOut && (p.stock === null || p.stock > 0);
}

/** Precio unitario de una línea: tamaño (o base) + opciones + extras. */
export function unitPrice(p: Product, line: Pick<CartLine, 'sizeId' | 'choices' | 'extras'>): number {
  const size = p.sizes.find((s) => s.id === line.sizeId);
  let price = size ? size.price : p.basePrice;
  for (const g of p.optionGroups) {
    const c = g.choices.find((x) => x.id === line.choices[g.id]);
    if (c) price += c.price;
  }
  for (const ex of p.extras) {
    const q = line.extras[ex.id] || 0;
    if (q > 0 && ex.available) price += ex.price * q;
  }
  return Math.max(0, price);
}

/** Devuelve un mensaje de error si la línea ya no es válida, o null si está bien. */
export function validateLine(p: Product | undefined, line: CartLine): string | null {
  if (!p) return 'Este producto ya no existe.';
  if (!p.active) return p.name + ' ya no está disponible.';
  if (p.soldOut || (p.stock !== null && p.stock <= 0)) return p.name + ' está agotado.';
  if (p.stock !== null && line.qty > p.stock) return 'Solo quedan ' + p.stock + ' de ' + p.name + '.';
  if (!Number.isInteger(line.qty) || line.qty < 1) return 'Cantidad inválida en ' + p.name + '.';
  if (p.sizes.length && !p.sizes.some((s) => s.id === line.sizeId)) return 'Elige un tamaño para ' + p.name + '.';
  for (const g of p.optionGroups) {
    const chosen = line.choices[g.id];
    if (g.required && !g.choices.some((c) => c.id === chosen)) return 'Elige "' + g.name + '" en ' + p.name + '.';
    if (chosen && !g.choices.some((c) => c.id === chosen)) return 'Una opción de ' + p.name + ' cambió. Edita el producto.';
  }
  for (const [id, q] of Object.entries(line.extras)) {
    if (q <= 0) continue;
    const ex = p.extras.find((e) => e.id === id);
    if (!ex || !ex.available) return 'Un extra de ' + p.name + ' ya no está disponible.';
    if (ex.max && q > ex.max) return ex.name + ': máximo ' + ex.max + '.';
  }
  const price = unitPrice(p, line);
  if (!(price >= 0) || !Number.isFinite(price)) return 'Precio inválido en ' + p.name + '.';
  return null;
}

/** Texto corto con las opciones elegidas (para carrito y pedidos). */
export function describeLine(p: Product, line: Pick<CartLine, 'sizeId' | 'choices' | 'extras'>): { size?: string; options: string[]; extras: { name: string; qty: number; price: number }[] } {
  const size = p.sizes.find((s) => s.id === line.sizeId)?.name;
  const options: string[] = [];
  for (const g of p.optionGroups) {
    const c = g.choices.find((x) => x.id === line.choices[g.id]);
    if (c) options.push(g.name + ': ' + c.name);
  }
  const extras = p.extras
    .filter((e) => (line.extras[e.id] || 0) > 0)
    .map((e) => ({ name: e.name, qty: line.extras[e.id], price: e.price }));
  return { size, options, extras };
}
