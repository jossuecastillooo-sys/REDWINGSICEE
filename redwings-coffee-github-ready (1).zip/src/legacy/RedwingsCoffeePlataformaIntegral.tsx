import React, { useEffect, useMemo, useState } from "react";
import "./RedwingsCoffeePlataformaIntegral.css";
type Product = {
  id: string;
  extras?: {
    name: string;
    price: number;
    active: boolean;
  }[];
  milkOptions?: string[];
  name: string;
  category: string;
  price: number;
  cost: number;
  stock: number;
  image: string;
  active: boolean;
  description: string;
  sku: string;
};
type Item = {
  productId: string;
  name: string;
  qty: number;
  price: number;
  cost: number;
  extras?: string[];
  milk?: string;
};
type Order = {
  id: string;
  customer: string;
  career: string;
  section: string;
  phone: string;
  items: Item[];
  total: number;
  status: "Pendiente" | "Confirmado" | "En preparación" | "Listo" | "Completado" | "Cancelado";
  stockDeducted?: boolean;
  date: string;
  notes: string;
  payment: string;
};
type Expense = {
  id: string;
  name: string;
  amount: number;
  category: string;
  date: string;
};
type Supplier = {
  id: string;
  name: string;
  phone: string;
  email: string;
  products: string;
  notes: string;
};
type Recipe = {
  id: string;
  name: string;
  yieldQty: number;
  ingredients: {
    name: string;
    qty: number;
    unit: string;
    cost: number;
  }[];
  price: number;
};
type Staff = {
  id: string;
  name: string;
  role: string;
  phone: string;
  active: boolean;
};
type Customer = {
  name: string;
  phone: string;
  orders: number;
  spent: number;
  points: number;
};
type Promotion = {
  id: string;
  name: string;
  code: string;
  percent: number;
  active: boolean;
  startsAt?: string;
  endsAt?: string;
};
type Campaign = {
  id: string;
  name: string;
  channel: string;
  message: string;
  date: string;
  status: string;
};
const seed: Product[] = [{
  id: "granita",
  name: "Granita tradicional",
  category: "Granitas",
  price: 45,
  cost: 18,
  stock: 24,
  image: "https://images.unsplash.com/photo-1461023058943-07fcbe16d735?auto=format&fit=crop&w=900&q=85",
  active: true,
  description: "Café frío con sabor intenso.",
  sku: "RW-BEB-001"
}, {
  id: "crema",
  name: "Granita con crema",
  category: "Granitas",
  price: 50,
  cost: 22,
  stock: 18,
  image: "https://images.unsplash.com/photo-1517701604599-bb29b565090c?auto=format&fit=crop&w=900&q=85",
  active: true,
  description: "Granita cremosa para una pausa especial.",
  sku: "RW-BEB-002"
}, {
  id: "frappe",
  name: "Frappé con lechera",
  category: "Frappés",
  price: 55,
  cost: 24,
  stock: 16,
  image: "https://images.unsplash.com/photo-1572490122747-3968b75cc699?auto=format&fit=crop&w=900&q=85",
  active: true,
  description: "Frappé de café con leche condensada.",
  sku: "RW-BEB-003"
}, {
  id: "pinguinera",
  name: "Pinguinera",
  category: "Frappés",
  price: 65,
  cost: 30,
  stock: 12,
  image: "https://images.unsplash.com/photo-1461023058943-07fcbe16d735?auto=format&fit=crop&w=900&q=85",
  active: true,
  description: "Especialidad de la casa.",
  sku: "RW-ESP-001"
}, {
  id: "oreo",
  name: "Frappé Oreo",
  category: "Frappés",
  price: 70,
  cost: 33,
  stock: 14,
  image: "https://images.unsplash.com/photo-1572490122747-3968b75cc699?auto=format&fit=crop&w=900&q=85",
  active: true,
  description: "Frappé con galleta de chocolate.",
  sku: "RW-ESP-002"
}, {
  id: "bolis",
  name: "Bolis Oreo largos",
  category: "Bolis",
  price: 30,
  cost: 12,
  stock: 30,
  image: "https://images.unsplash.com/photo-1560008581-09826d1de69e?auto=format&fit=crop&w=900&q=85",
  active: true,
  description: "Postre frío de Oreo.",
  sku: "RW-POS-001"
}, {
  id: "cafe",
  name: "Café tradicional · 1 lb",
  category: "Café",
  price: 150,
  cost: 95,
  stock: 20,
  image: "https://images.unsplash.com/photo-1559056199-641a0ac8b55e?auto=format&fit=crop&w=900&q=85",
  active: true,
  description: "Café tradicional en bolsa de una libra.",
  sku: "RW-CAF-001"
}, {
  id: "pimienta",
  name: "Café con pimienta · 1 lb",
  category: "Café",
  price: 165,
  cost: 105,
  stock: 10,
  image: "https://images.unsplash.com/photo-1447933601403-0c6688de566e?auto=format&fit=crop&w=900&q=85",
  active: true,
  description: "Mezcla especial de café con pimienta.",
  sku: "RW-CAF-002"
}].map(p => ({
  ...p,
  extras: p.category === "Granitas" ? [{
    name: "Crema batida",
    price: 8,
    active: true
  }, {
    name: "Oreo adicional",
    price: 8,
    active: true
  }, {
    name: "Caramelo Hershey’s",
    price: 6,
    active: true
  }, {
    name: "Lechera",
    price: 5,
    active: true
  }] : p.category === "Frappés" ? [{
    name: "Crema batida",
    price: 8,
    active: true
  }, {
    name: "Oreo adicional",
    price: 8,
    active: true
  }, {
    name: "Lechera",
    price: 5,
    active: true
  }, {
    name: "Pinguino",
    price: 5,
    active: true
  }] : p.category === "Bolis" ? [{
    name: "Oreo adicional",
    price: 8,
    active: true
  }] : [],
  milkOptions: ["Granitas", "Frappés"].includes(p.category) ? ["Entera", "Deslactosada", "Descremada"] : []
}));
const nav = [["overview", "Resumen", "⌂"], ["shop", "Tienda", "◈"], ["products", "Productos", "▦"], ["promotions", "Promociones", "％"], ["orders", "Pedidos", "≋"], ["inventory", "Inventario", "▤"], ["finance", "Finanzas", "＄"], ["customers", "Clientes", "♙"], ["marketing", "Marketing", "✳"], ["loyalty", "Fidelización", "☆"], ["staff", "Personal", "♧"], ["suppliers", "Proveedores", "⇄"], ["recipes", "Recetas y costos", "♨"], ["analytics", "Analítica", "⌁"], ["reports", "Informes", "▥"], ["assistant", "Asistente", "✦"], ["settings", "Configuración", "⚙"]];
const money = (n: number) => new Intl.NumberFormat("es-HN", {
  style: "currency",
  currency: "HNL",
  maximumFractionDigits: 2
}).format(n);
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
function load<T>(k: string, f: T): T {
  try {
    const v = localStorage.getItem("rwpro_" + k);
    return v ? JSON.parse(v) : f;
  } catch {
    return f;
  }
}
function saveFile(name: string, content: string, type = "application/json") {
  const u = URL.createObjectURL(new Blob([content], {
    type
  }));
  const a = document.createElement("a");
  a.href = u;
  a.download = name;
  a.click();
  URL.revokeObjectURL(u);
}
export function RedwingsCoffeePlataformaIntegral() {
  const [page, setPage] = useState("shop"),
    [profilePhone, setProfilePhone] = useState(() => load("profilePhone", "")),
    [discountCode, setDiscountCode] = useState(""),
    [deliveryMode, setDeliveryMode] = useState("Recoger en el instituto"),
    [isAdmin, setIsAdmin] = useState(false),
    [adminPassword, setAdminPassword] = useState(""),
    [career, setCareer] = useState(""),
    [heroTitle, setHeroTitle] = useState(() => load("heroTitle", "Tu momento.|Tu café.")),
    [heroText, setHeroText] = useState(() => load("heroText", "Sabores que convierten cualquier pausa en tu momento favorito.")),
    [heroImage, setHeroImage] = useState(() => load("heroImage", "https://images.unsplash.com/photo-1442512595331-e89e73853f31?auto=format&fit=crop&w=1100&q=90")),
    [section, setSection] = useState(""),
    [products, setProducts] = useState<Product[]>(() => load("products", seed)),
    [orders, setOrders] = useState<Order[]>(() => load("orders", [])),
    [expenses, setExpenses] = useState<Expense[]>(() => load("expenses", [])),
    [suppliers, setSuppliers] = useState<Supplier[]>(() => load("suppliers", [])),
    [recipes, setRecipes] = useState<Recipe[]>(() => load("recipes", [])),
    [staff, setStaff] = useState<Staff[]>(() => load("staff", [])),
    [campaigns, setCampaigns] = useState<Campaign[]>(() => load("campaigns", [])),
    [promotions, setPromotions] = useState<Promotion[]>(() => load("promotions", [{
      id: "welcome10",
      name: "Descuento de bienvenida",
      code: "REDWINGS10",
      percent: 10,
      active: true
    }])),
    [selectedExtras, setSelectedExtras] = useState<Record<string, string[]>>({}),
    [selectedMilk, setSelectedMilk] = useState<Record<string, string>>({}),
    [cart, setCart] = useState<Record<string, number>>({}),
    [search, setSearch] = useState(""),
    [cat, setCat] = useState("Todos"),
    [customer, setCustomer] = useState(""),
    [phone, setPhone] = useState(""),
    [notes, setNotes] = useState(""),
    [payment, setPayment] = useState("Efectivo al recoger"),
    [filter, setFilter] = useState("Todos"),
    [toast, setToast] = useState(""),
    [queryCustomer, setQueryCustomer] = useState(""),
    [campaignName, setCampaignName] = useState("Promo de la semana"),
    [campaign, setCampaign] = useState("Tu pausa favorita empieza con Redwings Coffee."),
    [campaignChannel, setCampaignChannel] = useState("WhatsApp"),
    [newName, setNewName] = useState(""),
    [newPrice, setNewPrice] = useState(""),
    [newCost, setNewCost] = useState(""),
    [newStock, setNewStock] = useState(""),
    [newCat, setNewCat] = useState("Bebidas frías"),
    [newSku, setNewSku] = useState(""),
    [newDesc, setNewDesc] = useState(""),
    [newImage, setNewImage] = useState(""),
    [newExtras, setNewExtras] = useState("Crema batida:8, Oreo adicional:8, Lechera:5"),
    [promoName, setPromoName] = useState("Promoción especial"),
    [promoCode, setPromoCode] = useState(""),
    [promoPercent, setPromoPercent] = useState("10"),
    [expenseName, setExpenseName] = useState(""),
    [expenseAmount, setExpenseAmount] = useState(""),
    [expenseCategory, setExpenseCategory] = useState("Insumos"),
    [supplierName, setSupplierName] = useState(""),
    [supplierPhone, setSupplierPhone] = useState(""),
    [supplierEmail, setSupplierEmail] = useState(""),
    [supplierProducts, setSupplierProducts] = useState(""),
    [staffName, setStaffName] = useState(""),
    [staffRole, setStaffRole] = useState("Ventas"),
    [staffPhone, setStaffPhone] = useState(""),
    [recipeName, setRecipeName] = useState(""),
    [recipeYield, setRecipeYield] = useState("1"),
    [recipePrice, setRecipePrice] = useState(""),
    [recipeIngredients, setRecipeIngredients] = useState("Café,1,porción,12"),
    [firebaseUrl, setFirebaseUrl] = useState(() => load("firebaseUrl", "")),
    [firebaseStatus, setFirebaseStatus] = useState("No conectado"),
    [firebaseBusy, setFirebaseBusy] = useState(false),
    [editId, setEditId] = useState(""),
    [dateFrom, setDateFrom] = useState(""),
    [dateTo, setDateTo] = useState(""),
    [showHelp, setShowHelp] = useState(false);
  useEffect(() => {
    const pairs: {
      [k: string]: unknown;
    } = {
      products,
      orders,
      expenses,
      suppliers,
      recipes,
      staff,
      campaigns,
      promotions,
      firebaseUrl,
      heroTitle,
      heroText,
      heroImage
    };
    Object.entries(pairs).forEach(([k, v]) => localStorage.setItem("rwpro_" + k, JSON.stringify(v)));
  }, [products, orders, expenses, suppliers, recipes, staff, campaigns, promotions, firebaseUrl]);
  const active = products.filter(p => p.active),
    categories = ["Todos", ...Array.from(new Set(active.map(p => p.category)))],
    shown = active.filter(p => (cat === "Todos" || p.category === cat) && (p.name + " " + p.description + " " + p.sku).toLowerCase().includes(search.toLowerCase())),
    items: Item[] = products.filter(p => cart[p.id]).map(p => {
      const extras = (p.extras || []).filter(x => x.active && (selectedExtras[p.id] || []).includes(x.name));
      return {
        productId: p.id,
        name: p.name,
        qty: cart[p.id],
        price: p.price + extras.reduce((s, x) => s + x.price, 0),
        cost: p.cost,
        extras: extras.map(x => x.name),
        milk: selectedMilk[p.id] || ""
      };
    }),
    total = items.reduce((s, p) => s + p.qty * p.price, 0),
    pending = orders.filter(o => ["Pendiente", "Confirmado", "En preparación", "Listo"].includes(o.status)).length,
    completed = orders.filter(o => o.status === "Completado"),
    revenue = completed.reduce((s, o) => s + o.total, 0),
    expenseTotal = expenses.reduce((s, e) => s + e.amount, 0),
    costOfSales = completed.reduce((s, o) => s + o.items.reduce((a, i) => a + i.qty * i.cost, 0), 0),
    grossProfit = revenue - costOfSales,
    netProfit = grossProfit - expenseTotal,
    low = products.filter(p => p.stock <= 5 && p.active).length,
    allSales = orders.reduce((s, o) => s + o.total, 0);
  const alert = (s: string) => {
      setToast(s);
      window.setTimeout(() => setToast(""), 3200);
    },
    go = (p: string) => {
      setPage(p);
      setSearch("");
    };
  const add = (id: string) => {
    const p = products.find(x => x.id === id);
    if (!p || p.stock < 1) {
      alert("Producto agotado.");
      return;
    }
    setCart(c => ({
      ...c,
      [id]: Math.min(p.stock, (c[id] || 0) + 1)
    }));
  };
  const updateQty = (id: string, qty: number) => setCart(c => ({
    ...c,
    [id]: Math.max(0, Math.min(products.find(p => p.id === id)?.stock || 99, qty))
  }));
  const changeOrderStatus = (orderId: string, status: Order["status"]) => {
    const order = orders.find(o => o.id === orderId);
    if (!order) return;
    if (status === "Completado" && order.status !== "Completado" && !order.stockDeducted) {
      const shortages = order.items.filter(item => {
        const p = products.find(x => x.id === item.productId);
        return !p || p.stock < item.qty;
      });
      if (shortages.length) {
        alert("Inventario insuficiente para: " + shortages.map(x => x.name).join(", "));
        return;
      }
      setProducts(current => current.map(p => {
        const sold = order.items.find(i => i.productId === p.id);
        return sold ? {
          ...p,
          stock: p.stock - sold.qty
        } : p;
      }));
      setOrders(current => current.map(o => o.id === orderId ? {
        ...o,
        status,
        stockDeducted: true
      } : o));
      alert("Pedido completado e inventario descontado.");
      return;
    }
    if (order.stockDeducted && status !== "Completado") alert("El inventario ya fue descontado; cambiar el estado no lo revierte.");
    setOrders(current => current.map(o => o.id === orderId ? {
      ...o,
      status
    } : o));
  };
  const validPromotion = promotions.find(p => p.active && p.code.trim().toUpperCase() === discountCode.trim().toUpperCase() && (!p.startsAt || new Date(p.startsAt) <= new Date()) && (!p.endsAt || new Date(p.endsAt) >= new Date()));
  const discountAmount = validPromotion ? total * Math.min(100, Math.max(0, validPromotion.percent)) / 100 : 0;
  const finalTotal = Math.max(0, total - discountAmount);
  const checkout = () => {
    if (!items.length || !customer.trim() || !career.trim() || !section.trim() || !phone.trim()) {
      alert("Completa el nombre, la carrera, la sección y el carrito.");
      return;
    }
    const order: Order = {
      id: "RW-" + Date.now().toString().slice(-8),
      customer: customer.trim(),
      career: career.trim(),
      section: section.trim(),
      phone: phone.trim(),
      items,
      total: finalTotal,
      status: "Pendiente",
      date: new Date().toISOString(),
      notes,
      payment: payment + " · " + deliveryMode
    };
    setOrders(o => [order, ...o]);
    const msg = "Hola Redwings Coffee, quiero hacer un pedido para recoger.\nPedido: " + order.id + "\nNombre: " + order.customer + "\nCarrera: " + order.career + "\nSección: " + order.section + (order.phone ? "\nTeléfono: " + order.phone : "") + "\n" + items.map(i => "• " + i.qty + " x " + i.name + (i.extras?.length ? " + " + i.extras.join(", ") : "") + (i.milk ? " · Leche " + i.milk : "") + " = " + money(i.qty * i.price)).join("\n") + "\nSubtotal: " + money(total) + "\nDescuento: -" + money(discountAmount) + "\nTotal a pagar: " + money(finalTotal) + "\nPago: " + payment + "\nEntrega: " + deliveryMode + (notes ? "\nNotas: " + notes : "");
    window.open("https://wa.me/50492899752?text=" + encodeURIComponent(msg), "_blank");
    setCart({});
    setCustomer("");
    setCareer("");
    setSection("");
    setPhone("");
    setNotes("");
    alert("Pedido guardado en este navegador. Confirma la recepción por WhatsApp.");
  };
  const createPromotion = () => {
    const code = promoCode.trim().toUpperCase().replace(/\\s+/g, "");
    const percent = Number(promoPercent);
    if (!promoName.trim() || !code || percent <= 0 || percent > 100) {
      alert("Completa nombre, código y un descuento entre 1 y 100%.");
      return;
    }
    setPromotions(current => [{
      id: uid(),
      name: promoName.trim(),
      code,
      percent,
      active: true
    }, ...current.filter(p => p.code !== code)]);
    setPromoName("Promoción especial");
    setPromoCode("");
    setPromoPercent("10");
    alert("Promoción creada y disponible en la tienda.");
  };
  const addProduct = () => {
    if (!newName.trim() || Number(newPrice) <= 0) {
      alert("Nombre y precio válido son obligatorios.");
      return;
    }
    const p: Product = {
      id: editId || uid(),
      name: newName.trim(),
      category: newCat,
      price: Number(newPrice),
      cost: Number(newCost) || 0,
      stock: Math.max(0, Number(newStock) || 0),
      image: newImage || "https://images.unsplash.com/photo-1442512595331-e89e73853f31?auto=format&fit=crop&w=900&q=85",
      active: true,
      description: newDesc,
      extras: newExtras.split(",").map(part => {
        const [name, price] = part.split(":");
        return {
          name: (name || "").trim(),
          price: Number(price) || 0,
          active: true
        };
      }).filter(x => x.name && x.price >= 0),
      milkOptions: ["Granitas", "Frappés"].includes(newCat) ? ["Entera", "Deslactosada", "Descremada"] : [],
      sku: newSku || "RW-" + Date.now().toString().slice(-6)
    };
    setProducts(old => editId ? old.map(x => x.id === editId ? {
      ...p,
      active: x.active
    } : x) : [p, ...old]);
    setEditId("");
    setNewName("");
    setNewPrice("");
    setNewCost("");
    setNewStock("");
    setNewSku("");
    setNewDesc("");
    setNewImage("");
    setNewExtras("Crema batida:8, Oreo adicional:8, Lechera:5");
    alert(editId ? "Producto actualizado." : "Producto creado.");
  };
  const editProduct = (p: Product) => {
    setEditId(p.id);
    setNewName(p.name);
    setNewPrice(String(p.price));
    setNewCost(String(p.cost));
    setNewStock(String(p.stock));
    setNewCat(p.category);
    setNewSku(p.sku);
    setNewDesc(p.description);
    setNewImage(p.image);
    setNewExtras((p.extras || []).map(x => x.name + ":" + x.price).join(", "));
    window.scrollTo({
      top: 0,
      behavior: "smooth"
    });
  };
  const addExpense = () => {
    if (!expenseName.trim() || Number(expenseAmount) <= 0) {
      alert("Completa descripción y monto.");
      return;
    }
    setExpenses(e => [{
      id: uid(),
      name: expenseName,
      amount: Number(expenseAmount),
      category: expenseCategory,
      date: new Date().toISOString()
    }, ...e]);
    setExpenseName("");
    setExpenseAmount("");
    alert("Gasto registrado.");
  };
  const addSupplier = () => {
    if (!supplierName.trim()) {
      alert("Introduce el nombre del proveedor.");
      return;
    }
    setSuppliers(s => [{
      id: uid(),
      name: supplierName,
      phone: supplierPhone,
      email: supplierEmail,
      products: supplierProducts,
      notes: ""
    }, ...s]);
    setSupplierName("");
    setSupplierPhone("");
    setSupplierEmail("");
    setSupplierProducts("");
    alert("Proveedor guardado.");
  };
  const addStaff = () => {
    if (!staffName.trim()) {
      alert("Introduce el nombre.");
      return;
    }
    setStaff(s => [{
      id: uid(),
      name: staffName,
      role: staffRole,
      phone: staffPhone,
      active: true
    }, ...s]);
    setStaffName("");
    setStaffPhone("");
    alert("Miembro añadido.");
  };
  const addRecipe = () => {
    if (!recipeName.trim() || Number(recipePrice) <= 0) {
      alert("Nombre y precio de venta son obligatorios.");
      return;
    }
    const ingredients = recipeIngredients.split("\n").map(line => {
      const a = line.split(",");
      return {
        name: (a[0] || "Ingrediente").trim(),
        qty: Number(a[1]) || 1,
        unit: (a[2] || "unidad").trim(),
        cost: Number(a[3]) || 0
      };
    });
    setRecipes(r => [{
      id: uid(),
      name: recipeName,
      yieldQty: Math.max(1, Number(recipeYield) || 1),
      ingredients,
      price: Number(recipePrice)
    }, ...r]);
    setRecipeName("");
    setRecipeYield("1");
    setRecipePrice("");
    setRecipeIngredients("Café,1,porción,12");
    alert("Receta y costo base guardados.");
  };
  const exportData = () => saveFile("redwings-respaldo-" + new Date().toISOString().slice(0, 10) + ".json", JSON.stringify({
    version: 2,
    exportedAt: new Date().toISOString(),
    products,
    orders,
    expenses,
    suppliers,
    recipes,
    staff,
    campaigns
  }, null, 2));
  const importData = (file: File) => {
    const r = new FileReader();
    r.onload = () => {
      try {
        const d = JSON.parse(String(r.result));
        if (!d || !Array.isArray(d.products) || !Array.isArray(d.orders)) throw Error("Formato");
        if (!confirm("Esto reemplazará los datos actuales por el respaldo seleccionado. ¿Continuar?")) return;
        setProducts(d.products);
        setOrders(d.orders);
        setExpenses(d.expenses || []);
        setSuppliers(d.suppliers || []);
        setRecipes(d.recipes || []);
        setStaff(d.staff || []);
        setCampaigns(d.campaigns || []);
        alert("Respaldo restaurado.");
      } catch {
        alert("Archivo inválido o incompatible.");
      }
    };
    r.readAsText(file);
  };
  const connectFirebase = async () => {
    let url = firebaseUrl.trim().replace(/\/$/, "");
    if (!/^https:\/\/.+\.firebasedatabase\.app$|^https:\/\/.+\.firebaseio\.com$/.test(url)) {
      alert("Pega la URL exacta de Realtime Database, por ejemplo https://proyecto-default-rtdb.firebaseio.com");
      return;
    }
    setFirebaseBusy(true);
    try {
      const r = await fetch(url + "/redwings/health.json");
      if (!r.ok) throw Error("No se pudo leer la base. Revisa reglas y URL.");
      setFirebaseStatus("Conectado · prueba de lectura correcta");
      alert("Firebase responde. Aún debes configurar reglas seguras y la sincronización de cada módulo.");
    } catch (e) {
      setFirebaseStatus("Error de conexión");
      alert(e instanceof Error ? e.message : "No se pudo conectar. Revisa la URL y las reglas de Firebase.");
    } finally {
      setFirebaseBusy(false);
    }
  };
  const syncFirebase = async () => {
    let url = firebaseUrl.trim().replace(/\/$/, "");
    if (!url) {
      alert("Primero configura la URL de Firebase.");
      return;
    }
    if (!confirm("La sincronización enviará el catálogo, pedidos y datos administrativos actuales a la ruta /redwings. ¿Continuar?")) return;
    setFirebaseBusy(true);
    try {
      const payload = {
        products,
        orders,
        expenses,
        suppliers,
        recipes,
        staff,
        campaigns,
        updatedAt: new Date().toISOString()
      };
      const r = await fetch(url + "/redwings.json", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
      });
      if (!r.ok) throw Error("Firebase rechazó la escritura. Comprueba las reglas.");
      setFirebaseStatus("Sincronizado · " + new Date().toLocaleTimeString("es-HN"));
      alert("Datos enviados a Firebase. No es sincronización automática entre usuarios; requiere autenticación y reglas adecuadas.");
    } catch (e) {
      setFirebaseStatus("Error al sincronizar");
      alert(e instanceof Error ? e.message : "No se pudo sincronizar.");
    } finally {
      setFirebaseBusy(false);
    }
  };
  const filteredOrders = orders.filter(o => (filter === "Todos" || o.status === filter) && (!dateFrom || o.date.slice(0, 10) >= dateFrom) && (!dateTo || o.date.slice(0, 10) <= dateTo));
  const customers: Customer[] = useMemo(() => {
    const m = new Map<string, Customer>();
    orders.forEach(o => {
      const k = o.phone.trim();
      if (!k) return;
      const c = m.get(k) || {
        name: o.customer,
        phone: k,
        orders: 0,
        spent: 0,
        points: 0
      };
      c.orders++;
      if (o.status !== "Cancelado") c.spent += o.total;
      if (o.status === "Completado") c.points += Math.floor(o.total / 10);
      m.set(k, c);
    });
    return Array.from(m.values()).sort((a, b) => b.spent - a.spent);
  }, [orders]);
  const createCampaign = () => {
    if (!campaignName.trim() || !campaign.trim()) {
      alert("Completa el nombre y el mensaje.");
      return;
    }
    setCampaigns(c => [{
      id: uid(),
      name: campaignName,
      channel: campaignChannel,
      message: campaign,
      date: new Date().toISOString(),
      status: "Borrador"
    }, ...c]);
    alert("Campaña guardada como borrador.");
  };
  const view = () => {
    if (page === "login") return <section className="rw-login"><span className="rw-kicker">REDWINGS COFFEE · ACCESO RESTRINGIDO</span><h1>Panel administrativo</h1><p>Accede para gestionar pedidos, productos, inventario y reportes.</p><form onSubmit={e => {
        e.preventDefault();
        if (adminPassword === "1986") {
          setIsAdmin(true);
          setPage("overview");
          setAdminPassword("");
          setToast("Sesión administrativa iniciada");
        } else {
          setToast("Contraseña incorrecta");
        }
      }}><label htmlFor="rw-admin-password">Contraseña de acceso</label><input id="rw-admin-password" type="password" autoComplete="current-password" value={adminPassword} onChange={e => setAdminPassword(e.target.value)} placeholder="Introduce la contraseña" required /><button className="rw-primary" type="submit">Entrar al panel</button></form><small>El acceso actual es una barrera básica del navegador. Antes de publicar con datos reales, debe sustituirse por autenticación segura del servidor.</small><button className="rw-secondary" onClick={() => {
        setPage("shop");
        setAdminPassword("");
      }}>← Volver a la tienda</button></section>;
    if (!isAdmin && !["shop", "discounts", "cart", "profile", "myorders"].includes(page)) return <section className="rw-login"><span className="rw-kicker">REDWINGS COFFEE</span><h1>Área privada</h1><p>Esta sección es exclusiva para administración.</p><button className="rw-primary" onClick={() => setPage("login")}>Iniciar sesión</button><button className="rw-secondary" onClick={() => setPage("shop")}>Volver a la tienda</button></section>;
    if (page === "profile") return <><div className="rw-heading"><div><span className="rw-kicker">MI CUENTA</span><h2>Perfil</h2><p>Consulta tu actividad y puntos acumulados.</p></div></div><section className="rw-panel rw-form"><label>Teléfono de tu cuenta</label><input value={profilePhone} onChange={e => {
          setProfilePhone(e.target.value);
          localStorage.setItem("rwpro_profilePhone", JSON.stringify(e.target.value));
        }} placeholder="Tu número de teléfono" />{customers.filter(c => c.phone.replace(/\D/g, "") === profilePhone.replace(/\D/g, "")).map(c => <div className="rw-stats"><div><small>Pedidos</small><b>{c.orders}</b></div><div><small>Compras</small><b>{money(c.spent)}</b></div><div><small>Puntos</small><b>{c.points}</b></div></div>)}<p className="rw-note">Los datos se consultan desde los pedidos de este dispositivo. La cuenta compartida requiere Firebase Authentication.</p></section></>;
    if (page === "myorders") return <><div className="rw-heading"><div><span className="rw-kicker">SEGUIMIENTO</span><h2>Mis pedidos</h2></div></div><section className="rw-panel rw-form"><input value={profilePhone} onChange={e => setProfilePhone(e.target.value)} placeholder="Filtrar por teléfono" />{orders.filter(o => !profilePhone || o.phone.replace(/\D/g, "") === profilePhone.replace(/\D/g, "")).map(o => <article className="rw-order" key={o.id}><div className="rw-orderhead"><div><span className="rw-kicker">{o.id}</span><h3>{o.status}</h3></div><b>{money(o.total)}</b></div><p>{o.items.map(i => i.qty + " × " + i.name + (i.extras?.length ? " + " + i.extras.join(", ") : "") + (i.milk ? " · " + i.milk : "")).join(", ")}</p><small>{new Date(o.date).toLocaleString("es-HN")}</small></article>)}</section></>;
    if (page === "discounts") return <><div className="rw-heading"><div><span className="rw-kicker">BENEFICIOS</span><h2>Promociones</h2><p>Ofertas activas para tu próxima compra.</p></div></div>{promotions.filter(p => p.active).map(p => <section className="rw-panel rw-promo-card" key={p.id}><span className="rw-kicker">PROMOCIÓN ACTIVA · {p.percent}% OFF</span><h2>{p.code}</h2><h3>{p.name}</h3><p>Introduce este código en tu carrito para aplicar el descuento.</p><button className="rw-secondary" onClick={() => {
          navigator.clipboard?.writeText(p.code);
          setDiscountCode(p.code);
          alert("Código copiado y listo para aplicar.");
        }}>Copiar código</button></section>)}{!promotions.some(p => p.active) && <div className="rw-empty">No hay promociones activas en este momento.</div>}</>;
    if (page === "cart") return <><div className="rw-heading"><div><span className="rw-kicker">TU COMPRA</span><h2>Carrito</h2><p>Revisa tus productos y completa los datos para pedir.</p></div></div><section className="rw-panel rw-form"><h3>Productos</h3>{items.length ? items.map(p => <div className="rw-cart-line" key={p.productId}><div><b>{p.name}</b><small>{money(p.price)} c/u</small></div><input aria-label={"Cantidad " + p.name} className="rw-qty" type="number" min="0" value={p.qty} onChange={e => updateQty(p.productId, Number(e.target.value))} /><strong>{money(p.qty * p.price)}</strong><button className="rw-link" onClick={() => updateQty(p.productId, 0)}>Quitar</button></div>) : <div className="rw-empty"><p>Tu carrito está vacío.</p><button className="rw-primary" onClick={() => go("shop")}>Volver a la tienda</button></div>}<div className="rw-cart-totals"><p>Subtotal <b>{money(total)}</b></p>{discountAmount > 0 && <p>Descuento <b>-{money(discountAmount)}</b></p>}<h2>Total <b>{money(finalTotal)}</b></h2></div><h3>Datos para recoger</h3><input required value={customer} onChange={e => setCustomer(e.target.value)} placeholder="Nombre completo *" /><input required value={career} onChange={e => setCareer(e.target.value)} placeholder="Carrera *" /><input required value={section} onChange={e => setSection(e.target.value)} placeholder="Sección *" /><input required value={phone} onChange={e => setPhone(e.target.value)} placeholder="Teléfono *" /><select value={deliveryMode} onChange={e => setDeliveryMode(e.target.value)}><option>Recoger en el instituto</option><option>Entrega coordinada</option></select><input value={discountCode} onChange={e => setDiscountCode(e.target.value.toUpperCase())} placeholder="Código de descuento" /><select value={payment} onChange={e => setPayment(e.target.value)}><option>Efectivo al recoger</option><option>Transferencia por confirmar</option><option>Otro método por acordar</option></select><textarea rows={3} value={notes} onChange={e => setNotes(e.target.value)} placeholder="Notas del pedido (opcional)" /><button className="rw-primary rw-checkout-submit" onClick={checkout} disabled={!items.length}>Crear pedido y abrir WhatsApp ↗</button><small>* Nombre, carrera, sección y teléfono son obligatorios. Los pedidos se guardan localmente en este dispositivo.</small></section></>;
    if (page === "shop") return <><section className="rw-hero"><div><span className="rw-kicker">CAFÉ CON PERSONALIDAD</span><h1>{heroTitle.split("|")[0]}<br /><i>{heroTitle.split("|")[1] || "Tu café."}</i></h1><p>{heroText}</p><button className="rw-primary" onClick={() => document.getElementById("rw-catalog")?.scrollIntoView({
            behavior: "smooth"
          })}>Explorar menú ↓</button></div><img src={heroImage} alt="Portada Redwings Coffee" /></section><div id="rw-catalog" className="rw-controls"><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar café, categoría o SKU..." /><select value={cat} onChange={e => setCat(e.target.value)}>{categories.map(c => <option key={c}>{c}</option>)}</select></div><div className="rw-products">{shown.map(p => <article className="rw-product" key={p.id}><div className="rw-photo"><img src={p.image} alt={p.name} onError={e => {
              e.currentTarget.src = "https://images.unsplash.com/photo-1442512595331-e89e73853f31?auto=format&fit=crop&w=900&q=85";
            }} /><span>{p.category}</span></div><div className="rw-productbody"><h3>{p.name}</h3><p>{p.description}</p>{((p.extras || []).some(x => x.active) || (p.milkOptions || []).length > 0) && <details className="rw-customizer"><summary>Personalizar producto</summary>{(p.extras || []).filter(x => x.active).map(x => <label key={x.name}><input type="checkbox" checked={(selectedExtras[p.id] || []).includes(x.name)} onChange={e => setSelectedExtras(current => ({
                  ...current,
                  [p.id]: e.target.checked ? [...(current[p.id] || []), x.name] : (current[p.id] || []).filter(n => n !== x.name)
                }))} /><span>{x.name}</span><b>+{money(x.price)}</b></label>)}{(p.milkOptions || []).length > 0 && <select aria-label="Tipo de leche" value={selectedMilk[p.id] || ""} onChange={e => setSelectedMilk(current => ({
                ...current,
                [p.id]: e.target.value
              }))}><option value="">Leche normal</option>{p.milkOptions!.map(m => <option key={m}>{m}</option>)}</select>}</details>}<div className="rw-price"><b>{money(p.price)}</b><button onClick={() => add(p.id)} disabled={p.stock < 1}>{p.stock < 1 ? "Agotado" : "＋ Añadir"}</button></div><small>{p.stock} disponibles</small></div></article>)}</div><section className="rw-cart-cta"><div><span className="rw-kicker">TU PEDIDO</span><h2>¿Listo para tu momento de café?</h2><p>{items.reduce((s, p) => s + p.qty, 0)} artículos · Total {money(finalTotal)}</p></div><button className="rw-primary" onClick={() => go("cart")}>Ir al carrito y finalizar ↗</button></section><button className="rw-floating-cart" onClick={() => go("cart")} aria-label="Abrir carrito"><span>◈</span><b>Carrito</b><em>{items.reduce((s, p) => s + p.qty, 0)}</em></button></>;
    if (page === "promotions") return <><div className="rw-heading"><div><span className="rw-kicker">VENTAS</span><h2>Promociones y descuentos</h2><p>Crea códigos promocionales y controla cuáles aparecen en la tienda.</p></div></div><div className="rw-formgrid"><input value={promoName} onChange={e => setPromoName(e.target.value)} placeholder="Nombre de promoción" /><input value={promoCode} onChange={e => setPromoCode(e.target.value.toUpperCase())} placeholder="Código, por ejemplo VERANO15" /><input type="number" min="1" max="100" value={promoPercent} onChange={e => setPromoPercent(e.target.value)} placeholder="Descuento %" /><button className="rw-primary" onClick={createPromotion}>＋ Crear promoción</button></div>{promotions.map(p => <article className="rw-order" key={p.id}><div className="rw-orderhead"><div><span className="rw-kicker">{p.code}</span><h3>{p.name}</h3></div><b>{p.percent}%</b></div><div className="rw-controls"><span className="rw-pill">{p.active ? "Activa" : "Pausada"}</span><button className="rw-secondary" onClick={() => setPromotions(ps => ps.map(x => x.id === p.id ? {
            ...x,
            active: !x.active
          } : x))}>{p.active ? "Pausar" : "Activar"}</button><button className="rw-link" onClick={() => setPromotions(ps => ps.filter(x => x.id !== p.id))}>Eliminar</button></div></article>)}</>;
    if (page === "products") return <><div className="rw-heading"><div><span className="rw-kicker">CATÁLOGO</span><h2>{editId ? "Editar producto" : "Gestión de productos"}</h2><p>SKU, precio, costo, existencias, imágenes y visibilidad.</p></div></div><div className="rw-formgrid rw-productform"><input value={newName} onChange={e => setNewName(e.target.value)} placeholder="Nombre del producto" /><input type="number" value={newPrice} onChange={e => setNewPrice(e.target.value)} placeholder="Precio de venta L" /><input type="number" value={newCost} onChange={e => setNewCost(e.target.value)} placeholder="Costo unitario L" /><input type="number" value={newStock} onChange={e => setNewStock(e.target.value)} placeholder="Existencias" /><select value={newCat} onChange={e => setNewCat(e.target.value)}>{["Bebidas frías", "Especiales", "Postres fríos", "Café empacado", "Combos", "Insumos", "Otros"].map(c => <option key={c}>{c}</option>)}</select><input value={newSku} onChange={e => setNewSku(e.target.value)} placeholder="SKU / código" /><input value={newImage} onChange={e => setNewImage(e.target.value)} placeholder="URL de imagen (opcional)" /><label className="rw-upload">Subir foto desde el teléfono<input type="file" accept="image/*" onChange={e => {
            const file = e.target.files?.[0];
            if (file) {
              if (file.size > 650000) {
                setToast("Imagen demasiado grande. Elige una menor de 650 KB.");
                return;
              }
              const reader = new FileReader();
              reader.onload = () => setNewImage(String(reader.result));
              reader.readAsDataURL(file);
            }
            e.currentTarget.value = "";
          }} /></label><input value={newDesc} onChange={e => setNewDesc(e.target.value)} placeholder="Descripción" /><input value={newExtras} onChange={e => setNewExtras(e.target.value)} placeholder="Extras: Crema batida:8, Oreo:8, Lechera:5" /><small className="rw-note">Los extras se separan por coma y usan formato nombre:precio. Las leches se habilitan automáticamente para Granitas y Frappés.</small><button className="rw-primary" onClick={addProduct}>{editId ? "Guardar cambios" : "＋ Crear producto"}</button>{editId && <button className="rw-secondary" onClick={() => {
          setEditId("");
          setNewName("");
          setNewPrice("");
          setNewCost("");
          setNewStock("");
          setNewSku("");
          setNewDesc("");
          setNewImage("");
        }}>Cancelar edición</button>}</div><div className="rw-controls"><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Filtrar catálogo..." /><button className="rw-secondary" onClick={() => saveFile("redwings-productos.csv", ["SKU,Nombre,Categoría,Precio,Costo,Stock,Activo", ...products.map(p => [p.sku, '"' + p.name.replace(/"/g, '""') + '"', p.category, p.price, p.cost, p.stock, p.active].join(","))].join("\n"), "text/csv")}>Exportar CSV</button></div><div className="rw-tablewrap"><table><thead><tr><th>Producto</th><th>Precio</th><th>Costo</th><th>Margen</th><th>Stock</th><th>Visible</th><th>Acciones</th></tr></thead><tbody>{products.filter(p => (p.name + " " + p.sku).toLowerCase().includes(search.toLowerCase())).map(p => <tr key={p.id}><td><b>{p.name}</b><small className="rw-block">{p.sku} · {p.category}</small></td><td>{money(p.price)}</td><td>{money(p.cost)}</td><td>{money(p.price - p.cost)}</td><td><input className="rw-stock" type="number" min="0" value={p.stock} onChange={e => setProducts(ps => ps.map(x => x.id === p.id ? {
                  ...x,
                  stock: Math.max(0, Number(e.target.value))
                } : x))} /></td><td><button className="rw-pill" onClick={() => setProducts(ps => ps.map(x => x.id === p.id ? {
                  ...x,
                  active: !x.active
                } : x))}>{p.active ? "Activo" : "Oculto"}</button></td><td><button className="rw-link" onClick={() => editProduct(p)}>Editar</button><button className="rw-link" onClick={() => {
                  if (confirm("¿Eliminar " + p.name + "?")) setProducts(ps => ps.filter(x => x.id !== p.id));
                }}>Eliminar</button></td></tr>)}</tbody></table></div></>;
    if (page === "orders") return <><div className="rw-heading"><div><span className="rw-kicker">OPERACIONES</span><h2>Pedidos</h2><p>Gestiona estados, contacto y rangos de fechas.</p></div><button className="rw-secondary" onClick={() => saveFile("redwings-pedidos.csv", ["Pedido,Fecha,Cliente,Teléfono,Estado,Total,Artículos", ...orders.map(o => [o.id, o.date, o.customer, o.phone, o.status, o.total, '"' + o.items.map(i => i.qty + "x " + i.name).join("; ") + '"'].join(","))].join("\n"), "text/csv")}>Exportar CSV</button></div><div className="rw-controls"><select value={filter} onChange={e => setFilter(e.target.value)}>{["Todos", "Pendiente", "Confirmado", "En preparación", "Listo", "Completado", "Cancelado"].map(s => <option key={s}>{s}</option>)}</select><label>Desde <input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)} /></label><label>Hasta <input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)} /></label></div>{filteredOrders.map(o => <article className="rw-order" key={o.id}><div className="rw-orderhead"><div><span className="rw-kicker">{o.id}</span><h3>{o.customer}</h3><small>{new Date(o.date).toLocaleString("es-HN")} · {o.phone}</small></div><b>{money(o.total)}</b></div><p>{o.items.map(i => i.qty + " × " + i.name + " (" + money(i.price) + ")").join(", ")}</p>{o.notes && <p>Nota: {o.notes}</p>}<div className="rw-controls"><select value={o.status} onChange={e => changeOrderStatus(o.id, e.target.value as Order["status"])}>{["Pendiente", "Confirmado", "En preparación", "Listo", "Completado", "Cancelado"].map(s => <option key={s}>{s}</option>)}</select><button className="rw-secondary" onClick={() => window.open("https://wa.me/" + o.phone.replace(/\D/g, ""), "_blank")}>Contactar ↗</button><button className="rw-link" onClick={() => saveFile(o.id + ".json", JSON.stringify(o, null, 2))}>Ficha</button><button className="rw-link" onClick={() => {
            if (confirm("¿Eliminar el registro de pedido?")) setOrders(os => os.filter(x => x.id !== o.id));
          }}>Eliminar</button></div></article>)}{!filteredOrders.length && <div className="rw-empty">No hay pedidos con estos filtros.</div>}</>;
    if (page === "inventory") return <><div className="rw-heading"><div><span className="rw-kicker">EXISTENCIAS</span><h2>Inventario y reposición</h2><p>{low} productos activos con cinco unidades o menos.</p></div><button className="rw-secondary" onClick={() => saveFile("redwings-inventario.csv", ["SKU,Producto,Stock,Costo,Valor de inventario,Estado", ...products.map(p => [p.sku, p.name, p.stock, p.cost, p.stock * p.cost, p.stock === 0 ? "Agotado" : p.stock <= 5 ? "Reponer" : "Disponible"].join(","))].join("\n"), "text/csv")}>Exportar inventario</button></div><div className="rw-stats"><div><small>Unidades totales</small><b>{products.reduce((s, p) => s + p.stock, 0)}</b></div><div><small>Valor al costo</small><b>{money(products.reduce((s, p) => s + p.stock * p.cost, 0))}</b></div><div><small>Agotados</small><b>{products.filter(p => p.stock === 0).length}</b></div><div><small>Reponer</small><b>{low}</b></div></div><div className="rw-tablewrap"><table><thead><tr><th>Producto</th><th>Stock</th><th>Estado</th><th>Valor en stock</th><th>Actualizar</th></tr></thead><tbody>{products.map(p => <tr key={p.id}><td>{p.name}</td><td>{p.stock}</td><td>{p.stock === 0 ? "Agotado" : p.stock <= 5 ? "Reponer" : "Disponible"}</td><td>{money(p.stock * p.cost)}</td><td><button className="rw-link" onClick={() => {
                  const n = prompt("Nuevo stock para " + p.name, String(p.stock));
                  if (n !== null && Number(n) >= 0) setProducts(ps => ps.map(x => x.id === p.id ? {
                    ...x,
                    stock: Number(n)
                  } : x));
                }}>Ajustar</button></td></tr>)}</tbody></table></div></>;
    if (page === "finance") return <><div className="rw-heading"><div><span className="rw-kicker">CONTROL FINANCIERO</span><h2>Finanzas y gastos</h2><p>Estimación basada en costos unitarios ingresados. No sustituye la contabilidad formal.</p></div></div><div className="rw-stats"><div><small>Ventas completadas</small><b>{money(revenue)}</b></div><div><small>Costo de productos vendidos</small><b>{money(costOfSales)}</b></div><div><small>Ganancia bruta estimada</small><b>{money(grossProfit)}</b></div><div><small>Resultado menos gastos</small><b>{money(netProfit)}</b></div></div><div className="rw-formgrid"><input value={expenseName} onChange={e => setExpenseName(e.target.value)} placeholder="Descripción del gasto" /><input type="number" value={expenseAmount} onChange={e => setExpenseAmount(e.target.value)} placeholder="Monto L" /><select value={expenseCategory} onChange={e => setExpenseCategory(e.target.value)}>{["Insumos", "Empaque", "Transporte", "Equipo", "Servicios", "Publicidad", "Otros"].map(c => <option key={c}>{c}</option>)}</select><button className="rw-primary" onClick={addExpense}>＋ Registrar gasto</button></div><div className="rw-tablewrap"><table><thead><tr><th>Fecha</th><th>Gasto</th><th>Categoría</th><th>Monto</th><th>Acción</th></tr></thead><tbody>{expenses.map(e => <tr key={e.id}><td>{new Date(e.date).toLocaleDateString("es-HN")}</td><td>{e.name}</td><td>{e.category}</td><td>{money(e.amount)}</td><td><button className="rw-link" onClick={() => setExpenses(es => es.filter(x => x.id !== e.id))}>Eliminar</button></td></tr>)}</tbody></table></div></>;
    if (page === "customers") return <><div className="rw-heading"><div><span className="rw-kicker">RELACIÓN CON CLIENTES</span><h2>Clientes y frecuencia</h2><p>Los datos se calculan desde los pedidos de este navegador.</p></div></div><input className="rw-wide" value={queryCustomer} onChange={e => setQueryCustomer(e.target.value)} placeholder="Buscar nombre o teléfono" /><div className="rw-tablewrap"><table><thead><tr><th>Nombre</th><th>Teléfono</th><th>Pedidos</th><th>Compras</th><th>Puntos estimados</th><th>Acción</th></tr></thead><tbody>{customers.filter(c => (c.name + " " + c.phone).toLowerCase().includes(queryCustomer.toLowerCase())).map(c => <tr key={c.phone}><td>{c.name}</td><td>{c.phone}</td><td>{c.orders}</td><td>{money(c.spent)}</td><td>{c.points}</td><td><button className="rw-link" onClick={() => window.open("https://wa.me/" + c.phone.replace(/\D/g, ""), "_blank")}>WhatsApp ↗</button></td></tr>)}</tbody></table></div><p className="rw-note">Los puntos son una propuesta de 1 punto por cada L10 de pedido completado, sin canje automático.</p></>;
    if (page === "marketing") return <><div className="rw-heading"><div><span className="rw-kicker">CRECIMIENTO</span><h2>Marketing y campañas</h2></div></div><div className="rw-marketing"><img src="https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=1000&q=85" alt="Café servido" /><div className="rw-form"><input value={campaignName} onChange={e => setCampaignName(e.target.value)} placeholder="Nombre de campaña" /><select value={campaignChannel} onChange={e => setCampaignChannel(e.target.value)}>{["WhatsApp", "Facebook", "Instagram", "TikTok", "Correo", "Presencial"].map(c => <option key={c}>{c}</option>)}</select><textarea rows={5} value={campaign} onChange={e => setCampaign(e.target.value)} placeholder="Texto de campaña" /><button className="rw-primary" onClick={createCampaign}>Guardar borrador</button><button className="rw-secondary" onClick={() => {
            navigator.clipboard?.writeText(campaign);
            alert("Texto copiado si el navegador permite el portapapeles.");
          }}>Copiar texto</button><button className="rw-secondary" onClick={() => window.open("https://wa.me/?text=" + encodeURIComponent(campaign), " _blank")}>Compartir por WhatsApp ↗</button></div></div><h3>Campañas guardadas</h3>{campaigns.map(c => <article className="rw-order" key={c.id}><b>{c.name}</b><small className="rw-block">{c.channel} · {new Date(c.date).toLocaleString("es-HN")} · {c.status}</small><p>{c.message}</p><button className="rw-link" onClick={() => {
          setCampaignName(c.name);
          setCampaign(c.message);
          setCampaignChannel(c.channel);
        }}>Editar borrador</button><button className="rw-link" onClick={() => setCampaigns(cs => cs.filter(x => x.id !== c.id))}>Eliminar</button></article>)}</>;
    if (page === "loyalty") return <><div className="rw-loyalty"><span>RW</span><h2>Redwings Rewards</h2><p>Programa propuesto: un punto por cada L10 en pedidos completados. Los puntos se estiman por teléfono y se actualizan con los pedidos guardados.</p><div className="rw-stats"><div><small>Clientes registrados</small><b>{customers.length}</b></div><div><small>Puntos estimados</small><b>{customers.reduce((s, c) => s + c.points, 0)}</b></div></div></div><div className="rw-tablewrap"><table><thead><tr><th>Cliente</th><th>Teléfono</th><th>Compras</th><th>Puntos</th></tr></thead><tbody>{customers.map(c => <tr key={c.phone}><td>{c.name}</td><td>{c.phone}</td><td>{money(c.spent)}</td><td>{c.points}</td></tr>)}</tbody></table></div></>;
    if (page === "staff") return <><div className="rw-heading"><div><span className="rw-kicker">EQUIPO</span><h2>Personal y responsabilidades</h2></div></div><div className="rw-formgrid"><input value={staffName} onChange={e => setStaffName(e.target.value)} placeholder="Nombre del integrante" /><select value={staffRole} onChange={e => setStaffRole(e.target.value)}>{["Administrador", "Ventas", "Barista", "Inventario", "Finanzas", "Marketing", "Compras", "Entrega"].map(c => <option key={c}>{c}</option>)}</select><input value={staffPhone} onChange={e => setStaffPhone(e.target.value)} placeholder="Teléfono (opcional)" /><button className="rw-primary" onClick={addStaff}>＋ Añadir integrante</button></div><div className="rw-tablewrap"><table><thead><tr><th>Nombre</th><th>Responsabilidad</th><th>Contacto</th><th>Estado</th><th>Acciones</th></tr></thead><tbody>{staff.map(s => <tr key={s.id}><td>{s.name}</td><td>{s.role}</td><td>{s.phone || "—"}</td><td>{s.active ? "Activo" : "Inactivo"}</td><td><button className="rw-link" onClick={() => setStaff(a => a.map(x => x.id === s.id ? {
                  ...x,
                  active: !x.active
                } : x))}>Cambiar estado</button><button className="rw-link" onClick={() => setStaff(a => a.filter(x => x.id !== s.id))}>Eliminar</button></td></tr>)}</tbody></table></div><p className="rw-note">Este módulo es un directorio interno, no un sistema de nómina ni control de acceso.</p></>;
    if (page === "suppliers") return <><div className="rw-heading"><div><span className="rw-kicker">ABASTECIMIENTO</span><h2>Proveedores</h2><p>Directorio y productos suministrados.</p></div></div><div className="rw-formgrid"><input value={supplierName} onChange={e => setSupplierName(e.target.value)} placeholder="Nombre del proveedor" /><input value={supplierPhone} onChange={e => setSupplierPhone(e.target.value)} placeholder="Teléfono" /><input value={supplierEmail} onChange={e => setSupplierEmail(e.target.value)} placeholder="Correo electrónico" /><input value={supplierProducts} onChange={e => setSupplierProducts(e.target.value)} placeholder="Productos / insumos" /><button className="rw-primary" onClick={addSupplier}>＋ Guardar proveedor</button></div><div className="rw-tablewrap"><table><thead><tr><th>Proveedor</th><th>Contacto</th><th>Correo</th><th>Insumos</th><th>Acciones</th></tr></thead><tbody>{suppliers.map(s => <tr key={s.id}><td>{s.name}</td><td>{s.phone || "—"}</td><td>{s.email || "—"}</td><td>{s.products || "—"}</td><td><button className="rw-link" onClick={() => {
                  const n = prompt("Editar productos / insumos:", s.products);
                  if (n !== null) setSuppliers(a => a.map(x => x.id === s.id ? {
                    ...x,
                    products: n
                  } : x));
                }}>Editar</button><button className="rw-link" onClick={() => setSuppliers(a => a.filter(x => x.id !== s.id))}>Eliminar</button></td></tr>)}</tbody></table></div><div className="rw-panel"><h3>Compras sugeridas</h3><p>Revisa el inventario bajo y contacta al proveedor del insumo correspondiente. Las órdenes de compra automáticas requieren definir cantidades mínimas y precios reales.</p><button className="rw-secondary" onClick={() => go("inventory")}>Revisar stock bajo</button></div></>;
    if (page === "recipes") return <><div className="rw-heading"><div><span className="rw-kicker">PRODUCCIÓN</span><h2>Recetas y costos</h2><p>Escribe un ingrediente por línea con formato: nombre,cantidad,unidad,costo total.</p></div></div><div className="rw-formgrid"><input value={recipeName} onChange={e => setRecipeName(e.target.value)} placeholder="Nombre de receta" /><input type="number" value={recipeYield} onChange={e => setRecipeYield(e.target.value)} placeholder="Porciones producidas" /><input type="number" value={recipePrice} onChange={e => setRecipePrice(e.target.value)} placeholder="Precio de venta por porción" /><textarea rows={4} value={recipeIngredients} onChange={e => setRecipeIngredients(e.target.value)} placeholder={"Café,1,porción,12\nLeche,100,ml,5"} /><button className="rw-primary" onClick={addRecipe}>＋ Guardar receta</button></div>{recipes.map(r => {
        const cost = r.ingredients.reduce((s, i) => s + i.cost, 0) / Math.max(1, r.yieldQty);
        return <article className="rw-order" key={r.id}><div className="rw-orderhead"><div><h3>{r.name}</h3><small>{r.yieldQty} porciones por lote</small></div><b>{money(cost)} / porción</b></div><p>{r.ingredients.map(i => i.name + ": " + i.qty + " " + i.unit + " (" + money(i.cost) + ")").join(" · ")}</p><p>Precio: {money(r.price)} · Margen bruto estimado: {money(r.price - cost)} ({r.price ? Math.round((r.price - cost) / r.price * 100) : 0}%)</p><button className="rw-link" onClick={() => setRecipes(rs => rs.filter(x => x.id !== r.id))}>Eliminar receta</button></article>;
      })}</>;
    if (page === "analytics" || page === "reports") return <><div className="rw-heading"><div><span className="rw-kicker">INDICADORES</span><h2>{page === "analytics" ? "Analítica de negocio" : "Informes y respaldos"}</h2><p>Los informes reflejan solo los datos introducidos en este navegador.</p></div><button className="rw-primary" onClick={exportData}>Descargar respaldo JSON</button></div><div className="rw-stats"><div><small>Pedidos totales</small><b>{orders.length}</b></div><div><small>Valor de pedidos</small><b>{money(allSales)}</b></div><div><small>Ticket promedio</small><b>{money(orders.length ? allSales / orders.length : 0)}</b></div><div><small>Productos activos</small><b>{active.length}</b></div><div><small>Ingresos completados</small><b>{money(revenue)}</b></div><div><small>Ganancia bruta estimada</small><b>{money(grossProfit)}</b></div><div><small>Gastos registrados</small><b>{money(expenseTotal)}</b></div><div><small>Resultado estimado</small><b>{money(netProfit)}</b></div></div><div className="rw-panel"><h3>Estado de pedidos</h3>{["Pendiente", "Confirmado", "En preparación", "Listo", "Completado", "Cancelado"].map(s => <p key={s}>{s}: <b>{orders.filter(o => o.status === s).length}</b></p>)}</div><div className="rw-panel"><h3>Productos con mayor venta registrada</h3>{products.map(p => ({
          ...p,
          sold: orders.filter(o => o.status === "Completado").reduce((s, o) => s + o.items.filter(i => i.productId === p.id).reduce((a, i) => a + i.qty, 0), 0)
        })).sort((a, b) => b.sold - a.sold).slice(0, 5).map(p => <p key={p.id}>{p.name}: <b>{p.sold}</b> unidades</p>)}</div><div className="rw-formgrid"><button className="rw-secondary" onClick={() => saveFile("redwings-pedidos.csv", ["ID,Fecha,Cliente,Estado,Total", ...orders.map(o => [o.id, o.date, o.customer, o.status, o.total].join(","))].join("\n"), "text/csv")}>Exportar pedidos CSV</button><button className="rw-secondary" onClick={() => saveFile("redwings-productos.csv", ["SKU,Nombre,Categoría,Precio,Costo,Stock", ...products.map(p => [p.sku, p.name, p.category, p.price, p.cost, p.stock].join(","))].join("\n"), "text/csv")}>Exportar productos CSV</button><label className="rw-upload">Restaurar respaldo JSON<input type="file" accept="application/json,.json" onChange={e => {
            const f = e.target.files?.[0];
            if (f) importData(f);
            e.currentTarget.value = "";
          }} /></label></div></>;
    if (page === "assistant") return <><div className="rw-panel rw-assistant"><span className="rw-kicker">COPILOTO OPERATIVO</span><h2>Asistente de Redwings</h2><p>Resumen generado con los datos locales actuales. No es una IA externa ni inventa información.</p><div className="rw-stats"><div><small>Pedidos por atender</small><b>{pending}</b></div><div><small>Stock bajo</small><b>{low}</b></div><div><small>Resultado estimado</small><b>{money(netProfit)}</b></div></div><h3>Acciones recomendadas</h3><ul>{pending ? <li>Revisar {pending} pedidos que todavía no están completados.</li> : <li>No hay pedidos pendientes registrados.</li>}{low ? <li>Revisar {low} productos con cinco unidades o menos y planificar reposición.</li> : <li>No hay alertas de stock bajo con el límite actual.</li>}{netProfit < 0 ? <li>El resultado estimado es negativo. Revisa costos, precios y gastos registrados.</li> : <li>Compara costos reales con precios para validar el margen.</li>}<li>Exporta un respaldo antes de hacer cambios grandes.</li></ul><button className="rw-primary" onClick={() => go("reports")}>Abrir informe</button><button className="rw-secondary" onClick={() => go("inventory")}>Revisar inventario</button></div><p className="rw-note">La IA conversacional real requiere un proveedor de modelos y un backend que mantenga las claves privadas fuera del navegador.</p></>;
    if (page === "settings") return <><div className="rw-panel"><span className="rw-kicker">IDENTIDAD DE MARCA</span><h2>Editor de portada</h2><p>Cambia el texto y la imagen que aparecen en la tienda pública.</p><label className="rw-block">Título principal (separa las líneas con |)</label><input className="rw-wide" value={heroTitle} onChange={e => setHeroTitle(e.target.value)} /><label className="rw-block">Texto de portada</label><textarea className="rw-wide" rows={3} value={heroText} onChange={e => setHeroText(e.target.value)} /><label className="rw-block">URL de imagen</label><input className="rw-wide" value={heroImage.startsWith("data:") ? "Imagen subida desde el teléfono" : heroImage} onChange={e => setHeroImage(e.target.value)} placeholder="https://..." /><label className="rw-upload">Subir imagen desde el teléfono<input type="file" accept="image/*" onChange={e => {
            const file = e.target.files?.[0];
            if (file) {
              if (file.size > 650000) {
                setToast("Imagen demasiado grande. Elige una menor de 650 KB.");
                return;
              }
              const reader = new FileReader();
              reader.onload = () => setHeroImage(String(reader.result));
              reader.readAsDataURL(file);
            }
            e.currentTarget.value = "";
          }} /></label>{heroImage && <img src={heroImage} alt="Vista previa de portada" style={{
          display: "block",
          width: "100%",
          maxWidth: 600,
          maxHeight: 240,
          objectFit: "cover",
          borderRadius: 12,
          marginTop: 14
        }} />}<button className="rw-primary" onClick={() => setToast("Portada guardada en este navegador")}>Guardar portada</button><button className="rw-secondary" onClick={() => {
          setHeroTitle("Tu momento.|Tu café.");
          setHeroText("Sabores que convierten cualquier pausa en tu momento favorito.");
          setHeroImage("https://images.unsplash.com/photo-1442512595331-e89e73853f31?auto=format&fit=crop&w=1100&q=90");
        }}>Restablecer</button><p className="rw-note">Los cambios y las imágenes subidas se guardan en este navegador. La sincronización entre teléfonos necesita almacenamiento compartido.</p></div><div className="rw-panel"><span className="rw-kicker">CATÁLOGO VISUAL</span><h2>Imágenes de productos</h2><p>Abre cualquier ficha para cambiar nombre, precio, descripción y foto.</p>{products.map(p => <article className="rw-order" key={p.id}><div className="rw-orderhead"><div><h3>{p.name}</h3><small>{money(p.price)} · {p.category}</small></div><img src={p.image} alt={p.name} style={{
              width: 76,
              height: 76,
              objectFit: "cover",
              borderRadius: 8
            }} /></div><button className="rw-primary" onClick={() => {
            editProduct(p);
            setPage("products");
          }}>Editar producto e imagen</button></article>)}</div><div className="rw-heading"><div><span className="rw-kicker">SISTEMA</span><h2>Configuración e integración</h2></div></div><div className="rw-panel"><h3>Datos del negocio</h3><p>Nombre: Redwings Coffee</p><p>Moneda: Lempira hondureño (HNL)</p><p>WhatsApp de pedidos: +504 9289-9752</p><p>Modalidad: recogida de pedidos</p><p>Almacenamiento actual: navegador / dispositivo.</p></div><div className="rw-panel"><span className="rw-kicker">FIREBASE REALTIME DATABASE</span><h3>Conectar base de datos</h3><p>Introduce la URL exacta de tu Realtime Database, sin la ruta final /redwings. La prueba revisa la lectura de /redwings/health. No pegues contraseñas ni claves privadas aquí.</p><input className="rw-wide" value={firebaseUrl} onChange={e => {
          setFirebaseUrl(e.target.value);
          setFirebaseStatus("Pendiente de probar");
        }} placeholder="https://TU-PROYECTO-default-rtdb.firebaseio.com" /><div className="rw-controls"><button className="rw-primary" disabled={firebaseBusy} onClick={connectFirebase}>{firebaseBusy ? "Probando…" : "Probar conexión"}</button><button className="rw-secondary" disabled={firebaseBusy} onClick={syncFirebase}>{firebaseBusy ? "Procesando…" : "Enviar respaldo a Firebase"}</button></div><p>Estado: <b>{firebaseStatus}</b></p><p className="rw-note">La escritura de respaldo solo funciona si las reglas de Firebase permiten escribir. No actives escritura pública en una base con datos reales. Para producción hace falta Firebase Authentication, reglas por UID y sincronización autenticada; esta prueba no reemplaza esas medidas.</p></div><div className="rw-panel"><h3>Respaldo y mantenimiento</h3><p>Descarga una copia completa o restaura un JSON compatible. La restauración reemplaza los datos actuales.</p><button className="rw-primary" onClick={exportData}>Descargar respaldo completo</button><label className="rw-upload">Seleccionar respaldo para restaurar<input type="file" accept="application/json,.json" onChange={e => {
            const f = e.target.files?.[0];
            if (f) importData(f);
            e.currentTarget.value = "";
          }} /></label><button className="rw-secondary" onClick={() => setShowHelp(x => !x)}>{showHelp ? "Ocultar" : "Ver"} instrucciones de configuración</button>{showHelp && <ol><li>En Firebase abre Realtime Database y copia su URL completa.</li><li>Crea la ruta /redwings/health con el valor true para probar lectura.</li><li>Configura Authentication y reglas seguras antes de datos reales.</li><li>No guardes contraseñas ni claves de administrador en el código del sitio.</li><li>Para compartir pedidos con Blogger, conecta ambos frontends a la misma base mediante reglas que permitan a clientes crear pedidos y solo al administrador leerlos.</li></ol>}</div><div className="rw-panel"><h3>Privacidad y límites</h3><p>Los datos actuales se guardan en localStorage y pueden perderse si borras los datos del navegador. No se ha configurado inicio de sesión, permisos multiusuario, pagos en línea ni integración con una IA externa.</p></div></>;
    return <><section className="rw-hero"><div><span className="rw-kicker">PANEL DE CONTROL · REDWINGS COFFEE</span><h1>Buen día.<br /><i>Vamos a mover el negocio.</i></h1><p>Productos, pedidos, inventario y números en un solo espacio de trabajo.</p><button className="rw-primary" onClick={() => go("shop")}>Abrir tienda ↗</button><button className="rw-secondary" onClick={() => go("products")}>Gestionar catálogo</button></div><img src="https://images.unsplash.com/photo-1442512595331-e89e73853f31?auto=format&fit=crop&w=1100&q=90" alt="Café artesanal" /></section><div className="rw-stats"><div><small>Ventas completadas</small><b>{money(revenue)}</b><span>Ingresos confirmados</span></div><div><small>Pedidos activos</small><b>{pending}</b><span>Requieren seguimiento</span></div><div><small>Productos activos</small><b>{active.length}</b><span>{low} con stock bajo</span></div><div><small>Resultado estimado</small><b>{money(netProfit)}</b><span>Ganancia menos gastos</span></div></div><div className="rw-heading"><div><span className="rw-kicker">CENTRO DE OPERACIONES</span><h2>Todo tu negocio, organizado</h2><p>Acceso rápido a los módulos de gestión.</p></div></div><div className="rw-cards">{nav.filter(n => n[0] !== "overview").map(([id, label, ico]) => <button className="rw-module" key={id} onClick={() => go(id)}><span>{ico}</span><b>{label}</b><small>Gestionar y consultar</small><i>Explorar ↗</i></button>)}</div><div className="rw-columns"><div className="rw-panel"><h3>Pedidos recientes</h3>{orders.slice(0, 5).map(o => <p key={o.id}><b>{o.id}</b> · {o.customer} · {o.status} · {money(o.total)}</p>)}{!orders.length && <p>Todavía no hay pedidos. Puedes crear uno desde la tienda.</p>}<button className="rw-link" onClick={() => go("orders")}>Ver todos los pedidos →</button></div><div className="rw-panel"><h3>Alertas de inventario</h3>{products.filter(p => p.active && p.stock <= 5).map(p => <p key={p.id}>{p.name}: <b>{p.stock}</b> unidades</p>)}{low === 0 && <p>No hay productos bajo el límite de cinco unidades.</p>}<button className="rw-link" onClick={() => go("inventory")}>Abrir inventario →</button></div></div><div className="rw-panel"><h3>Estado de conexión</h3><p>Modo actual: almacenamiento local. Firebase: {firebaseStatus}. Los datos no se comparten automáticamente con Blogger hasta terminar la autenticación, reglas y sincronización.</p><button className="rw-secondary" onClick={() => go("settings")}>Configurar integración</button></div></>;
  };
  return <div className="rw-app"><header className="rw-top"><button className="rw-brand" aria-label="Redwings Coffee. Acceso a tienda y administración" onClick={() => go(isAdmin ? "overview" : "login")}><span className="rw-mark">R</span><span><b>REDWINGS</b><small>COFFEE · EST. 2026</small></span></button><nav className="rw-customer-nav"><button onClick={() => go("shop")}>Tienda</button><button onClick={() => go("discounts")}>Descuentos</button><button onClick={() => go("myorders")}>Pedidos</button><button onClick={() => go("profile")}>Perfil</button>{isAdmin ? <button onClick={() => go("overview")}>Panel privado</button> : null}</nav><div className="rw-topright"><span className="rw-local">● Modo local</span><button className="rw-cartbutton" onClick={() => go("cart")}>Carrito {items.reduce((s, p) => s + p.qty, 0)}</button></div></header>{!isAdmin && <nav className="rw-bottom-nav" aria-label="Navegación principal"><button className={page === "shop" ? "active" : ""} onClick={() => go("shop")}><span>⌂</span>Inicio</button><button className={page === "discounts" ? "active" : ""} onClick={() => go("discounts")}><span>✳</span>Ofertas</button><button className={page === "cart" ? "active" : ""} onClick={() => go("cart")}><span>◈</span>Carrito</button><button className={page === "myorders" ? "active" : ""} onClick={() => go("myorders")}><span>≋</span>Pedidos</button><button className={page === "profile" ? "active" : ""} onClick={() => go("profile")}><span>♙</span>Perfil</button></nav>}<div className={"rw-layout " + (!isAdmin ? "rw-public" : "")}>{isAdmin && <aside className="rw-sidebar"><small className="rw-sidecap">ESPACIO DE TRABAJO</small>{nav.map(([id, label, ico]) => <button key={id} className={"rw-nav " + (page === id ? "selected" : "")} onClick={() => go(id)}><span>{ico}</span>{label}{id === "orders" && pending > 0 ? <em>{pending}</em> : null}</button>)}<div className="rw-sidefoot"><span>RW</span><div><b>Redwings Coffee</b><small>Panel de negocio</small></div></div></aside>}<main className="rw-main"><div className="rw-mobilecrumb">REDWINGS / {nav.find(n => n[0] === page)?.[1]}</div>{view()}<footer className="rw-footer"><span>REDWINGS COFFEE</span><span>Hecho para crecer con cada taza.</span>{isAdmin && <button onClick={exportData}>Exportar respaldo</button>}{null}{isAdmin && <button onClick={() => {
            setIsAdmin(false);
            setPage("shop");
          }}>Cerrar sesión</button>}</footer></main></div>{toast && <div className="rw-toast" role="status">{toast}</div>}</div>;
}
export default RedwingsCoffeePlataformaIntegral;