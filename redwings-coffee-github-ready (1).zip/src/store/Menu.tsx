import { useMemo, useState } from 'react';
import { useCategories, useProducts } from '../services/data';
import { navigate } from '../services/router';
import { norm } from '../lib/format';
import { isAvailable } from '../lib/pricing';
import { Icon } from '../components/Icon';
import { Empty } from '../components/ui';
import { ProductCard } from './ProductCard';
import { catalog, fromPrice } from './helpers';

type Sort = 'order' | 'asc' | 'desc' | 'name';

export function Menu({ categoryId }: { categoryId?: string }) {
  const [products] = useProducts();
  const [categories] = useCategories();
  const [q, setQ] = useState('');
  const [onlyAvail, setOnlyAvail] = useState(false);
  const [sort, setSort] = useState<Sort>('order');
  const cats = categories.filter((c) => c.active).sort((a, b) => a.order - b.order);
  const active = categoryId && cats.some((c) => c.id === categoryId) ? categoryId : 'all';

  const shown = useMemo(() => {
    const catName = (id: string) => categories.find((c) => c.id === id)?.name || '';
    const term = norm(q.trim());
    let list = catalog(products, categories).filter((p) => active === 'all' || p.categoryId === active);
    if (term) {
      list = list.filter((p) => norm([p.name, p.description, p.ingredients.join(' '), p.tags.join(' '), catName(p.categoryId), p.code || ''].join(' ')).includes(term));
    }
    if (onlyAvail) list = list.filter((p) => isAvailable(p));
    const s = [...list];
    if (sort === 'asc') s.sort((a, b) => fromPrice(a) - fromPrice(b));
    if (sort === 'desc') s.sort((a, b) => fromPrice(b) - fromPrice(a));
    if (sort === 'name') s.sort((a, b) => a.name.localeCompare(b.name, 'es'));
    return s;
  }, [products, categories, q, active, onlyAvail, sort]);

  return (
    <div className="page">
      <h1 className="page-title">Menú</h1>
      <div className="search">
        <Icon name="search" size={20} />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar bebidas, ingredientes…" aria-label="Buscar" />
        {q && <button className="icon-btn" onClick={() => setQ('')} aria-label="Borrar búsqueda"><Icon name="close" size={18} /></button>}
      </div>
      <div className="chips chips-wrap">
        <button className={'chip' + (active === 'all' ? ' on' : '')} onClick={() => navigate('menu')}>Todos</button>
        {cats.map((c) => <button key={c.id} className={'chip' + (active === c.id ? ' on' : '')} onClick={() => navigate('menu/' + c.id)}>{c.name}</button>)}
      </div>
      <div className="toolbar">
        <label className="check"><input type="checkbox" checked={onlyAvail} onChange={(e) => setOnlyAvail(e.target.checked)} /> Solo disponibles</label>
        <select value={sort} onChange={(e) => setSort(e.target.value as Sort)} aria-label="Ordenar">
          <option value="order">Orden del menú</option>
          <option value="asc">Precio: menor a mayor</option>
          <option value="desc">Precio: mayor a menor</option>
          <option value="name">Nombre</option>
        </select>
      </div>
      {shown.length === 0 ? (
        <Empty icon="search" title="Sin resultados" text={q ? 'No encontramos "' + q + '". Prueba con otra palabra.' : 'No hay productos en esta categoría.'} />
      ) : (
        <div className="grid">{shown.map((p) => <ProductCard key={p.id} p={p} />)}</div>
      )}
    </div>
  );
}
