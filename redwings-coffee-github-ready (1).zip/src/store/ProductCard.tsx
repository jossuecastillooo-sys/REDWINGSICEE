import type { Product } from '../types';
import { money } from '../lib/format';
import { isAvailable } from '../lib/pricing';
import { addToCart } from '../services/cart';
import { useFavorites } from '../services/data';
import { openProduct, toast } from '../services/ui';
import { Icon } from '../components/Icon';
import { ProductImage } from '../components/ui';
import { fromPrice, needsCustomization } from './helpers';

export function ProductCard({ p }: { p: Product }) {
  const [favs, setFavs] = useFavorites();
  const fav = favs.includes(p.id);
  const ok = isAvailable(p);
  const quickAdd = () => {
    if (!ok) return;
    if (needsCustomization(p)) return openProduct(p.id);
    addToCart({ productId: p.id, choices: {}, extras: {}, qty: 1 });
    toast(p.name + ' agregado al carrito');
  };
  return (
    <article className={'pcard' + (ok ? '' : ' pcard-off')}>
      <button className="pcard-main" onClick={() => openProduct(p.id)} aria-label={'Ver ' + p.name}>
        <div className="pcard-img">
          <ProductImage src={p.image} name={p.name} />
          <div className="pcard-tags">
            {!ok && <span className="tag tag-off">Agotado</span>}
            {ok && p.tags.map((t) => <span key={t} className="tag">{t}</span>)}
          </div>
        </div>
        <h3>{p.name}</h3>
        <p className="pcard-price">{p.sizes.length ? 'Desde ' : ''}{money(fromPrice(p))}</p>
      </button>
      <button className={'fav-btn' + (fav ? ' on' : '')} aria-label={fav ? 'Quitar de favoritos' : 'Guardar en favoritos'} onClick={() => setFavs(fav ? favs.filter((x) => x !== p.id) : [...favs, p.id])}>
        <Icon name="heart" size={20} />
      </button>
      <button className="add-btn" onClick={quickAdd} disabled={!ok} aria-label={'Agregar ' + p.name}>
        <Icon name="plus" size={22} />
      </button>
    </article>
  );
}
