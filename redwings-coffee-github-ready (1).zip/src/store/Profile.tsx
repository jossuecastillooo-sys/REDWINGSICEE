import type React from 'react';
import { useState } from 'react';
import { fmtDate, isValidPhone, normalizePhone } from '../lib/format';
import { useCustomer, useNotifications, useOrders } from '../services/data';
import { setStored } from '../services/store';
import { navigate } from '../services/router';
import { toast } from '../services/ui';
import { Icon } from '../components/Icon';
import { Field } from '../components/ui';

export function Profile() {
  const [c, setC] = useCustomer();
  const [orders] = useOrders();
  const [notifs] = useNotifications();
  const [f, setF] = useState({ name: c?.name || '', phone: c?.phone || '', career: c?.career || '', grade: c?.grade || '', section: c?.section || '' });
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF((x) => ({ ...x, [k]: e.target.value }));
  const mine = c ? orders.filter((o) => o.customer.phone === c.phone) : [];
  const unread = c ? notifs.filter((n) => n.phone === c.phone && !n.read).length : 0;

  const save = () => {
    if (!f.name.trim()) return toast('Escribe tu nombre', 'error');
    if (!isValidPhone(f.phone)) return toast('El teléfono debe tener 8 dígitos', 'error');
    setC({ ...f, phone: normalizePhone(f.phone), createdAt: c?.createdAt || new Date().toISOString() });
    toast('Perfil guardado');
  };
  return (
    <div className="page">
      <h1 className="page-title">Perfil</h1>
      {c && <p className="muted small">Cliente desde {fmtDate(c.createdAt)} · {mine.length} pedido(s)</p>}
      <section className="card">
        <Field label="Nombre"><input value={f.name} onChange={set('name')} /></Field>
        <Field label="Teléfono"><input value={f.phone} onChange={set('phone')} inputMode="tel" /></Field>
        <Field label="Carrera"><input value={f.career} onChange={set('career')} /></Field>
        <div className="two">
          <Field label="Grado"><input value={f.grade} onChange={set('grade')} /></Field>
          <Field label="Sección"><input value={f.section} onChange={set('section')} /></Field>
        </div>
        <button className="btn btn-primary btn-block" onClick={save}>Guardar perfil</button>
      </section>
      <nav className="menu-list">
        <button onClick={() => navigate('orders')}><Icon name="orders" /> Mis pedidos <Icon name="down" size={16} /></button>
        <button onClick={() => navigate('favorites')}><Icon name="heart" /> Favoritos</button>
        <button onClick={() => navigate('notifications')}><Icon name="bell" /> Notificaciones {unread > 0 && <span className="badge-n">{unread}</span>}</button>
        <button onClick={() => navigate('help')}><Icon name="help" /> Ayuda y contacto</button>
      </nav>
      {c && (
        <button className="link danger center" onClick={() => { if (window.confirm('¿Borrar tu perfil de este dispositivo? Tus pedidos no se eliminan.')) { setStored('customer', null); toast('Perfil borrado', 'info'); } }}>
          Borrar perfil de este dispositivo
        </button>
      )}
    </div>
  );
}
