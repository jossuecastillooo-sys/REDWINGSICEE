import { useMemo, useState } from 'react';
import type { CartLine } from '../types';
import { money } from '../lib/format';
import { isAvailable, unitPrice, validateLine } from '../lib/pricing';
import { addToCart } from '../services/cart';
import { useCart, useFavorites, useProducts } from '../services/data';
import { closeProduct, toast, useProductSheet } from '../services/ui';
import { Icon } from '../components/Icon';
import { ProductImage, Sheet, Stepper } from '../components/ui';

export function ProductSheetHost() {
  const target = useProductSheet();
  const [products] = useProducts();
  const p = target && products.find((x) => x.id === target.productId);
  if (!target || !p) return null;
  return <ProductSheetInner key={target.productId + (target.lineId || '')} productId={target.productId} lineId={target.lineId} />;
}

function ProductSheetInner({ productId, lineId }: { productId: string; lineId?: string }) {
  const [products] = useProducts();
  const [cart] = useCart();
  const [favs, setFavs] = useFavorites();
  const p = products.find((x) => x.id === productId)!;
  const existing = lineId ? cart.find((l) => l.id === lineId) : undefined;

  const [sizeId, setSizeId] = useState<string | undefined>(existing?.sizeId ?? (p.sizes[0]?.id));
  const [choices, setChoices] = useState<Record<string, string>>(() => {
    if (existing) return existing.choices;
    const init: Record<string, string> = {};
    p.optionGroups.forEach((g) => { if (g.required && g.choices[0]) init[g.id] = g.choices[0].id; });
    return init;
  });
  const [extras, setExtras] = useState<Record<string, number>>(existing?.extras ?? {});
  const [qty, setQty] = useState(existing?.qty ?? 1);
  const [note, setNote] = useState(existing?.note ?? '');

  const draft: CartLine = { id: lineId || '', productId, sizeId, choices, extras, qty, note: note.trim() || undefined };
  const unit = useMemo(() => unitPrice(p, draft), [p, sizeId, choices, extras]); // eslint-disable-line react-hooks/exhaustive-deps
  const error = validateLine(p, draft);
  const ok = isAvailable(p);
  const fav = favs.includes(p.id);
  const extrasAvail = p.extras.filter((e) => e.available);

  const submit = () => {
    if (error) return toast(error, 'error');
    addToCart({ productId, sizeId, choices, extras: Object.fromEntries(Object.entries(extras).filter(([, q]) => q > 0)), qty, note: draft.note }, lineId);
    toast(lineId ? 'Producto actualizado' : p.name + ' agregado al carrito');
    closeProduct();
  };

  return (
    <Sheet
      title={p.name}
      onClose={closeProduct}
      tall
      footer={
        ok ? (
          <div className="sheet-foot-row">
            <Stepper value={qty} min={1} max={p.stock ?? 99} onChange={setQty} />
            <button className="btn btn-primary btn-grow" onClick={submit}>
              {lineId ? 'Guardar' : 'Agregar'} · {money(unit * qty)}
            </button>
          </div>
        ) : (
          <p className="muted center">Este producto no está disponible por ahora.</p>
        )
      }
    >
      <div className="psheet-img">
        <ProductImage src={p.image} name={p.name} />
        <button className={'fav-btn' + (fav ? ' on' : '')} aria-label="Favorito" onClick={() => setFavs(fav ? favs.filter((x) => x !== p.id) : [...favs, p.id])}>
          <Icon name="heart" size={20} />
        </button>
      </div>
      <div className="tags-row">{p.tags.map((t) => <span key={t} className="tag">{t}</span>)}{!ok && <span className="tag tag-off">Agotado</span>}</div>
      {p.description && <p className="muted">{p.description}</p>}
      {p.ingredients.length > 0 && <p className="small"><b>Ingredientes:</b> {p.ingredients.join(', ')}</p>}
      {p.prepMinutes ? <p className="small">Preparación aprox. {p.prepMinutes} min</p> : null}

      {ok && (
        <>
          {p.sizes.length > 0 && (
            <fieldset className="opt-group">
              <legend>Tamaño</legend>
              {p.sizes.map((s) => (
                <label key={s.id} className={'opt' + (sizeId === s.id ? ' on' : '')}>
                  <input type="radio" name="size" checked={sizeId === s.id} onChange={() => setSizeId(s.id)} />
                  <span>{s.name}</span><b>{money(s.price)}</b>
                </label>
              ))}
            </fieldset>
          )}
          {p.optionGroups.filter((g) => g.choices.length).map((g) => (
            <fieldset className="opt-group" key={g.id}>
              <legend>{g.name}{g.required ? '' : ' (opcional)'}</legend>
              {!g.required && (
                <label className={'opt' + (!choices[g.id] ? ' on' : '')}>
                  <input type="radio" name={g.id} checked={!choices[g.id]} onChange={() => setChoices((c) => { const n = { ...c }; delete n[g.id]; return n; })} />
                  <span>Ninguna</span>
                </label>
              )}
              {g.choices.map((c) => (
                <label key={c.id} className={'opt' + (choices[g.id] === c.id ? ' on' : '')}>
                  <input type="radio" name={g.id} checked={choices[g.id] === c.id} onChange={() => setChoices((x) => ({ ...x, [g.id]: c.id }))} />
                  <span>{c.name}</span>{c.price > 0 && <b>+{money(c.price)}</b>}
                </label>
              ))}
            </fieldset>
          ))}
          {extrasAvail.length > 0 && (
            <fieldset className="opt-group">
              <legend>Extras</legend>
              {extrasAvail.map((e) => (
                <div key={e.id} className="opt opt-extra">
                  <span>{e.name}</span><b>+{money(e.price)}</b>
                  <Stepper value={extras[e.id] || 0} max={e.max || 5} onChange={(n) => setExtras((x) => ({ ...x, [e.id]: n }))} />
                </div>
              ))}
            </fieldset>
          )}
          <label className="field">
            <span>Nota para este producto (opcional)</span>
            <input value={note} maxLength={120} onChange={(e) => setNote(e.target.value)} placeholder="Ej. poco hielo" />
          </label>
        </>
      )}
    </Sheet>
  );
}
