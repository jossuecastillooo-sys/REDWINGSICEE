import { useMemo } from 'react';
import { useCategories, useOrders, useProducts, useSettings } from '../services/data';
import { navigate } from '../services/router';
import { Icon } from '../components/Icon';
import { isAvailable } from '../lib/pricing';
import { ProductCard } from './ProductCard';
import { catalog, titleLines } from './helpers';
import type { Product } from '../types';

function Row({ title, items, onMore }: { title: string; items: Product[]; onMore?: () => void }) {
  if (!items.length) return null;
  return (
    <section className="section">
      <div className="section-head">
        <h2>{title}</h2>
        {onMore && <button className="link" onClick={onMore}>Ver todo</button>}
      </div>
      <div className="grid">{items.map((p) => <ProductCard key={p.id} p={p} />)}</div>
    </section>
  );
}

export function Home() {
  const [settings] = useSettings();
  const [products] = useProducts();
  const [categories] = useCategories();
  const [orders] = useOrders();
  const list = useMemo(() => catalog(products, categories), [products, categories]);
  const cats = categories.filter((c) => c.active).sort((a, b) => a.order - b.order);

  const best = useMemo(() => {
    const qty = new Map<string, number>();
    orders.filter((o) => o.status !== 'Cancelado').forEach((o) => o.lines.forEach((l) => qty.set(l.productId, (qty.get(l.productId) || 0) + l.qty)));
    return list.filter((p) => qty.has(p.id)).sort((a, b) => (qty.get(b.id) || 0) - (qty.get(a.id) || 0)).slice(0, 4);
  }, [orders, list]);

  const lines = titleLines(settings.banner.title);
  return (
    <div className="page">
      <section className="hero" style={settings.banner.image ? { backgroundImage: 'linear-gradient(180deg,rgba(20,16,13,.25),rgba(20,16,13,.92)),url(' + settings.banner.image + ')' } : undefined}>
        <span className={'status-chip ' + (settings.open ? 'open' : 'closed')}>
          <i /> {settings.open ? 'Tienda abierta' : 'Tienda cerrada'}{settings.hours ? ' · ' + settings.hours : ''}
        </span>
        <h1>{lines.map((l, i) => <span key={i}>{l}{i < lines.length - 1 ? ' ' : ''}<br /></span>)}</h1>
        <p>{settings.banner.text}</p>
        <button className="btn btn-primary" onClick={() => navigate('menu')}>Hacer un pedido</button>
      </section>

      {!settings.open && <div className="notice notice-warn">{settings.closedMessage}</div>}
      {settings.notice && <div className="notice"><Icon name="bell" size={18} /> {settings.notice}</div>}

      <div className="chips">
        {cats.map((c) => <button key={c.id} className="chip" onClick={() => navigate('menu/' + c.id)}>{c.name}</button>)}
      </div>

      <Row title="Destacados" items={list.filter((p) => p.featured)} onMore={() => navigate('menu')} />
      <Row title="Más vendidos" items={best} />
      <Row title="Recomendados" items={list.filter((p) => p.recommended)} />
      <Row title="Nuevos" items={list.filter((p) => p.tags.includes('Nuevo'))} />
      <Row title="Ofertas" items={list.filter((p) => p.tags.includes('Oferta'))} />
      {list.filter((p) => !isAvailable(p)).length > 0 && <p className="muted center small">Los productos agotados aparecen marcados en el menú.</p>}
      {list.length === 0 && <p className="muted center">Aún no hay productos activos.</p>}
    </div>
  );
}
