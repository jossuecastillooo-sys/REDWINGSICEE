import { useState } from 'react';
import { fmtDateTime, isValidPhone, money, normalizePhone } from '../lib/format';
import { useCustomer, useLookupPhone, useOrders, useSettings } from '../services/data';
import { STATUS_FLOW, STATUS_MESSAGE, reorder } from '../services/orders';
import { goBack, navigate } from '../services/router';
import { toast } from '../services/ui';
import { openWhatsApp, orderMessage } from '../services/whatsapp';
import { Empty, Field } from '../components/ui';
import { BACKEND } from '../services/config';
import type { Order } from '../types';

const ACTIVE = ['Pendiente', 'Confirmado', 'En preparación', 'Listo'];

function doReorder(o: Order) {
  const r = reorder(o);
  r.warnings.forEach((w) => toast(w, 'info'));
  if (r.added) { toast(r.added + ' producto(s) agregados al carrito'); navigate('cart'); }
  else toast('No se pudo agregar ningún producto.', 'error');
}

export function Orders() {
  const [customer] = useCustomer();
  const [lookup, setLookup] = useLookupPhone();
  const [orders] = useOrders();
  const [tab, setTab] = useState<'active' | 'history'>('active');
  const [input, setInput] = useState('');
  const phone = customer?.phone || lookup;

  if (!phone) {
    return (
      <div className="page">
        <h1 className="page-title">Mis pedidos</h1>
        <p className="muted">Escribe el teléfono que usaste al hacer tu pedido para ver su estado.</p>
        <Field label="Teléfono"><input value={input} inputMode="tel" onChange={(e) => setInput(e.target.value)} placeholder="9999-9999" /></Field>
        <button className="btn btn-primary btn-block" onClick={() => (isValidPhone(input) ? setLookup(normalizePhone(input)) : toast('El teléfono debe tener 8 dígitos', 'error'))}>Consultar</button>
      </div>
    );
  }
  const mine = orders.filter((o) => o.customer.phone === phone);
  const list = mine.filter((o) => (tab === 'active' ? ACTIVE.includes(o.status) : !ACTIVE.includes(o.status)));
  return (
    <div className="page">
      <h1 className="page-title">Mis pedidos</h1>
      <div className="tabs">
        <button className={tab === 'active' ? 'on' : ''} onClick={() => setTab('active')}>Activos ({mine.filter((o) => ACTIVE.includes(o.status)).length})</button>
        <button className={tab === 'history' ? 'on' : ''} onClick={() => setTab('history')}>Historial</button>
      </div>
      {list.length === 0 ? (
        <Empty icon="orders" title={tab === 'active' ? 'No tienes pedidos activos' : 'Aún no hay historial'} action={<button className="btn btn-primary" onClick={() => navigate('menu')}>Hacer un pedido</button>} />
      ) : (
        <div className="stack">
          {list.map((o) => (
            <div key={o.id} className="card order-card">
              <button className="order-main" onClick={() => navigate('orders/' + o.id)}>
                <div className="row-between"><b>{o.number}</b><span className={'badge st-' + o.status.replace(/\s|ó/g, '')}>{o.status}</span></div>
                <p className="small muted">{fmtDateTime(o.createdAt)} · {o.lines.reduce((s, l) => s + l.qty, 0)} productos</p>
                <p className="order-total">{money(o.total)}</p>
              </button>
              <button className="btn btn-ghost btn-block" onClick={() => doReorder(o)}>Volver a pedir</button>
            </div>
          ))}
        </div>
      )}
      {!customer && <button className="link center" onClick={() => setLookup('')}>Usar otro teléfono</button>}
    </div>
  );
}

export function OrderDetail({ id }: { id: string }) {
  const [orders] = useOrders();
  const [settings] = useSettings();
  const o = orders.find((x) => x.id === id);
  if (!o) return <div className="page"><Empty icon="orders" title="Pedido no encontrado" action={<button className="btn btn-primary" onClick={() => navigate('orders')}>Mis pedidos</button>} /></div>;
  const cancelled = o.status === 'Cancelado';
  const at = (s: string) => o.history.find((h) => h.status === s)?.at;
  const current = STATUS_FLOW.indexOf(o.status);
  return (
    <div className="page">
      <button className="link" onClick={() => goBack('orders')}>← Mis pedidos</button>
      <div className="row-between"><h1 className="page-title">{o.number}</h1><span className={'badge st-' + o.status.replace(/\s|ó/g, '')}>{o.status}</span></div>
      {o.status === 'Pendiente' && <div className="notice"><b>¡Pedido recibido!</b> {BACKEND === 'local' ? 'Guardado en este dispositivo.' : ''} Pronto lo confirmaremos.</div>}
      {cancelled && <div className="notice notice-warn"><b>Pedido cancelado.</b>{o.cancelReason ? ' Motivo: ' + o.cancelReason : ''}</div>}

      <section className="card">
        <h2>Seguimiento</h2>
        <ol className="timeline">
          {STATUS_FLOW.map((s, i) => {
            const reached = !!at(s);
            const isNow = !cancelled && i === current;
            return (
              <li key={s} className={(reached ? 'done ' : '') + (isNow ? 'now' : '')}>
                <i />
                <div><b>{s === 'Pendiente' ? 'Pedido recibido' : s}</b>
                  {reached ? <p className="small muted">{fmtDateTime(at(s) as string)}</p> : <p className="small muted">Pendiente</p>}
                  {isNow && <p className="small">{STATUS_MESSAGE[s]}</p>}</div>
              </li>
            );
          })}
          {cancelled && <li className="done cancel"><i /><div><b>Cancelado</b><p className="small muted">{fmtDateTime(at('Cancelado') as string)}</p></div></li>}
        </ol>
      </section>

      <section className="card">
        <h2>Detalle</h2>
        {o.lines.map((l, i) => (
          <div key={i} className="sum-line">
            <div><b>{l.qty} × {l.name}</b>
              <p className="small muted">{[l.sizeName, ...l.options, ...l.extras.map((e) => e.name + (e.qty > 1 ? ' x' + e.qty : '')), l.note].filter(Boolean).join(' · ')}</p></div>
            <b>{money(l.unitPrice * l.qty)}</b>
          </div>
        ))}
        <div className="summary"><div><span>Subtotal</span><b>{money(o.subtotal)}</b></div><div><span>Descuentos</span><b>{money(o.discount)}</b></div><div className="total"><span>Total</span><b>{money(o.total)}</b></div></div>
        <p className="small muted">{o.pickup} · {o.payment}</p>
        {o.notes && <p className="small muted">Notas: {o.notes}</p>}
      </section>
      <div className="btn-row">
        <button className="btn btn-ghost" onClick={() => doReorder(o)}>Volver a pedir</button>
        <button className="btn btn-ghost" onClick={() => openWhatsApp(settings, orderMessage(o, settings.name))}>Enviar por WhatsApp</button>
      </div>
    </div>
  );
}
