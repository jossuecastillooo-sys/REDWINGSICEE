import type { Category, Product } from '../types';

export const catalog = (products: Product[], categories: Category[]): Product[] => {
  const active = new Set(categories.filter((c) => c.active).map((c) => c.id));
  return products.filter((p) => p.active && active.has(p.categoryId)).sort((a, b) => a.order - b.order);
};

export const fromPrice = (p: Product): number => (p.sizes.length ? Math.min(...p.sizes.map((s) => s.price)) : p.basePrice);

export const needsCustomization = (p: Product): boolean =>
  p.sizes.length > 0 || p.optionGroups.some((g) => g.choices.length > 0) || p.extras.some((e) => e.available);

export const titleLines = (t: string): string[] => t.split('|').map((x) => x.trim()).filter(Boolean);
