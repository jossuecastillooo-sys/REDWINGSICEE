import { useState } from 'react';
import { useSettings } from '../services/data';
import { goBack } from '../services/router';
import { openWhatsApp } from '../services/whatsapp';
import { Icon } from '../components/Icon';

const FAQ: [string, string][] = [
  ['¿Cómo hago un pedido?', 'Entra al Menú, toca un producto, personalízalo y agrégalo al carrito. Luego confirma tus datos en "Continuar con el pedido".'],
  ['¿Cómo personalizo mi bebida?', 'Al abrir un producto verás las opciones que tiene disponibles (leche, extras, etc.). El precio se actualiza al instante.'],
  ['¿Cómo recojo mi pedido?', 'Elige la opción de entrega al confirmar. Te avisaremos en la app cuando esté listo.'],
  ['¿Cómo veo el estado de mi pedido?', 'En la pestaña Pedidos verás cada etapa: recibido, confirmado, en preparación, listo y entregado.'],
  ['¿Cómo pago?', 'Los métodos de pago disponibles aparecen al confirmar el pedido. Actualmente el pago es en efectivo.'],
  ['¿Qué pasa si un producto se agota?', 'Se marca como agotado y no se puede agregar. Si ya estaba en tu carrito te avisaremos antes de confirmar.'],
];

export function Help() {
  const [settings] = useSettings();
  const [open, setOpen] = useState<number | null>(0);
  return (
    <div className="page">
      <button className="link" onClick={() => goBack('profile')}>← Atrás</button>
      <h1 className="page-title">Ayuda</h1>
      <div className="stack">
        {FAQ.map(([q, a], i) => (
          <div key={q} className="card faq">
            <button onClick={() => setOpen(open === i ? null : i)} aria-expanded={open === i}><b>{q}</b><Icon name={open === i ? 'up' : 'down'} size={18} /></button>
            {open === i && <p className="muted">{a}</p>}
          </div>
        ))}
      </div>
      <button className="btn btn-primary btn-block" onClick={() => openWhatsApp(settings, 'Hola ' + settings.name + ', tengo una consulta.')}><Icon name="wa" size={20} /> Escribir por WhatsApp</button>
      <button className="btn btn-ghost btn-block" onClick={() => openWhatsApp(settings, 'Hola ' + settings.name + ', quiero reportar un problema con la app: ')}>Reportar un problema</button>
    </div>
  );
}
