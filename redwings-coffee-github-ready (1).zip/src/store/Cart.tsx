import { money } from '../lib/format';
import { describeLine } from '../lib/pricing';
import { priceCart, removeLine, setLineQty, clearCart } from '../services/cart';
import { useCart, useProducts, useSettings } from '../services/data';
import { navigate } from '../services/router';
import { openProduct, toast } from '../services/ui';
import { Icon } from '../components/Icon';
import { Empty, ProductImage, Stepper } from '../components/ui';

export function Cart() {
  const [cart] = useCart();
  const [products] = useProducts();
  const [settings] = useSettings();
  const priced = priceCart(cart, products);
  const blocked = !settings.open && !settings.allowOrdersWhenClosed;

  if (!cart.length) {
    return <div className="page"><h1 className="page-title">Carrito</h1><Empty icon="bag" title="Tu carrito está vacío" text="Agrega algo del menú para empezar." action={<button className="btn btn-primary" onClick={() => navigate('menu')}>Ver menú</button>} /></div>;
  }
  return (
    <div className="page">
      <div className="row-between">
        <h1 className="page-title">Carrito <small>({priced.count})</small></h1>
        <button className="link danger" onClick={() => { if (window.confirm('¿Vaciar el carrito?')) { clearCart(); toast('Carrito vaciado', 'info'); } }}>Vaciar</button>
      </div>
      <div className="stack">
        {priced.lines.map(({ line, product, unit, total, error }) => {
          const d = product ? describeLine(product, line) : { size: undefined, options: [], extras: [] };
          return (
            <div key={line.id} className={'line' + (error ? ' line-err' : '')}>
              <ProductImage src={product?.image} name={product?.name || 'Producto'} className="line-img" />
              <div className="line-body">
                <h3>{product?.name || 'Producto eliminado'}</h3>
                <p className="small muted">{[d.size, ...d.options, ...d.extras.map((e) => e.name + (e.qty > 1 ? ' x' + e.qty : '') + ' (+' + money(e.price * e.qty) + ')'), line.note ? '“' + line.note + '”' : ''].filter(Boolean).join(' · ') || 'Sin personalización'}</p>
                {error && <p className="small err">{error}</p>}
                <div className="line-foot">
                  <Stepper value={line.qty} min={0} onChange={(n) => setLineQty(line.id, n)} />
                  <div className="line-price"><small>{money(unit)} c/u</small><b>{money(total)}</b></div>
                </div>
                <div className="line-actions">
                  {product && <button className="link" onClick={() => openProduct(line.productId, line.id)}><Icon name="edit" size={16} /> Editar</button>}
                  <button className="link danger" onClick={() => removeLine(line.id)}><Icon name="trash" size={16} /> Quitar</button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
      <div className="summary">
        <div><span>Subtotal</span><b>{money(priced.subtotal)}</b></div>
        <div><span>Descuentos</span><b>{money(0)}</b></div>
        <div className="total"><span>Total</span><b>{money(priced.subtotal)}</b></div>
      </div>
      {blocked && <div className="notice notice-warn">{settings.closedMessage}</div>}
      <button className="btn btn-primary btn-block" disabled={!priced.valid || blocked} onClick={() => navigate('checkout')}>Continuar con el pedido</button>
      {!priced.valid && <p className="small err center">Corrige los productos marcados para continuar.</p>}
    </div>
  );
}
