import { useCart, useCustomer, useNotifications, useProducts, useSettings, useLookupPhone } from '../services/data';
import { priceCart } from '../services/cart';
import { navigate } from '../services/router';
import { useOnline } from '../services/ui';
import { Icon } from '../components/Icon';
import { Cart } from './Cart';
import { Checkout } from './Checkout';
import { Favorites } from './Favorites';
import { Help } from './Help';
import { Home } from './Home';
import { Menu } from './Menu';
import { Notifications } from './Notifications';
import { OrderDetail, Orders } from './Orders';
import { Profile } from './Profile';
import { ProductSheetHost } from './ProductSheet';

const TABS: [string, string, string][] = [['', 'Inicio', 'home'], ['menu', 'Menú', 'menu'], ['orders', 'Pedidos', 'orders'], ['favorites', 'Favoritos', 'heart'], ['profile', 'Perfil', 'user']];

export function ShopApp({ route }: { route: string[] }) {
  const [settings] = useSettings();
  const [cart] = useCart();
  const [products] = useProducts();
  const [customer] = useCustomer();
  const [lookup] = useLookupPhone();
  const [notifs] = useNotifications();
  const online = useOnline();
  const count = priceCart(cart, products).count;
  const phone = customer?.phone || lookup;
  const unread = notifs.filter((n) => n.phone === phone && !n.read).length;
  const [r0, r1] = route;

  let page;
  switch (r0) {
    case 'menu': page = <Menu categoryId={r1} />; break;
    case 'cart': page = <Cart />; break;
    case 'checkout': page = <Checkout />; break;
    case 'orders': page = r1 ? <OrderDetail id={r1} /> : <Orders />; break;
    case 'favorites': page = <Favorites />; break;
    case 'profile': page = <Profile />; break;
    case 'notifications': page = <Notifications />; break;
    case 'help': page = <Help />; break;
    default: page = <Home />;
  }
  const activeTab = ['', 'menu', 'orders', 'favorites', 'profile'].includes(r0 || '') ? r0 || '' : r0 === 'notifications' || r0 === 'help' ? 'profile' : r0 === 'cart' || r0 === 'checkout' ? 'menu' : '';

  return (
    <div className="shell">
      <header className="topbar">
        <button className="brand" onClick={() => navigate('')} aria-label="Ir al inicio">
          <span className="brand-mark">R</span>
          <span><b>{settings.name}</b><small>{settings.slogan}</small></span>
        </button>
        <div className="top-actions">
          <button className="icon-btn" onClick={() => navigate('notifications')} aria-label="Notificaciones"><Icon name="bell" />{unread > 0 && <span className="badge-n">{unread}</span>}</button>
          <button className="icon-btn" onClick={() => navigate('cart')} aria-label={'Carrito, ' + count + ' productos'}><Icon name="bag" />{count > 0 && <span className="badge-n">{count}</span>}</button>
        </div>
      </header>
      {!online && <div className="offline-bar">Sin conexión · tu carrito se conserva</div>}
      <main>{page}</main>
      <nav className="bottom-nav" aria-label="Navegación principal">
        {TABS.map(([path, label, icon]) => (
          <button key={label} className={activeTab === path ? 'on' : ''} onClick={() => navigate(path)} aria-current={activeTab === path ? 'page' : undefined}>
            <Icon name={icon} /><span>{label}</span>
          </button>
        ))}
      </nav>
      <ProductSheetHost />
    </div>
  );
}
