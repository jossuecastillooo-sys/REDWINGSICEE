import { fmtDateTime } from '../lib/format';
import { useCustomer, useLookupPhone, useNotifications } from '../services/data';
import { goBack, navigate } from '../services/router';
import { Empty } from '../components/ui';
import { Icon } from '../components/Icon';

export function Notifications() {
  const [c] = useCustomer();
  const [lookup] = useLookupPhone();
  const [all, setAll] = useNotifications();
  const phone = c?.phone || lookup;
  const mine = all.filter((n) => n.phone === phone);
  return (
    <div className="page">
      <button className="link" onClick={() => goBack('profile')}>← Atrás</button>
      <div className="row-between">
        <h1 className="page-title">Notificaciones</h1>
        {mine.some((n) => !n.read) && <button className="link" onClick={() => setAll(all.map((n) => (n.phone === phone ? { ...n, read: true } : n)))}>Marcar leídas</button>}
      </div>
      <p className="small muted">Avisos dentro de la app. Las notificaciones push al celular se activarán al conectar el servidor.</p>
      {mine.length === 0 ? <Empty icon="bell" title="Sin notificaciones" text={phone ? 'Aquí verás el estado de tus pedidos.' : 'Haz un pedido o consulta tus pedidos con tu teléfono.'} /> : (
        <div className="stack">
          {mine.map((n) => (
            <div key={n.id} className={'card notif' + (n.read ? '' : ' unread')}>
              <button className="notif-main" onClick={() => { setAll(all.map((x) => (x.id === n.id ? { ...x, read: true } : x))); if (n.orderId) navigate('orders/' + n.orderId); }}>
                <b>{n.title}</b><p className="small">{n.body}</p><p className="small muted">{fmtDateTime(n.createdAt)}</p>
              </button>
              <button className="icon-btn" aria-label="Eliminar" onClick={() => setAll(all.filter((x) => x.id !== n.id))}><Icon name="trash" size={18} /></button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
