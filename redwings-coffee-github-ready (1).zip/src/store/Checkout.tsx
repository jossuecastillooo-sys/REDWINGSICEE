import type React from 'react';
import { useState } from 'react';
import { isValidPhone, money, normalizePhone } from '../lib/format';
import { describeLine } from '../lib/pricing';
import { clearCart, priceCart } from '../services/cart';
import { BACKEND } from '../services/config';
import { useCart, useCustomer, useProducts, useSettings } from '../services/data';
import { submitOrder } from '../services/orders';
import { goBack, navigate } from '../services/router';
import { toast, useOnline } from '../services/ui';
import { Field } from '../components/ui';

export function Checkout() {
  const [cart] = useCart();
  const [products] = useProducts();
  const [settings] = useSettings();
  const [customer, setCustomer] = useCustomer();
  const online = useOnline();
  const priced = priceCart(cart, products);
  const [f, setF] = useState({
    name: customer?.name || '', phone: customer?.phone || '', career: customer?.career || '', grade: customer?.grade || '', section: customer?.section || '',
  });
  const [pickup, setPickup] = useState(settings.pickupMethods[0] || '');
  const [payment, setPayment] = useState(settings.paymentMethods[0] || '');
  const [notes, setNotes] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF((x) => ({ ...x, [k]: e.target.value }));

  if (!cart.length) {
    return <div className="page"><p className="muted center">No hay productos en el carrito.</p><button className="btn btn-primary btn-block" onClick={() => navigate('menu')}>Ir al menú</button></div>;
  }

  const validate = () => {
    const e: Record<string, string> = {};
    if (!f.name.trim()) e.name = 'Escribe tu nombre';
    if (!isValidPhone(f.phone)) e.phone = 'Debe tener 8 dígitos';
    if (!f.career.trim()) e.career = 'Requerido';
    if (!f.grade.trim()) e.grade = 'Requerido';
    if (!f.section.trim()) e.section = 'Requerido';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const confirm = () => {
    if (!validate()) return toast('Revisa los campos marcados', 'error');
    setBusy(true);
    const res = submitOrder({ customer: { ...f, phone: normalizePhone(f.phone) }, pickup, payment, notes });
    setBusy(false);
    if (!res.ok) return toast(res.error, 'error');
    setCustomer({ ...f, phone: normalizePhone(f.phone), createdAt: customer?.createdAt || new Date().toISOString() });
    clearCart();
    navigate('orders/' + res.order.id);
  };

  return (
    <div className="page">
      <div className="row-between"><button className="link" onClick={() => goBack('cart')}>← Carrito</button><span className="steps">Paso 2 de 2</span></div>
      <h1 className="page-title">Confirmar pedido</h1>

      <section className="card">
        <h2>Tus datos</h2>
        <Field label="Nombre completo"><input value={f.name} onChange={set('name')} autoComplete="name" />{errors.name && <em className="err">{errors.name}</em>}</Field>
        <Field label="Teléfono" hint="Sirve para consultar tus pedidos."><input value={f.phone} onChange={set('phone')} inputMode="tel" autoComplete="tel" placeholder="9999-9999" />{errors.phone && <em className="err">{errors.phone}</em>}</Field>
        <Field label="Carrera"><input value={f.career} onChange={set('career')} />{errors.career && <em className="err">{errors.career}</em>}</Field>
        <div className="two">
          <Field label="Grado"><input value={f.grade} onChange={set('grade')} />{errors.grade && <em className="err">{errors.grade}</em>}</Field>
          <Field label="Sección"><input value={f.section} onChange={set('section')} />{errors.section && <em className="err">{errors.section}</em>}</Field>
        </div>
      </section>

      <section className="card">
        <h2>Entrega</h2>
        {settings.pickupMethods.map((m) => <label key={m} className={'opt' + (pickup === m ? ' on' : '')}><input type="radio" name="pickup" checked={pickup === m} onChange={() => setPickup(m)} /><span>{m}</span></label>)}
        <h2 className="mt">Pago</h2>
        {settings.paymentMethods.map((m) => <label key={m} className={'opt' + (payment === m ? ' on' : '')}><input type="radio" name="pay" checked={payment === m} onChange={() => setPayment(m)} /><span>{m}</span></label>)}
        <Field label="Notas para el pedido (opcional)"><input value={notes} maxLength={200} onChange={(e) => setNotes(e.target.value)} /></Field>
      </section>

      <section className="card">
        <h2>Resumen</h2>
        {priced.lines.map(({ line, product, total, error }) => (
          <div key={line.id} className="sum-line">
            <div><b>{line.qty} × {product?.name}</b>
              <p className="small muted">{product ? [...(() => { const d = describeLine(product, line); return [d.size, ...d.options, ...d.extras.map((e) => e.name + (e.qty > 1 ? ' x' + e.qty : ''))]; })()].filter(Boolean).join(' · ') : ''}</p>
              {error && <p className="small err">{error}</p>}</div>
            <b>{money(total)}</b>
          </div>
        ))}
        <div className="summary">
          <div><span>Subtotal</span><b>{money(priced.subtotal)}</b></div>
          <div><span>Descuentos</span><b>{money(0)}</b></div>
          <div className="total"><span>Total</span><b>{money(priced.subtotal)}</b></div>
        </div>
      </section>

      {BACKEND === 'local' && <p className="small muted center">Modo local: el pedido se guarda en este dispositivo hasta que se conecte la base de datos.</p>}
      {!online && <p className="small err center">Sin conexión. Tu carrito está guardado.</p>}
      <button className="btn btn-primary btn-block" disabled={busy || !priced.valid} onClick={confirm}>Confirmar pedido · {money(priced.subtotal)}</button>
    </div>
  );
}
