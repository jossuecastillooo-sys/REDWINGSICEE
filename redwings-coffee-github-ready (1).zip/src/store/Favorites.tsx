import { useFavorites, useProducts } from '../services/data';
import { navigate } from '../services/router';
import { Empty } from '../components/ui';
import { ProductCard } from './ProductCard';

export function Favorites() {
  const [favs] = useFavorites();
  const [products] = useProducts();
  const list = products.filter((p) => favs.includes(p.id) && p.active);
  return (
    <div className="page">
      <h1 className="page-title">Favoritos</h1>
      {list.length === 0 ? (
        <Empty icon="heart" title="Aún no tienes favoritos" text="Toca el corazón en cualquier producto para guardarlo aquí." action={<button className="btn btn-primary" onClick={() => navigate('menu')}>Ver menú</button>} />
      ) : (
        <div className="grid">{list.map((p) => <ProductCard key={p.id} p={p} />)}</div>
      )}
    </div>
  );
}
