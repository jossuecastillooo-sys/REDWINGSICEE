import { AdminApp } from './admin/AdminApp';
import { ToastHost } from './components/ui';
import { useRoute } from './services/router';
import { ShopApp } from './store/ShopApp';

/** La administración solo es accesible escribiendo la ruta #/admin; no hay ningún botón público hacia ella. */
export default function App() {
  const route = useRoute();
  return (
    <>
      {route[0] === 'admin' ? <AdminApp route={route} /> : <ShopApp route={route} />}
      <ToastHost />
    </>
  );
}
