import { useEffect, useState, type ReactNode } from 'react';
import { toast, useToast } from '../services/ui';
import { fileToDataUrl } from '../lib/image';
import { Icon } from './Icon';

export function ToastHost() {
  const t = useToast();
  if (!t) return null;
  return (
    <div className={'toast toast-' + t.kind} role="status" key={t.id}>
      {t.msg}
    </div>
  );
}

export function Sheet({ title, onClose, children, footer, tall }: { title: string; onClose: () => void; children: ReactNode; footer?: ReactNode; tall?: boolean }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [onClose]);
  return (
    <div className="sheet-backdrop" onClick={onClose}>
      <div className={'sheet' + (tall ? ' sheet-tall' : '')} role="dialog" aria-modal="true" aria-label={title} onClick={(e) => e.stopPropagation()}>
        <div className="sheet-head">
          <h2>{title}</h2>
          <button className="icon-btn" onClick={onClose} aria-label="Cerrar"><Icon name="close" /></button>
        </div>
        <div className="sheet-body">{children}</div>
        {footer && <div className="sheet-foot">{footer}</div>}
      </div>
    </div>
  );
}

export function Stepper({ value, onChange, min = 0, max = 99 }: { value: number; onChange: (n: number) => void; min?: number; max?: number }) {
  return (
    <div className="stepper">
      <button onClick={() => onChange(Math.max(min, value - 1))} disabled={value <= min} aria-label="Menos"><Icon name="minus" size={18} /></button>
      <span>{value}</span>
      <button onClick={() => onChange(Math.min(max, value + 1))} disabled={value >= max} aria-label="Más"><Icon name="plus" size={18} /></button>
    </div>
  );
}

export function Empty({ icon, title, text, action }: { icon: string; title: string; text?: string; action?: ReactNode }) {
  return (
    <div className="empty">
      <div className="empty-icon"><Icon name={icon} size={30} /></div>
      <h3>{title}</h3>
      {text && <p>{text}</p>}
      {action}
    </div>
  );
}

export function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return (
    <label className="field">
      <span>{label}</span>
      {children}
      {hint && <small>{hint}</small>}
    </label>
  );
}

export function Switch({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button type="button" className="switch-row" onClick={() => onChange(!checked)} role="switch" aria-checked={checked}>
      <span>{label}</span>
      <span className={'switch' + (checked ? ' on' : '')}><i /></span>
    </button>
  );
}

export function ProductImage({ src, name, className = '' }: { src?: string; name: string; className?: string }) {
  if (src) return <img className={'pimg ' + className} src={src} alt={name} loading="lazy" decoding="async" />;
  return (
    <div className={'pimg pimg-ph ' + className} aria-label={name}>
      <Icon name="menu" size={34} />
    </div>
  );
}

export function ImagePicker({ value, onChange, label = 'Foto' }: { value?: string; onChange: (v: string | undefined) => void; label?: string }) {
  return (
    <div className="field">
      <span>{label}</span>
      <div className="img-picker">
        <ProductImage src={value} name={label} className="img-prev" />
        <div className="img-actions">
          <label className="btn btn-ghost">
            <Icon name="camera" size={18} /> {value ? 'Cambiar' : 'Subir foto'}
            <input
              type="file" accept="image/*" hidden
              onChange={async (e) => {
                const f = e.target.files?.[0];
                e.target.value = '';
                if (!f) return;
                try {
                  onChange(await fileToDataUrl(f));
                } catch (err) {
                  toast(err instanceof Error ? err.message : 'No se pudo cargar la imagen.', 'error');
                }
              }}
            />
          </label>
          {value && <button type="button" className="btn btn-ghost" onClick={() => onChange(undefined)}>Quitar</button>}
        </div>
      </div>
    </div>
  );
}

export function Num({ value, onChange, placeholder, label }: { value: number; onChange: (n: number) => void; placeholder?: string; label?: string }) {
  const [t, setT] = useState(String(value));
  useEffect(() => {
    if (Number(t) !== value) setT(String(value));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);
  return (
    <input
      inputMode="decimal" aria-label={label} placeholder={placeholder} value={t}
      onChange={(e) => {
        const s = e.target.value.replace(',', '.');
        if (/^\d*\.?\d*$/.test(s)) {
          setT(s);
          onChange(s === '' || s === '.' ? 0 : Number(s));
        }
      }}
    />
  );
}

export function BarList({ items, empty = 'Sin datos todavía' }: { items: { label: string; value: number; display: string }[]; empty?: string }) {
  const max = Math.max(1, ...items.map((i) => i.value));
  if (!items.length) return <p className="muted small">{empty}</p>;
  return (
    <div className="bars">
      {items.map((i) => (
        <div key={i.label} className="bar-row">
          <span className="bar-label">{i.label}</span>
          <span className="bar-track"><i style={{ width: Math.max(2, (i.value / max) * 100) + '%' }} /></span>
          <b>{i.display}</b>
        </div>
      ))}
    </div>
  );
}
