const P: Record<string, string> = {
  home: 'M3 11l9-8 9 8M5 10v10h5v-6h4v6h5V10',
  menu: 'M5 8h12v5a5 5 0 01-5 5h-2a5 5 0 01-5-5V8zM17 9h2a2 2 0 010 4h-2M8 3v2M11 3v2M14 3v2',
  orders: 'M6 3h12v18l-3-2-3 2-3-2-3 2V3zM9 8h6M9 12h6',
  heart: 'M12 20s-7-4.4-7-10a4 4 0 017-2.6A4 4 0 0119 10c0 5.6-7 10-7 10z',
  user: 'M12 12a4 4 0 100-8 4 4 0 000 8zM4 21a8 8 0 0116 0',
  bag: 'M5 8h14l-1 12H6L5 8zM9 8V6a3 3 0 016 0v2',
  bell: 'M6 16V11a6 6 0 0112 0v5l2 2H4l2-2zM10 21h4',
  back: 'M15 5l-7 7 7 7',
  plus: 'M12 5v14M5 12h14',
  minus: 'M5 12h14',
  close: 'M6 6l12 12M18 6L6 18',
  search: 'M11 18a7 7 0 100-14 7 7 0 000 14zM21 21l-5-5',
  check: 'M5 12l5 5L20 7',
  trash: 'M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13',
  edit: 'M4 20h4L19 9l-4-4L4 16v4zM13 7l4 4',
  copy: 'M9 9h11v11H9zM5 15V4h11',
  up: 'M6 15l6-6 6 6',
  down: 'M6 9l6 6 6-6',
  camera: 'M4 8h4l2-3h4l2 3h4v11H4V8zM12 17a4 4 0 100-8 4 4 0 000 8z',
  chart: 'M4 20V10M10 20V4M16 20v-7M22 20H2',
  tag: 'M3 12V3h9l9 9-9 9-9-9zM8 8h.01',
  gear: 'M12 15a3 3 0 100-6 3 3 0 000 6zM19 12l2-1-2-4-2 .5-1.5-1.2L15 4H9l-.5 2.3L7 7.5 5 7l-2 4 2 1v0l-2 1 2 4 2-.5 1.5 1.2L9 20h6l.5-2.3 1.5-1.2 2 .5 2-4-2-1z',
  help: 'M9 9a3 3 0 115 2c-1 1-2 1.5-2 3M12 18h.01',
  wa: 'M4 20l1.3-4A8 8 0 118 19l-4 1zM9 9c0 3 3 6 6 6l1-2-2-1-1 .7c-.8-.4-1.5-1.1-1.9-1.9L12 10l-1-2-2 1z',
  logout: 'M10 4H4v16h6M16 8l4 4-4 4M20 12H9',
  list: 'M4 6h16M4 12h16M4 18h16',
};

export function Icon({ name, size = 22 }: { name: keyof typeof P | string; size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d={P[name] || ''} />
    </svg>
  );
}
