export type ID = string;

export interface Category {
  id: ID;
  name: string;
  description?: string;
  image?: string;
  order: number;
  active: boolean;
}

export interface Extra {
  id: ID;
  name: string;
  price: number;
  available: boolean;
  max?: number;
  image?: string;
}

export interface Choice {
  id: ID;
  name: string;
  price: number;
}

export interface OptionGroup {
  id: ID;
  name: string;
  required: boolean;
  choices: Choice[];
}

export interface Size {
  id: ID;
  name: string;
  /** Precio absoluto del producto en este tamaño. */
  price: number;
}

export type Tag = 'Nuevo' | 'Popular' | 'Oferta';

export interface Product {
  id: ID;
  name: string;
  description: string;
  image?: string;
  categoryId: ID;
  basePrice: number;
  code?: string;
  active: boolean;
  soldOut: boolean;
  /** null = sin control de inventario. */
  stock: number | null;
  tags: Tag[];
  featured: boolean;
  recommended: boolean;
  ingredients: string[];
  prepMinutes?: number;
  sizes: Size[];
  optionGroups: OptionGroup[];
  extras: Extra[];
  order: number;
  /** true = dato de ejemplo cargado por el sistema (se pone en false al editarlo). */
  demo?: boolean;
}

export interface CartLine {
  id: ID;
  productId: ID;
  sizeId?: ID;
  /** groupId -> choiceId */
  choices: Record<ID, ID>;
  /** extraId -> cantidad */
  extras: Record<ID, number>;
  qty: number;
  note?: string;
}

export type OrderStatus =
  | 'Pendiente'
  | 'Confirmado'
  | 'En preparación'
  | 'Listo'
  | 'Entregado'
  | 'Cancelado';

export interface OrderLine {
  productId: ID;
  name: string;
  sizeName?: string;
  options: string[];
  extras: { name: string; qty: number; price: number }[];
  qty: number;
  /** Precio unitario al momento de la compra. */
  unitPrice: number;
  note?: string;
  /** Configuración original, para "Volver a pedir". */
  config: { sizeId?: ID; choices: Record<ID, ID>; extras: Record<ID, number> };
}

export interface Order {
  id: ID;
  number: string;
  createdAt: string;
  customer: { name: string; phone: string; career: string; grade: string; section: string };
  lines: OrderLine[];
  subtotal: number;
  discount: number;
  total: number;
  status: OrderStatus;
  history: { status: OrderStatus; at: string }[];
  pickup: string;
  payment: string;
  notes?: string;
  cancelReason?: string;
  /** Si el stock fue descontado al crear el pedido (para restaurarlo al cancelar). */
  stockReserved?: boolean;
}

export interface AppNotification {
  id: ID;
  /** Teléfono del cliente destinatario. */
  phone: string;
  title: string;
  body: string;
  createdAt: string;
  read: boolean;
  orderId?: ID;
}

export interface StoreSettings {
  name: string;
  slogan: string;
  open: boolean;
  closedMessage: string;
  allowOrdersWhenClosed: boolean;
  hours: string;
  whatsapp: string;
  phone: string;
  notice: string;
  banner: { title: string; text: string; image?: string };
  pickupMethods: string[];
  paymentMethods: string[];
  lowStockThreshold: number;
}

export interface CustomerProfile {
  name: string;
  phone: string;
  career: string;
  grade: string;
  section: string;
  createdAt: string;
}

export interface ActivityEntry {
  id: ID;
  at: string;
  user: string;
  action: string;
  section: string;
  item: string;
}
