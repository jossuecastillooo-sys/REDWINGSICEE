# Redwings Coffee

PWA Android-first (React + TypeScript + Vite) para la cafetería Redwings Coffee: tienda para clientes y panel administrativo privado.

## Ejecutar

```bash
npm install
npm run dev      # desarrollo
npm run build    # compila a /dist
npm run preview  # prueba la versión compilada (necesaria para probar la PWA)
```

- Tienda: `/`  ·  Panel admin: `/#/admin` (no hay ningún botón público hacia él; la primera vez se crea la contraseña).
- Instalación en Android: abrir en Chrome (HTTPS o `localhost`) → menú → "Instalar app".
- Publicación en GitHub Pages: `npm run build` y subir el contenido de `dist/` (usa rutas relativas y rutas con `#`, no necesita configuración extra).

## Estructura

```
src/
  types/       Modelos (Producto, Pedido, Ajustes…)
  lib/         Formato, precios/validación, imágenes
  services/    store (persistencia), data (hooks), cart, orders, auth, whatsapp, seed
  store/       Pantallas del cliente
  admin/       Panel administrativo
  components/  UI compartida (Sheet, Stepper, Switch, ImagePicker…)
  styles/      app.css (tema oscuro, crema y dorado)
  legacy/      Versión anterior (referencia, no se usa)
public/        manifest, service worker, iconos
```

## Datos

Todo pasa por `src/services/store.ts` (hoy `localStorage`). Para conectar Firebase solo hay que sustituir `getStored/setStored` por un adaptador de Firestore; los componentes no cambian. Estado detallado en [`docs/ESTADO.md`](docs/ESTADO.md).
