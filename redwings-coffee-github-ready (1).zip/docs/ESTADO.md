# Estado del proyecto (v0.2.0)

> Aviso: esta versión se escribió sin poder ejecutar `npm install` ni `npm run build`. Hay que compilar y probar en un equipo con red antes de publicar.

## Terminado (en código)
- Arquitectura modular, tema oscuro/crema/dorado, navegación inferior (Inicio, Menú, Pedidos, Favoritos, Perfil).
- Catálogo con categorías, búsqueda sin acentos/mayúsculas, filtro de disponibilidad, orden, etiquetas, agotados bloqueados.
- Personalización por producto (tamaños, grupos de opciones, extras con máximo), precio en vivo.
- Carrito persistente, líneas separadas por personalización, editar, recalcular con precios actuales.
- Checkout con validaciones, verificación de disponibilidad/precios/stock, pedido único con número RW-0001…, precio guardado al comprar.
- Seguimiento con línea de tiempo real (solo estados alcanzados), cancelación con motivo, notificaciones internas, "Volver a pedir" con avisos de cambios.
- Favoritos, perfil, ayuda, WhatsApp (resumen opcional; el pedido existe sin WhatsApp).
- Admin (`#/admin`): resumen con ventas reales, pedidos (filtros, búsqueda, cambio de estado, cancelar), productos (crear/editar/duplicar/eliminar/reordenar/agotar/desactivar, fotos desde el dispositivo, extras, opciones, tamaños, stock), categorías, configuración (tienda abierta/cerrada, portada, métodos, horario), registro de actividad, respaldo/restauración JSON.
- PWA: manifest, iconos, service worker con caché y modo sin conexión limitado.

## Limitaciones actuales
- Los datos viven en el navegador de cada dispositivo: tienda y admin **no se sincronizan entre teléfonos** hasta conectar la base de datos.
- La contraseña del admin protege solo la interfaz local; no es seguridad real. Requiere Firebase Auth + reglas.
- Sin notificaciones push (solo bandeja interna). Requiere Firebase Cloud Messaging.
- Imágenes guardadas dentro de `localStorage` (≈5 MB de límite): usar pocas fotos hasta tener Storage.

## Pendiente (fases siguientes)
Inventario avanzado e ingredientes, costos y ganancia, promociones y combos, puntos y recompensas, menú secreto, personal y permisos por rol, marketing/campañas, exportar reportes, Firebase (Auth, Firestore, Storage, reglas), pruebas automáticas.
